# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, cookielib,urllib, urllib2,re,sys

MainURL = 'http://www.wareztuga.me/'
addon_id = 'plugin.video.wt'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
art = '/resources/art/'
mensagemok = xbmcgui.Dialog().ok
selfAddon = xbmcaddon.Addon(id=addon_id)
wtpath = selfAddon.getAddonInfo('path')
iconpequeno=wtpath + art + 'logo32.png'
cookie = cookielib.CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
opener.addheaders = [('Host','www.wareztuga.me'),
                     ('User-Agent', user_agent),
                     ('X-Requested-With','XMLHttpRequest'),
                     ('Referer',MainURL + 'login.php')]
username = urllib.quote(selfAddon.getSetting('wareztuga-username'))
password = urllib.quote(selfAddon.getSetting('wareztuga-password'))
logintest = opener.open(MainURL + "login.ajax.php?username=%s&password=%s"%(username,password)).read()
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
traducao= selfAddon.getLocalizedString
vazio=[]
#bits = sys.argv[1].split(',')
print sys.argv[1]
accao =re.compile("'(.+?)'").findall(sys.argv[1])[0]
tipo=re.compile("'(.+?)'").findall(sys.argv[1])[1]
warezid=re.compile("'(.+?)'").findall(sys.argv[1])[2]
urlficheiro=re.compile("'(.+?)'").findall(sys.argv[1])[3]
print urlficheiro

#tipo = bits[0]
#warezid = bits[1][:-4].strip()
#overlay =  bits[2].strip()

def abrir_url_cookie(url):
    link=opener.open(url).read()
    return link

def abrir_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def apagarinterrompido(tipo):
    try: os.remove(os.path.join(pastaperfil, tipo))
    except: pass
    try: os.remove(os.path.join(pastaperfil, tipo + '_info'))
    except: pass
    xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + "Temporario Removido" + ",'10000',"+iconpequeno+")")
    xbmc.executebuiltin("XBMC.Container.Refresh")

def accaonosite(tipo,warezid,metodo):
    url=MainURL + 'fave.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid + '&action=' + metodo
    abrir_url_cookie(url)
    xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + traducao(40116) + ",'10000',"+iconpequeno+")")
    xbmc.executebuiltin("XBMC.Container.Refresh")

def comentarios():
    link=abrir_url_cookie(urlficheiro)
    comentarios=re.compile('<div id=".+?".+?>\r\n\t<div class="item.+?>\r\n\t\t<div class="comment-header">\r\n\t\t\t<div class="avatar">\r\n\t\t\t\t<img src="(.+?)" alt="(.+?)" />\r\n\t\t\t\t\r\n\t\t\t</div>\r\n\t\t\t<div class="comment-info">\r\n\t\t\t\t<div class="comment-user">\r\n\t\t\t\t\t<div class="username">\r\n\t\t\t\t\t\t<span>.+?</span>\r\n\t\t\t\t\t\t<div class=".+?"></div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="comment-date"><span>(.+?)</span></div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class="comment-number">.+?</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class="clear"></div>\r\n\t\t<div class="comment-body">\r\n\t\t\t<span>(.+?)</span>\r\n\t\t</div>\r\n\t\t<div class="comment-separator"></div>').findall(link)
    texto=[]
    if comentarios==vazio: texto.append('\n[B]' + str(traducao(40117)) + '[/B]')
    else: texto.append('\n[B]' + str(traducao(40118)) + ':[/B]')
    xbmc.executebuiltin("ActivateWindow(10147)")
    window = xbmcgui.Window(10147)
    xbmc.sleep(100)
    window.getControl(1).setLabel( "%s - %s" % ("Comentarios",'wareztuga.tv',))
    for foto,nick,tempo,comment in comentarios:
        #comment=caracteres(comment)
        texto.append('[B]' + nick + '[/B] (' + tempo + '): ' + comment)
        print texto
    texto='\n\n'.join(texto)
    window.getControl(5).setText(texto)

def votar(tipo,warezid):
    voto = xbmcgui.Dialog().numeric(0,traducao(40120))
    voto=int(voto)
    if voto > 10 or voto<1:
        votar(tipo,warezid)
    else:
        voto=str(voto)
        urlfinal= MainURL + 'mediaRater.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid + '&rate=' + voto
        abrir_url_cookie(urlfinal)
        xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + traducao(40121) + ",'10000',"+iconpequeno+")")

def trailer(warezid):
    print warezid
    request= 'http://api.themoviedb.org/3/movie/' + warezid + '/trailers?api_key=6ee3768ba155b41252384a1148398b34'
    txheaders= {'Accept': 'application/json','User-Agent':user_agent}
    req = urllib2.Request(request,None,txheaders)
    response=urllib2.urlopen(req).read()
    if re.search('"size":"HD"',response): codigo=re.compile('"size":"HD","source":"(.+?)"').findall(response)[0]
    elif re.search('"size":"HQ"',response): codigo=re.compile('"size":"HQ","source":"(.+?)"').findall(response)[0]
    elif re.search('"size":"Standard"',response): codigo=re.compile('"size":"Standard","source":"(.+?)"').findall(response)[0]
    else:
        mensagemok("wareztuga.tv",'Sem fontes de trailer disponiveis.')
        return
    sources = []
    urlfinal='http://www.youtube.com/watch?v=' + codigo
    sys.argv=''
    import urlresolver
    hosted_media = urlresolver.HostedMediaFile(url=urlfinal)
    sources.append(hosted_media)
    source = urlresolver.choose_source(sources)
    if source: stream_url = source.resolve()
    else: stream_url = ''
    xbmc.Player().play(stream_url)

def comentar(tipo,warezid):
    keyb = xbmc.Keyboard('', traducao(40122))
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText()
        encode=urllib.quote(search)
        if encode != '':
            comentario=urllib.quote(encode)
            #linkcomment = MainURL + 'comment.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid
            values = {'comment': comentario}
            #html = net.http_POST(linkcomment, values,opener).content
            
           



            #encode.append('Comentário efectuado através de wareztuga.tv mobile')
            #encode='\n\n'.join(encode)
            #values = {'comment': encode}
            #data = urllib.urlencode(values)
            data = urllib.urlencode(values)
            #params = urllib.urlencode(opener)
#            linkcomment = MainURL + 'comment.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid
            req = urllib2.Request(MainURL + 'comment.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid, opener)
            #html = net.http_POST(linkcomment, data).content
            response = urllib2.urlopen(req,"comment=teste").read()
            #response.close()
#           req = urllib2.Request(linkcomment, data, opener)
#            response = urllib2.urlopen(req)
#            link = response.read()
#            response.close()
      
            #link=opener2.open(linkcomment).read()
            #f = urllib.urlopen(opener.open(linkcomment), query)
            #contents = f.read()
            #f.close()
            #print linkcomment
            #html = net.http_POST(linkcomment, data).content

def principal():
    if accao== 'visto': accaonosite(tipo,warezid,'watched')
    if accao== 'faved': accaonosite(tipo,warezid,'faved')
    if accao== 'cliped': accaonosite(tipo,warezid,'cliped')
    if accao== 'subscribed': accaonosite(tipo,warezid,'subscribed')
    if accao== 'comentarios': comentarios()
    if accao== 'comentar': comentar(tipo,warezid)
    if accao== 'votar': votar(tipo,warezid)
    if accao== 'trailer': trailer(warezid)
    if accao== 'interrompido':apagarinterrompido(tipo)        

principal()
