# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, cookielib,urllib, urllib2,re,sys

MainURL = 'http://www.wareztuga.me/'
addon_id = 'plugin.video.wt'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36'
art = '/resources/art/'
mensagemok = xbmcgui.Dialog().ok
selfAddon = xbmcaddon.Addon(id=addon_id)
wtpath = selfAddon.getAddonInfo('path').decode('utf-8')
iconpequeno=wtpath + art + 'logo32.png'
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile')).decode('utf-8')
cookie_wt = os.path.join(pastaperfil, "cookiewt.lwp")
traducaoma= selfAddon.getLocalizedString
vazio=[]
print sys.argv[1]
accao =re.compile("'(.+?)'").findall(sys.argv[1])[0]
tipo=re.compile("'(.+?)'").findall(sys.argv[1])[1]
warezid=re.compile("'(.+?)'").findall(sys.argv[1])[2]
urlficheiro=re.compile("'(.+?)'").findall(sys.argv[1])[3]
print urlficheiro

def abrir_url_cookie(url,parametros):
      from t0mm0.common.net import Net
      net=Net()
      net.set_cookies(cookie_wt)
      try:
            if parametros:link=net.http_POST(url,parametros).content.encode('latin-1','ignore')
            link=net.http_GET(url).content.encode('latin-1','ignore')
            return link
      except urllib2.HTTPError, e:
            mensagemok('wareztuga.tv',str(urllib2.HTTPError(e.url, e.code, traducao(40199), e.hdrs, e.fp)),traducao(40200))
            sys.exit(0)
      except urllib2.URLError, e:
            mensagemok('wareztuga.tv',traducao(40199) + ' ' + traducao(40200))
            sys.exit(0)

def abrir_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def traducao(texto):
      return traducaoma(texto).encode('utf-8')

def apagarinterrompido(tipo):
    try: os.remove(os.path.join(pastaperfil, tipo))
    except: pass
    try: os.remove(os.path.join(pastaperfil, tipo + '_info'))
    except: pass
    xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + traducao(40201) + ",'10000',"+iconpequeno.encode('utf-8')+")")
    xbmc.executebuiltin("XBMC.Container.Refresh")

def accaonosite(tipo,warezid,metodo):
    url=MainURL + 'fave.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid + '&action=' + metodo
    abrir_url_cookie(url,False)
    xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + traducao(40116) + ",'10000',"+iconpequeno.encode('utf-8')+")")
    xbmc.executebuiltin("XBMC.Container.Refresh")

def comentarios():
    link=abrir_url_cookie(urlficheiro,False)
    comentarios=re.compile('<div id=".+?".+?>\r\n\t<div class="item.+?>\r\n\t\t<div class="comment-header">\r\n\t\t\t<div class="avatar">\r\n\t\t\t\t<img src="(.+?)" alt="(.+?)" />\r\n\t\t\t\t\r\n\t\t\t</div>\r\n\t\t\t<div class="comment-info">\r\n\t\t\t\t<div class="comment-user">\r\n\t\t\t\t\t<div class="username">\r\n\t\t\t\t\t\t<span>.+?</span>\r\n\t\t\t\t\t\t<div class=".+?"></div>\r\n\t\t\t\t\t</div>\r\n\t\t\t\t\t<div class="comment-date"><span>(.+?)</span></div>\r\n\t\t\t\t</div>\r\n\t\t\t\t<div class="comment-number">.+?</div>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\t\t<div class="clear"></div>\r\n\t\t<div class="comment-body">\r\n\t\t\t<span>(.+?)</span>\r\n\t\t</div>\r\n\t\t<div class="comment-separator"></div>').findall(link)
    texto=[]
    if comentarios==vazio: texto.append('\n[B]' + str(traducao(40117)) + '[/B]')
    else: texto.append('\n[B]' + str(traducao(40118)) + ':[/B]')
    xbmc.executebuiltin("ActivateWindow(10147)")
    window = xbmcgui.Window(10147)
    xbmc.sleep(100)
    window.getControl(1).setLabel( "%s - %s" % (traducao(40119),'wareztuga.tv',))
    for foto,nick,tempo,comment in comentarios:
        #comment=caracteres(comment)
        texto.append('[B]' + nick + '[/B] (' + tempo + '): ' + comment)
        print texto
    texto='\n\n'.join(texto)
    window.getControl(5).setText(texto)

def votar(tipo,warezid):
    voto = xbmcgui.Dialog().numeric(0,traducao(40120))
    voto=int(voto)
    if voto > 10 or voto<1:
        votar(tipo,warezid)
    else:
        voto=str(voto)
        urlfinal= MainURL + 'mediaRater.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid + '&rate=' + voto
        abrir_url_cookie(urlfinal,False)
        xbmc.executebuiltin("XBMC.Notification(wareztuga.tv," + traducao(40121) + ",'10000',"+iconpequeno.encode('utf-8')+")")

def trailer(warezid):
    print warezid
    request= 'http://api.themoviedb.org/3/movie/' + warezid + '/trailers?api_key=6ee3768ba155b41252384a1148398b34'
    txheaders= {'Accept': 'application/json','User-Agent':user_agent}
    req = urllib2.Request(request,None,txheaders)
    response=urllib2.urlopen(req).read()
    if re.search('"size":"HD"',response): codigo=re.compile('"size":"HD","source":"(.+?)"').findall(response)[0]
    elif re.search('"size":"HQ"',response): codigo=re.compile('"size":"HQ","source":"(.+?)"').findall(response)[0]
    elif re.search('"size":"Standard"',response): codigo=re.compile('"size":"Standard","source":"(.+?)"').findall(response)[0]
    else:
        mensagemok("wareztuga.tv",traducao(40202))
        return
    sources = []
    urlfinal='http://www.youtube.com/watch?v=' + codigo
    sys.argv=''
    import urlresolver
    hosted_media = urlresolver.HostedMediaFile(url=urlfinal)
    sources.append(hosted_media)
    source = urlresolver.choose_source(sources)
    if source: stream_url = source.resolve()
    else: stream_url = ''
    xbmc.Player().play(stream_url)

def reportarerro(tipo,warezid):
    mensagemok('wareztuga.tv',traducao(40203), traducao(40204), traducao(40205))
    keyb = xbmc.Keyboard('', traducao(40206))
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText()
        encode=[]
        encode.append(search)
        if encode != '' and len(encode[0])>=3:
            encode.append('Erro reportado através de wareztuga.tv mobile (XBMC).')
            comentario='\n\n'.join(encode)
            linkreport = MainURL + 'report.ajax.php?mediaType' + tipo + '&mediaID=' + warezid
            parametros = {'problem': comentario}
            abrir_url_cookie(linkreport,parametros)
            xbmc.executebuiltin("XBMC.Notification(wareztuga.tv,"+traducao(40207)+",'10000',"+iconpequeno.encode('utf-8')+")")
        else: xbmc.executebuiltin("XBMC.Notification(wareztuga.tv,"+traducao(40213)+",'10000',"+iconpequeno.encode('utf-8')+")")

def comentar(tipo,warezid):
    keyb = xbmc.Keyboard('', traducao(40122))
    keyb.doModal()
    if (keyb.isConfirmed()):
        search = keyb.getText()
        encode=[]
        encode.append(search)
        if encode != '' and len(encode[0])>=3:
            encode.append('Comentário efectuado através de wareztuga.tv mobile.')
            comentario='\n\n'.join(encode)
            linkcomment = MainURL + 'comment.ajax.php?mediaType=' + tipo + '&mediaID=' + warezid
            parametros = {'comment': comentario}
            abrir_url_cookie(linkcomment,parametros)
            xbmc.executebuiltin("XBMC.Notification(wareztuga.tv,"+traducao(40208)+",'10000',"+iconpequeno.encode('utf-8')+")")
        else: xbmc.executebuiltin("XBMC.Notification(wareztuga.tv,"+traducao(40213)+",'10000',"+iconpequeno.encode('utf-8')+")")

            
def principal():
    if accao== 'visto': accaonosite(tipo,warezid,'watched')
    if accao== 'faved': accaonosite(tipo,warezid,'faved')
    if accao== 'cliped': accaonosite(tipo,warezid,'cliped')
    if accao== 'subscribed': accaonosite(tipo,warezid,'subscribed')
    if accao== 'comentarios': comentarios()
    if accao== 'comentar': comentar(tipo,warezid)
    if accao== 'votar': votar(tipo,warezid)
    if accao== 'trailer': trailer(warezid)
    if accao== 'interrompido':apagarinterrompido(tipo)
    if accao== 'reportar': reportarerro(tipo,warezid)

principal()
