# -*- coding: utf-8 -*-

""" Optimus Discos
    2013 fightnight
"""

import xbmc, xbmcgui, xbmcaddon, xbmcplugin,datetime,time,re,sys, urllib, urllib2

####################################################### CONSTANTES #####################################################

versao = '0.0.04'
addon_id = 'plugin.audio.optimusdiscos'
MainURL = 'http://optimusdiscos.pt/'
AlbumlistURL = 'player/albums.json'
TracklistURL = 'player/playlist/track.json'
vazio= []
art = '/resources/art/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
selfAddon = xbmcaddon.Addon(id=addon_id)
optimuspath = selfAddon.getAddonInfo('path')
menuescolha = xbmcgui.Dialog().select
mensagemok = xbmcgui.Dialog().ok
downloadPath = selfAddon.getSetting('download-folder')
PATH = "XBMC_OPTIMUS"
UATRACK="UA-40872520-1"

if selfAddon.getSetting('ga_visitor')=='':
    from random import randint
    selfAddon.setSetting('ga_visitor',str(randint(0, 0x7fffffff)))

def menu_principal():
      GA("None","menuprincipal")
      link=abrir_url(MainURL + AlbumlistURL)
      albuns=re.compile('{"is_downloadable".+?"album_id":"(.+?)".+?"artwork":"(.+?)".+?"description":"(.+?)".+?"album":"(.+?)".+?"artist":"(.+?)".+?"year":"(.+?)"').findall(link)
      for albumid,thumb,desc,albumname,artist,year in albuns:
            addAlbum('[B]' + artist + ' - ' + albumname + '[/B] (' + year + ')',albumid,1,thumb,1,True,desc,albumname,artist,year)
      disponivel=versao_disponivel()
      if disponivel==versao: addLink('Última versão instalada (' + versao+ ')','',"%s/resources/art/versao_inst.png"%selfAddon.getAddonInfo("path"))
      else: addDir('Instalada: ' + versao + ' | Actualização: ' + disponivel,MainURL,2,"%s/resources/art/versao_inst.png"%selfAddon.getAddonInfo("path"),1,False)
      xbmc.executebuiltin("Container.SetViewMode(500)")
      xbmcplugin.setContent(int(sys.argv[1]), 'albuns')
      
def lista_faixas(name,url):
      GA("None",name)
      link=abrir_url(MainURL + TracklistURL)
      cover=re.compile('{"is_downloadable".+?"album_id":"'+url+'".+?"artwork":"(.+?)".+?"downloadurl":"(.+?)"').findall(link)[0]
      addLink('[COLOR white]' + name + '[/COLOR]',url,cover[0])
      numeroref=int(0)
      tracks=re.compile('"album_id":"' + url + '".+?"track":"(.+?)".+?"name":"(.+?)"').findall(link)
      if len(tracks)!=1: addDir('[COLOR yellow][B]Reproduzir Todas[/B][/COLOR]',url,4,cover[0],1,False)
      addDir('[COLOR yellow][B]Download de Album[/B][/COLOR]',cover[1],5,cover[0],1,False)
      addLink("",'',cover[0])
      for downloadurl,trackname in tracks:
            numeroref=int(numeroref + 1)
            if len(tracks)!=1: numerostracks='#' + str(numeroref) + ' - '
            else:  numerostracks=''
            addDir(numerostracks + trackname,downloadurl + '-----'+url+'-----',3,cover[0],1,False)

def reproduzirtodas(name,url):
      dp = xbmcgui.DialogProgress()
      dp.create("Optimus Discos",'A criar a playlist.')
      dp.update(0)
      playlist = xbmc.PlayList(1)
      playlist.clear()
      link=abrir_url(MainURL + TracklistURL)
      numeroref=int(0)
      albuminfo=re.compile('{"is_downloadable".+?"album_id":"'+url+'".+?"artwork":"(.+?)".+?"album":"(.+?)".+?"artist":"(.+?)".+?"year":"(.+?)"').findall(link)[0]
      tracks=re.compile('"album_id":"' + url + '".+?"track":"(.+?)".+?"name":"(.+?)"').findall(link)
      for downloadurl,trackname in tracks:
            numeroref=int(numeroref + 1)
            if len(tracks)!=1: numerostracks='#' + str(numeroref) + ' - '
            else:  numerostracks=''
            liz=xbmcgui.ListItem(numerostracks + trackname, iconImage="DefaultVideo.png", thumbnailImage=albuminfo[0])
	    liz.setInfo('music', {'Title':numerostracks + trackname,'Album':albuminfo[1],'Artist':albuminfo[2],'Year':int(albuminfo[3])})
	    liz.setProperty('mimetype', 'audio/mpeg')                
	    playlist.add(downloadurl, liz)
	    progress = len(playlist) / float(len(tracks)) * 100               
	    dp.update(int(progress), 'A adicionar à playlist.')
	    if dp.iscanceled(): return
      dp.close()
      xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
      xbmcPlayer.play(playlist)


def playmusic(name,url):
      playlist = xbmc.PlayList(1)
      playlist.clear()
      url=re.compile('(.+?)-----(.+?)-----').findall(url)[0]
      link=abrir_url(MainURL + TracklistURL)
      albuminfo=re.compile('{"is_downloadable".+?"album_id":"'+url[1]+'".+?"artwork":"(.+?)".+?"album":"(.+?)".+?"artist":"(.+?)".+?"year":"(.+?)"').findall(link)[0]
      liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=albuminfo[0])
      liz.setInfo('music', {'Title':name,'Album':albuminfo[1],'Artist':albuminfo[2],'Year':int(albuminfo[3])})
      liz.setProperty('mimetype', 'audio/mpeg')                
      playlist.add(url[0], liz)
      xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
      xbmcPlayer.play(playlist)

def downloadzip(name,url):
      if downloadPath=='':
            ok = mensagemok('Optimus Discos','Escolhes uma pasta para fazer download.')
            selfAddon.openSettings()
      else:
            lib=os.path.join(downloadPath, 'album-optimus.zip')
            downloader(url,lib)
            pasta = xbmc.translatePath(os.path.join(downloadPath,''))
            xbmc.sleep(1000)
            dp = xbmcgui.DialogProgress()
            dp.create("Optimus Discos", "A extrair")
            import extract
            extract.all(lib,pasta,dp)
            os.remove(lib)

def downloader(url,dest, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create("Optimus Discos","A fazer download...",'')

    if useReq:
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled(): 
                raise Exception("Canceled")                
                dp.close()

            chunk = resp.read(size)
            if not chunk:            
                f.close()
                break

            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)       
    else:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Canceled")
        dp.close()



################################################## PASTAS ################################################################

def addLink(name,url,iconimage):
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
      return ok

def addDir(name,url,mode,iconimage,total,pasta):
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

def addAlbum(name,url,mode,iconimage,total,pasta,desc,albumname,artist,year):
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      liz.setInfo( type="Audio", infoLabels={ "Title": name, "Artist": artist } )
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

def abrir_url(url):
      req = urllib2.Request(url)
      req.add_header('User-Agent', user_agent)
      response = urllib2.urlopen(req)
      link=response.read()
      response.close()
      return link

def versao_disponivel():
      try:
          link=abrir_url('http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.audio.optimusdiscos/addon.xml')
          match=re.compile('name="Optimus Discos"\r\n       version="(.+?)"\r\n       provider-name="fightnight">').findall(link)[0]
      except:
          ok = mensagemok('Optimus Discos','Addon não conseguiu conectar ao servidor','de actualização. Verifique a situação.','')
          match='Erro. Verificar origem do erro.'
      return match

def get_params():
      param=[]
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                  params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                  splitparams={}
                  splitparams=pairsofparams[i].split('=')
                  if (len(splitparams))==2:
                        param[splitparams[0]]=splitparams[1]                 
      return param

def clean(text):
      command={'&nbsp;':' ','&quot;':'"','&#039;':'','&#39;':"'",'&atilde;':'ã','&ordf;':'ª','&eacute;':'é','&ccedil;':'ç','&oacute;':'ó','&acirc;':'â','&ntilde;':'ñ','&aacute;':'á','&iacute;':'í'}
      regex = re.compile("|".join(map(re.escape, command.keys())))
      return regex.sub(lambda mo: command[mo.group(0)], text)

def parseDate(dateString):
    try: return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except: return datetime.datetime.today() - datetime.timedelta(days = 1) #force update

def checkGA():
    secsInHour = 60 * 60
    threshold  = 2 * secsInHour
    now   = datetime.datetime.today()
    prev  = parseDate(selfAddon.getSetting('ga_time'))
    delta = now - prev
    nDays = delta.days
    nSecs = delta.seconds
    doUpdate = (nDays > 0) or (nSecs > threshold)
    if not doUpdate:
        return
    selfAddon.setSetting('ga_time', str(now).split('.')[0])
    APP_LAUNCH()    
    
                    
def send_request_to_google_analytics(utm_url):
    try:
        req = urllib2.Request(utm_url, None,{'User-Agent':user_agent})
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)         
    return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VISITOR = selfAddon.getSetting('ga_visitor')
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
        except:
            print "================  CANNOT POST TO ANALYTICS  ================" 
            
            
def APP_LAUNCH():
        versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
        if versionNumber < 12:
            if xbmc.getCondVisibility('system.platform.osx'):
                if xbmc.getCondVisibility('system.platform.atv2'):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
            elif xbmc.getCondVisibility('system.platform.ios'):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility('system.platform.windows'):
                log_path = xbmc.translatePath('special://home')
                log = os.path.join(log_path, 'xbmc.log')
                logfile = open(log, 'r').read()
            elif xbmc.getCondVisibility('system.platform.linux'):
                log_path = xbmc.translatePath('special://home/temp')
            else:
                log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        elif versionNumber > 11:
            print '======================= more than ===================='
            log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        else:
            logfile='Starting XBMC (Unknown Git:.+?Platform: Unknown. Built.+?'
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        print '==========================   '+PATH+' '+versao+'  =========================='
        try:
            from hashlib import md5
        except:
            from md5 import md5
        from random import randint
        import time
        from urllib import unquote, quote
        from os import environ
        from hashlib import sha1
        import platform
        VISITOR = selfAddon.getSetting('ga_visitor')
        for build, PLATFORM in match:
            if re.search('12',build[0:2],re.IGNORECASE): 
                build="Frodo" 
            if re.search('11',build[0:2],re.IGNORECASE): 
                build="Eden" 
            if re.search('13',build[0:2],re.IGNORECASE): 
                build="Gotham" 
            print build
            print PLATFORM
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + versao + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except:
                print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================" 
checkGA()

params=get_params()
url=None
name=None
mode=None
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
      print "Versao Instalada: v" + versao
      #menu_principal()
      ok = mensagemok('Optimus Discos','Fim do addon.','Desinstala este addon e instala o addon substituto','(Fightnight Music do repositorio)')
elif mode==1: lista_faixas(name,url)
elif mode==2: ok = mensagemok('Optimus Discos','A actualizacao é automatica. Caso nao actualize va ao','repositorio fightnight e prima c ou durante 2seg','e force a actualizacao. De seguida, reinicie o XBMC.')
elif mode==3: playmusic(name,url)
elif mode==4: reproduzirtodas(name,url)
elif mode==5: downloadzip(name,url)
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))
