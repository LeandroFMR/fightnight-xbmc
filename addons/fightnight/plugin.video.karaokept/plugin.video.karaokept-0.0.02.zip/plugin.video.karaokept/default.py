# -*- coding: utf-8 -*-

""" Karaoke Portugues
    2013 fightnight"""

import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,datetime,time

####################################################### CONSTANTES #####################################################

versao = '0.0.02'
addon_id = 'plugin.video.karaokept'
MainURL = 'http://abelhas.pt/'
art = '/resources/art/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36'
selfAddon = xbmcaddon.Addon(id=addon_id)
wtpath = selfAddon.getAddonInfo('path').decode('utf-8')
iconpequeno=wtpath + art + 'iconpqmudar.jpg'
traducaoma= selfAddon.getLocalizedString
mensagemok = xbmcgui.Dialog().ok
mensagemprogresso = xbmcgui.DialogProgress()
#downloadPath = selfAddon.getSetting('download-folder').decode('utf-8')
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile')).decode('utf-8')
pastafavoritos = os.path.join(pastaperfil, "favoritos")
cookies = os.path.join(pastaperfil, "cookies.lwp")
username = urllib.quote(selfAddon.getSetting('abelhas-username'))
password = selfAddon.getSetting('abelhas-password')
entrada='wbnb.fvyin333/Cevinqn/'
routinas1='Cnffjbeq'
routinas2='enzobvn'
PATH = ""            
UATRACK=""

def traducao(texto):
      return traducaoma(texto).encode('utf-8')


#################################################### LOGIN WAREZTUGA #####################################################

def login_abelhas():
      print "Sem cookie. A iniciar login"
      try:
            link=abrir_url(MainURL)
            token=re.compile('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />').findall(link)[0]
            from t0mm0.common.net import Net
            net=Net()
            form_d = {'RedirectUrl':'','Redirect':'True','FileId':0,'Login':username,'Password':password,'RememberMe':'true','__RequestVerificationToken':token}
            ref_data = {'Accept': '*/*', 'Content-Type': 'application/x-www-form-urlencoded','Origin': 'http://abelhas.pt', 'X-Requested-With': 'XMLHttpRequest', 'Referer': 'http://abelhas.pt/','User-Agent':user_agent}
            endlogin=MainURL + 'action/login/login'
            try:
                  logintest= net.http_POST(endlogin,form_data=form_d,headers=ref_data).content.encode('latin-1','ignore')
            except: logintest='Erro'
      except:
            link='Erro'
            logintest='Erro'

      if selfAddon.getSetting('abelhas-username')== '':
            ok = mensagemok('Karaoke Português',traducao(40000),traducao(40001))
            entrarnovamente(1)
      else:    
            if re.search('003eA senha indicada n',logintest):
                  mensagemok('Karaoke Português',traducao(40002))
                  entrarnovamente(1)
            elif re.search('existe. Certifica-te que indicaste o nome correcto.',logintest):
                  mensagemok('Karaoke Português',traducao(40003))
                  entrarnovamente(1)
            elif re.search(username,logintest):
                  xbmc.executebuiltin("XBMC.Notification(Karaoke Português,"+traducao(40004)+",'500000',"+iconpequeno.encode('utf-8')+")")
                  net.save_cookies(cookies)
                  conteudo=clean(abrir_url_cookie(MainURL + str(entrada.decode('rot13'))))
                  if re.search('ProtectedFolderChomikLogin',conteudo):
                        chomikid=re.compile('<input id="ChomikId" name="ChomikId" type="hidden" value="(.+?)" />').findall(conteudo)[0]
                        folderid=re.compile('<input id="FolderId" name="FolderId" type="hidden" value="(.+?)" />').findall(conteudo)[0]
                        foldername=re.compile('<input id="FolderName" name="FolderName" type="hidden" value="(.+?)" />').findall(conteudo)[0]
                        token=re.compile('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />').findall(conteudo)[0]

                        from t0mm0.common.net import Net
                        net=Net()
                        form_d = {'ChomikId':chomikid,'FolderId':folderid,'FolderName':foldername,str(routinas1.decode('rot13')):str(routinas2.decode('rot13')),'Remember':'true','__RequestVerificationToken':token}
                        ref_data = {'Accept':'*/*','Content-Type':'application/x-www-form-urlencoded','Host':'abelhas.pt','Origin':'http://abelhas.pt','Referer':url,'User-Agent':user_agent,'X-Requested-With':'XMLHttpRequest'}
                        endlogin=MainURL + 'action/Files/LoginToFolder'
                        teste= net.http_POST(endlogin,form_data=form_d,headers=ref_data).content.encode('latin-1','ignore')

                  listagem=abrir_url('http://fightnight-xbmc.googlecode.com/svn/karaoke/listagem.txt')
                  localizacao=os.path.join(pastaperfil,'listagem.txt')
                  try:os.remove(localizacao)
                  except: pass
                  savefile(pastaperfil,'listagem.txt',listagem)
                 
                  menu_principal(1)
            
            elif re.search('Erro',logintest) or link=='Erro':
                  opcao= xbmcgui.Dialog().yesno('Karaoke Português', traducao(40005), "", "",traducao(40006), 'OK')
                  if opcao: menu_principal(0)
                  else: login_abelhas()
                
################################################### MENUS PLUGIN ######################################################

def menu_principal(ligacao):
      if ligacao==1:
            addDir('Todas as Músicas','querotodasasmusicas',1,wtpath + art + 'filmes.png',1,True)
            addDir('Artistas',MainURL,4,wtpath + art + 'series.png',2,True)
            addDir('Mais recentes',MainURL,7,wtpath + art + 'series.png',2,True)
            addDir('Música directa (ID)',MainURL + username,3,wtpath + art + 'series.png',2,False)
            addDir('Favoritos','pastas',9,wtpath + art + 'series.png',2,True)
            #addDir('Pesquisar','pastas',5,wtpath + art + 'series.png',2,True)
            addLink("",'',wtpath + art + 'nothingx.png')
      elif ligacao==0:
            addDir(traducao(40015),MainURL,6,wtpath + art + 'refresh.png',1,True)
            addLink("",'',wtpath + art + 'nothingx.png')
      if ligacao==1:
            disponivel=versao_disponivel()
            if disponivel==versao: addLink(traducao(40017) + versao+ ')','',wtpath + art + 'versao_disp.png')
            else: addDir(traducao(40016) + versao + ' | ' + traducao(40019) + disponivel,MainURL,13,wtpath + art + 'versao_disp.png',1,False)
      else: addLink(traducao(40016) + versao,'',wtpath + art + 'versao_disp.png')
      addDir(traducao(40018) + " | [COLOR gold][B]Karaoke Portugues[/B][/COLOR]",MainURL,8,wtpath + art + 'defs.png',6,True)
      xbmc.executebuiltin("Container.SetViewMode(50)")


def todasasmusicas(url):
      listagem=openfile('listagem.txt')
      favoritos = os.listdir(pastafavoritos)
      
      if url=='querotodasasmusicas':
            musicas=re.compile('"id":"(.+?)","artist":"(.+?)","song":"(.+?)"').findall(listagem)
            for musicid,artist,song in musicas:
                  if musicid in favoritos: faved=True
                  else: faved=False
                  print faved
                  addCont(artist + ' - ' + song + ' ('+musicid+')',musicid,2,wtpath + art + 'series.png',len(musicas),faved,False)
      else:
            musicas=re.compile('"id":"(.+?)","artist":"'+url+'","song":"(.+?)"').findall(listagem)
            for musicid,song in musicas:
                  if musicid in favoritos: faved=True
                  else: faved=False
                  addCont(url + ' - ' + song + ' ('+musicid+')',musicid,2,wtpath + art + 'series.png',len(musicas),faved,False)

def artistas():
      listagem=openfile('listagem.txt')
      musicas=re.compile('"artist":"(.+?)"').findall(listagem)
      seen= set()
      seen_add = seen.add
      limpo= [ x for x in musicas if x not in seen and not seen_add(x)]
      for artistas in limpo:
            addDir(artistas,artistas,1,wtpath + art + 'series.png',len(limpo),True)

def ultimasadicionadas():
      conteudo=abrir_url_cookie(MainURL + str(entrada.decode('rot13')) + 'all?requestedFolderMode=filesList&fileListSortType=Date&fileListAscending=False')
      ultimas=re.compile('<span class="bold">(.+?)</span>').findall(conteudo)
      listagem=openfile('listagem.txt')
      favoritos = os.listdir(pastafavoritos)
      for referencias in ultimas:
            if referencias in favoritos: faved=True
            else: faved=False
            musicas=re.compile('"id":"'+referencias+'","artist":"(.+?)","song":"(.+?)"').findall(listagem)[0]
            addCont(musicas[0] + ' - ' + musicas[1] + ' ('+referencias+')',referencias,2,wtpath + art + 'series.png',len(ultimas),faved,False)


def musicadirecta():
      idname=caixadetexto(url).lower()
      listagem=openfile('listagem.txt')
      try:
            musicas=re.compile('"id":"'+idname+'","artist":"(.+?)","song":"(.+?)"').findall(listagem)[0]
            name=musicas[0] + ' - ' + musicas[1] + ' ('+idname+')'
            analyzer(idname,name)
      except:
            mensagemok('Karaoke Português','ID inválido.')

def favoritos():
      listagem=openfile('listagem.txt')
      listagem = unicode(listagem, errors='ignore')
      favoritos = os.listdir(pastafavoritos)
      for referencias in favoritos:
            if referencias in favoritos: faved=True
            else: faved=False
            musicas=re.compile('"id":"'+referencias+'","artist":"(.+?)","song":"(.+?)"').findall(listagem)[0]
            addCont(musicas[0] + ' - ' + musicas[1] + ' ('+referencias+')',referencias,2,wtpath + art + 'series.png',len(favoritos),faved,False)

def guardarfavoritos(url):
      if not os.path.exists(pastafavoritos):
          os.makedirs(pastafavoritos)

      savefile(pastafavoritos,url,'')
      xbmc.executebuiltin("XBMC.Notification(Karaoke Português,Adicionado aos favoritos,'500000',"+iconpequeno.encode('utf-8')+")")

def apagarfavoritos(url):
      favorito=os.path.join(pastafavoritos,url)
      os.remove(favorito)
      xbmc.executebuiltin("XBMC.Notification(Karaoke Português,Removido dos favoritos,'500000',"+iconpequeno.encode('utf-8')+")")
      xbmc.executebuiltin("Container.Refresh")
      
def entrarnovamente(opcoes):
      if opcoes==1: selfAddon.openSettings()
      addDir(traducao(40020),MainURL,None,wtpath + art + 'refresh.png',1,True)
      addDir(traducao(40021),MainURL,8,wtpath + art + 'defs.png',1,False)

########################################################### PLAYER ################################################

def analyzer(url,name):
      mensagemprogresso.create('Karaoke Português', traducao(40025))
      from t0mm0.common.net import Net
      net=Net()
      conteudo=abrir_url_cookie(MainURL + str(entrada.decode('rot13')) + 'all/' + url + '.mp4')
      try:
            fileid=re.compile('<input type="hidden" name="FileId" value="(.+?)"/>').findall(conteudo)[0]
            token=re.compile('<input name="__RequestVerificationToken" type="hidden" value="(.+?)" />').findall(conteudo)[0]
            form_d = {'fileId':fileid,'__RequestVerificationToken':token}
            ref_data = {'Accept': '*/*', 'Content-Type': 'application/x-www-form-urlencoded','Origin': 'http://abelhas.pt', 'X-Requested-With': 'XMLHttpRequest', 'Referer': 'http://abelhas.pt/','User-Agent':user_agent}
            endlogin=MainURL + 'action/License/Download'
            final= net.http_POST(endlogin,form_data=form_d,headers=ref_data).content.encode('latin-1','ignore')
      except:
            mensagemok('Karaoke Português','Ficheiro indisponivel.')
            
      try:
            linkfinal=re.compile('"redirectUrl":"(.+?)"').findall(final)[0]
            linkfinal=linkfinal.replace('\u0026','&')
      except:
            if re.search('Por favor tenta baixar este ficheiro mais tarde.',final):
                  mensagemok('Karaoke Português',traducao(40026))
                  return
            else:
                  linkfinal=''
                  mensagemok('Karaoke Português',traducao(40027))
                  return

      mensagemprogresso.close()
      comecarvideo(name,linkfinal)

def comecarvideo(name,url):
        thumbnail=wtpath + art + ''
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
        listitem.setInfo("Video", {"Title":name})
        listitem.setInfo("Music", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        dialogWait = xbmcgui.DialogProgress()
        dialogWait.create('Video', 'A carregar')
        playlist.add(url, listitem)
        dialogWait.close()
        del dialogWait
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
        
################################################## PASTAS ################################################################

def addLink(name,url,iconimage):
      liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def addDir(name,url,mode,iconimage,total,pasta):
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      liz=xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name} )
      liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

def addCont(name,url,mode,iconimage,total,faved,pasta):
      contexto=[]
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      liz=xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      if faved==False: contexto.append(('Adicionar aos favoritos', 'XBMC.RunPlugin(%s?mode=10&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
      else: contexto.append(('Remover dos favoritos', 'XBMC.RunPlugin(%s?mode=11&url=%s&name=%s)' % (sys.argv[0], urllib.quote_plus(url),name)))
      liz.setInfo( type="Video", infoLabels={ "Title": name} )
      liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
      liz.addContextMenuItems(contexto, replaceItems=True) 
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

######################################################## OUTRAS FUNCOES ###############################################

def savefile(caminho,filename, contents):
    try:
        destination = os.path.join(caminho, filename)
        fh = open(destination, 'wb')
        fh.write(contents)  
        fh.close()
    except: print "Nao gravou o marcador de: %s" % filename

def openfile(filename):
    try:
        destination = os.path.join(pastaperfil, filename)
        fh = open(destination, 'rb')
        contents=fh.read()
        fh.close()
        return contents
    except:
        print "Nao abriu o marcador de: %s" % filename
        return None

def format_time(seconds):
	minutes,seconds = divmod(seconds, 60)
	if minutes > 60:
		hours,minutes = divmod(minutes, 60)
		return "%02d:%02d:%02d" % (hours, minutes, seconds)
	else:
		return "%02d:%02d" % (minutes, seconds)

def caixadetexto(url):
      title="Introduza o ID - Karaoke Português"
      keyb = xbmc.Keyboard(selfAddon.getSetting('ultima-pesquisa'), title)
      keyb.doModal()
      if (keyb.isConfirmed()):
            search = keyb.getText()
            if search=='': sys.exit(0)
            encode=urllib.quote_plus(search)
            return encode
            
      else: sys.exit(0)
            
def abrir_url(url):
      req = urllib2.Request(url)
      req.add_header('User-Agent', user_agent)
      response = urllib2.urlopen(req)
      link=response.read()
      response.close()
      return link

def abrir_url_cookie(url,erro=True):
      from t0mm0.common.net import Net
      net=Net()
      net.set_cookies(cookies)
      try:
            ref_data = {'Host': 'abelhas.pt', 'Connection': 'keep-alive', 'Referer': 'http://abelhas.pt/','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8','User-Agent':user_agent,'Referer': 'http://abelhas.pt/'}
            link=net.http_GET(url,ref_data).content.encode('latin-1','ignore')
            return link
      except urllib2.HTTPError, e:
            if erro==True: mensagemok('Karaoke Português',str(urllib2.HTTPError(e.url, e.code, traducao(40032), e.hdrs, e.fp)),traducao(40033))
            sys.exit(0)
      except urllib2.URLError, e:
            if erro==True: mensagemok('Karaoke Português',traducao(40032)+traducao(40033))
            sys.exit(0)
            
def versao_disponivel():
      try:
            link=abrir_url('http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.video.karaokept/addon.xml')
            match=re.compile('name="Karaoke Portugues"\r\n       version="(.+?)"\r\n       provider-name="fightnight">').findall(link)[0]
      except:
            ok = mensagemok('Karaoke Português',traducao(40034),traducao(40035),'')
            match=traducao(40036)
      return match

def handle_wait(time_to_wait,title,text):
      ret = mensagemprogresso.create(' '+title)
      secs=0
      percent=0
      increment = int(100 / time_to_wait)
      cancelled = False
      while secs < time_to_wait:
            secs = secs + 1
            percent = increment*secs
            secs_left = str((time_to_wait - secs))
            remaining_display = 'Aguarda '+secs_left+' segundos para terminar.'
            mensagemprogresso.update(percent,' '+text,remaining_display)
            xbmc.sleep(1000)
            if (mensagemprogresso.iscanceled()):
                  cancelled = True
                  break
      if cancelled == True:
            return False
      else:
            return True

def redirect(url):
      req = urllib2.Request(url)
      req.add_header('User-Agent', user_agent)
      response = urllib2.urlopen(req)
      gurl=response.geturl()
      return gurl

def millis():
      import time as time_
      return int(round(time_.time() * 1000))

def load_json(data):
      def to_utf8(dct):
            rdct = {}
            for k, v in dct.items() :
                  if isinstance(v, (str, unicode)) :
                        rdct[k] = v.encode('utf8', 'ignore')
                  else :
                        rdct[k] = v
            return rdct
      try :        
            from lib import simplejson
            json_data = simplejson.loads(data, object_hook=to_utf8)
            return json_data
      except:
            try:
                  import json
                  json_data = json.loads(data, object_hook=to_utf8)
                  return json_data
            except:
                  import sys
                  for line in sys.exc_info():
                        print "%s" % line
      return None

def get_params():
      param=[]
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                  params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                  splitparams={}
                  splitparams=pairsofparams[i].split('=')
                  if (len(splitparams))==2:
                        param[splitparams[0]]=splitparams[1]                 
      return param

def clean(text):
      command={'\r':'','\n':'','\t':'','&nbsp;':' ','&quot;':'"','&#039;':'','&#39;':"'",'&#227;':'ã','&170;':'ª','&#233;':'é','&#231;':'ç','&#243;':'ó','&#226;':'â','&ntilde;':'ñ','&#225;':'á','&#237;':'í','&#245;':'õ','&#201;':'É','&#250;':'ú','&amp;':'&','&#193;':'Á','&#195;':'Ã','&#202;':'Ê','&#199;':'Ç','&#211;':'Ó','&#213;':'Õ','&#212;':'Ó','&#218;':'Ú'}
      regex = re.compile("|".join(map(re.escape, command.keys())))
      return regex.sub(lambda mo: command[mo.group(0)], text)

def parseDate(dateString):
      try: return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
      except: return datetime.datetime.today() - datetime.timedelta(days = 1) #force update

def checkGA():
      secsInHour = 60 * 60
      threshold  = 2 * secsInHour
      now   = datetime.datetime.today()
      prev  = parseDate(selfAddon.getSetting('ga_time2'))
      delta = now - prev
      nDays = delta.days
      nSecs = delta.seconds
      doUpdate = (nDays > 0) or (nSecs > threshold)
      if not doUpdate: return
      selfAddon.setSetting('ga_time2', str(now).split('.')[0])
      APP_LAUNCH() 
                    
def send_request_to_google_analytics(utm_url):
      try:
            req = urllib2.Request(utm_url, None, {'User-Agent':user_agent})
            response = urllib2.urlopen(req).read()
      except: print ("GA fail: %s" % utm_url)         
      return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            #VISITOR = ADDON.getSetting('ga_visitor')
            VISITOR = environ.get("GA_VISITOR", username)
            VISITOR = str(int("0x%s" % sha1(VISITOR).hexdigest(), 0))[:10]
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
        except: print "================  CANNOT POST TO ANALYTICS  ================" 
            
def APP_LAUNCH():
        print '==========================   '+PATH+' '+versao+'   =========================='
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            import platform
            VISITOR = environ.get("GA_VISITOR", username)
            VISITOR = str(int("0x%s" % sha1(VISITOR).hexdigest(), 0))[:10]
            if re.search('12.0',xbmc.getInfoLabel( "System.BuildVersion"),re.IGNORECASE) or re.search('12.1',xbmc.getInfoLabel( "System.BuildVersion"),re.IGNORECASE): build="Frodo" 
            if re.search('11.0',xbmc.getInfoLabel( "System.BuildVersion"),re.IGNORECASE): build="Eden" 
            if re.search('13.0',xbmc.getInfoLabel( "System.BuildVersion"),re.IGNORECASE): build="Gotham"
            try: PLATFORM=platform.system()+' '+platform.release()
            except: PLATFORM=platform.system()
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + versao + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+PATH+"-"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except: print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================" 
        except: print "================  CANNOT POST TO ANALYTICS  ================"
checkGA()
            
params=get_params()
url=None
name=None
mode=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
      print "Versao Instalada: v" + versao
      login_abelhas()
elif mode==1: todasasmusicas(url)
elif mode==2: analyzer(url,name)
elif mode==3: musicadirecta()
elif mode==4: artistas()
elif mode==5: caixadetexto(url)
elif mode==6: login_abelhas()
elif mode==7: ultimasadicionadas()
elif mode==8: selfAddon.openSettings()#sacarficheiros()
elif mode==9: favoritos()
elif mode==10: guardarfavoritos(url)
elif mode==11: apagarfavoritos(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
