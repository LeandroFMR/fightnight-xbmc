# -*- coding: utf-8 -*-

""" Séries Portuguesas
    2014 fightnight"""

import xbmcgui,xbmcplugin

def addLink(name,url,iconimage):
      liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      liz.addContextMenuItems([], replaceItems=True) 
      return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

addLink('Fim do addon.','','')
addLink('Ira voltar noutros moldes.','','')
addLink('Aguardem.','','')

xbmcplugin.endOfDirectory(int(sys.argv[1]))
