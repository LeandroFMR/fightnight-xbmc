# -*- coding: utf-8 -*-

""" Sapo Videos
    2013 fightnight
"""

import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys

####################################################### CONSTANTES #####################################################

versao = '0.0.04'
addon_id = 'plugin.video.sapo'
MainURL = 'http://videos.sapo.pt/'
vazio= []
art = '/resources/art/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:10.0a1) Gecko/20111029 Firefox/10.0a1'
selfAddon = xbmcaddon.Addon(id=addon_id)
sapopath = selfAddon.getAddonInfo('path')
mensagemok = xbmcgui.Dialog().ok

def menu_principal():
      addDir("Tops",MainURL,1,'',1)
      addDir("Categorias",MainURL,3,'',1)
      addDir("Pesquisar",MainURL,4,'',1)
      addLink("",'','')
      disponivel=versao_disponivel()
      if disponivel==versao: addLink('Última versao instalada (' + versao+ ')','','')
      else: addDir('Instalada v' + versao + ' | Actualização v' + disponivel,MainURL,4,'',1)

def pesquisa():
      keyb = xbmc.Keyboard('', 'Sapo Vídeos')
      keyb.doModal()
      if (keyb.isConfirmed()):
            search = keyb.getText()
            if search=='': sys.exit(0)
            encode=urllib.quote(search)
            urlfinal='http://videos.sapo.pt/ajax/search.php?word=' + encode + '&order=releve&version=2&epages=60'
            request(urlfinal)


def tops():
      addDir("Mais recentes",MainURL + 'ultimos.html',6,'',1)
      addDir("Mais votados",MainURL + 'votes.html',6,'',1)
      addDir("Mais vistos de hoje",MainURL + 'top.html',6,'',1)
      addDir("Mais vistos da última semana",MainURL + 'top.html?type=week',6,'',1)
      addDir("Mais vistos do último mês",MainURL + 'top.html?type=month',6,'',1)
      addDir("Mais vistos de sempre",MainURL + 'top.html?type=all',6,'',1)

def categorias():
      link=abrir_url(url)
      categorias=re.compile('<a href="http://videos.sapo.pt/categoria.html.+?id=(.+?)" >(.+?)</a>').findall(link)
      for end,nome in categorias:
            addDir(nome,'http://videos.sapo.pt/ajax/videos_cat.php?epages=60&order=news&catid=' + end,6,'',1)
            

def request(url):
      link=abrir_url(url)
      link=clean(link)
      videos=re.compile("titlelong:'(.+?)'.+?randname:'(.+?)'.+?img:'(.+?)'").findall(link)
      for titulo,idend,thumb in videos:
            pastastream(titulo,MainURL + idend,5,thumb,len(videos))
            
def captura(name,url):
      link=abrir_url(url)
      thumb=re.compile('<meta property="og:image" content="(.+?)"/>').findall(link)[0]
      username=re.compile("var usermrec='(.+?)'").findall(link)[0]
      try:
            endereco=re.compile('file=(.+?)&').findall(link)[0]
      except:
            link=abrir_url(url + '/rss2')
            video=re.compile('<media:content url="(.+?)/pic/').findall(link)[0]
            endereco = video + '/mov'
      finalurl=redirect(endereco)
      comecarvideo(name,finalurl,username,thumb)


def comecarvideo(titulo,url,username,thumb):
      playlist = xbmc.PlayList(1)
      playlist.clear()
      listitem = xbmcgui.ListItem(titulo, iconImage="DefaultVideo.png", thumbnailImage=thumb)            
      listitem.setInfo("Video", {"Title":titulo, "TVShowTitle": username[0]})
      listitem.setProperty('mimetype', 'video/x-msvideo')
      listitem.setProperty('IsPlayable', 'true')
      dialogWait = xbmcgui.DialogProgress()
      dialogWait.create('Sapo Videos', 'A carregar')
      playlist.add(url, listitem)
      dialogWait.close()
      del dialogWait
      xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
      xbmcPlayer.play(playlist)

################################################## PASTAS ################################################################

def addLink(name,url,iconimage):
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
      return ok

def pastastream(name,url,mode,iconimage,total):
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=total)
      cm = []
      cm.append(('',''))
      liz.addContextMenuItems(cm, replaceItems=True)                      
      return ok

def addDir(name,url,mode,iconimage,total):
      u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
      ok=True; liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
      liz.setInfo( type="Video", infoLabels={ "Title": name } )
      ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=total)
      return ok

def abrir_url(url):
      req = urllib2.Request(url)
      req.add_header('User-Agent', user_agent)
      response = urllib2.urlopen(req)
      link=response.read()
      response.close()
      return link

def versao_disponivel():
      try:
            link=abrir_url('http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.video.sapo/addon.xml')
            match=re.compile('name="Sapo Videos"\r\n       version="(.+?)"\r\n       provider-name="fightnight">').findall(link)[0]
      except:
            ok = mensagemok('Sapo Videos','Addon não conseguiu conectar ao servidor','de actualização. Verifique a situação.','')
            match='Erro. Verificar origem do erro.'      
      return match


def redirect(url):
      req = urllib2.Request(url)
      req.add_header('User-Agent', user_agent)
      response = urllib2.urlopen(req)
      gurl=response.geturl()
      return gurl

def get_params():
      param=[]
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                  params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                  splitparams={}
                  splitparams=pairsofparams[i].split('=')
                  if (len(splitparams))==2:
                        param[splitparams[0]]=splitparams[1]                 
      return param

def clean(text):
      command={'&nbsp;':' ','&quot;':'"','&#039;':''}
      regex = re.compile("|".join(map(re.escape, command.keys())))
      return regex.sub(lambda mo: command[mo.group(0)], text)


params=get_params()
url=None
name=None
mode=None
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
      print "Versao Instalada: v" + versao
      menu_principal()
        
elif mode==1: tops()
elif mode==2: canais()
elif mode==3: categorias()
elif mode==4: pesquisa()
elif mode==5: captura(name,url)
elif mode==6: request(url)
  
xbmcplugin.endOfDirectory(int(sys.argv[1]))
