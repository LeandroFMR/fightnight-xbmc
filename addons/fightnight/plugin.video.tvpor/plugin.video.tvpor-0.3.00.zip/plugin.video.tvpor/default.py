from resources.lib import main

try:
    myAddon = main.Main()
    myAddon.run()
except:
    import sys, traceback
    traceback.print_exc(file = sys.stdout)
