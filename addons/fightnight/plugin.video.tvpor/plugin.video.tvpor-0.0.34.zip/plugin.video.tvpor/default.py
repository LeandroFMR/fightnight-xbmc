# -*- coding: utf-8 -*-

""" TV Portuguesa
    2013 fightnight"""

import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re,sys, urllib, urllib2,time,datetime

versao = '0.0.34'
SptveuURL = 'http://thesporttv.eu/'
WiimovURL='http://www.wiimov.org'
TVDezURL = 'http://www.estadiofutebol.com'
#TVTugaURL = 'http://www.tvtuga.com'
TugastreamURL = 'http://www.tugastream.com/'
TVPTHDURL = 'http://www.tvportugalhd.org'
TVPTHDZuukURL = 'http://www.zuuk.pw'
TVCoresURL = 'http://tvfree4.me'
TVZuneURL = 'http://www.tvzune.com/'
VBURL= 'http://www.videosbacanas.com/'
ResharetvURL = 'http://resharetv.com/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36'
addon_id = 'plugin.video.tvpor'
art = '/resources/art/'
selfAddon = xbmcaddon.Addon(id=addon_id)
tvporpath = selfAddon.getAddonInfo('path')
mensagemok = xbmcgui.Dialog().ok
menuescolha = xbmcgui.Dialog().select
mensagemprogresso = xbmcgui.DialogProgress()
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile'))
PATH = "XBMC_TVPOR"
UATRACK="UA-39199007-1"

#try:
if selfAddon.getSetting('ga_visitor')=='':
    from random import randint
    selfAddon.setSetting('ga_visitor',str(randint(0, 0x7fffffff)))

def menu_principal():
    GA("None","menuprincipal")
    if selfAddon.getSetting("mensagemfb2") == "true":
        ok = mensagemok('TV Portuguesa','Faz like na pagina do facebook para','obteres todas as novidades.','http://fb.com/fightnightxbmc')
        selfAddon.setSetting('mensagemfb2',value='false')
    addDir("Ver Canais",TVDezURL,13,tvporpath + art + 'vercanais-ver2.png',1,True)
    disponivel=versao_disponivel()
    if disponivel==versao: addLink('Última versao (' + versao+ ')','',tvporpath + art + 'versao-ver2.png')
    else: addDir('Instalada v' + versao + ' | Actualização v' + disponivel,TVDezURL,15,tvporpath + art + 'versao-ver2.png',1,False)
    addDir("Definições do addon",TVDezURL,22,tvporpath + art + 'defs-ver2.png',1,False)
    addDir("[COLOR red][B]LER AVISO[/B][/COLOR]",'nada',23,tvporpath + art + 'aviso-ver2.png',1,False)
    xbmc.executebuiltin("Container.SetViewMode(500)")

def abrir_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def abrir_url_cookie(url):
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
    link = opener.open(url).read()
    return link

def versao_disponivel():
    try:
        link=abrir_url('http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.video.tvpor/addon.xml')
        match=re.compile('name="TV Portuguesa"\r\n       version="(.+?)"\r\n       provider-name="fightnight">').findall(link)[0]
    except:
        ok = mensagemok('TV Portuguesa','Addon não conseguiu conectar ao servidor','de actualização. Verifique a situação.','')
        match='Erro. Verificar origem do erro.'
    return match

def savefile(filename, contents):
    try:
        destination = os.path.join(pastaperfil, filename)
        fh = open(destination, 'wb')
        fh.write(contents)  
        fh.close()
    except: print "Nao gravou os temporarios de: %s" % filename

def openfile(filename):
    try:
        destination = os.path.join(pastaperfil, filename)
        fh = open(destination, 'rb')
        contents=fh.read()
        fh.close()
        return contents
    except:
        print "Nao abriu os temporarios de: %s" % filename
        return None

def listascanais():
    addDir("[B]Cesarix[/B]: Ciências",'http://dl.dropbox.com/u/74834278/Tv%20Ciencia.xml',5,tvporpath + art + 'listas-ver2.png',1,True)
    addDir("[B]Cesarix[/B]: Desporto",'http://dl.dropbox.com/u/74834278/Desporto.xml',5,tvporpath + art + 'listas-ver2.png',1,True)
    addDir("[B]Cesarix[/B]: Estrangeiro",'http://dl.dropbox.com/u/74834278/Canais%20Estrangeiros.xml',5,tvporpath + art + 'listas-ver2.png',1,True)
    addDir("[B]Pissos13[/B]: Global",'http://dl.dropbox.com/u/88295111/pissos13.xml',5,tvporpath + art + 'listas-ver2.png',1,True)
    addLink("",'',tvporpath + art + 'listas-ver2.png')
    addLink("[B][COLOR white]Queres adicionar a tua lista (XML)?[/COLOR][/B]",'',tvporpath + art + 'listas-ver2.png')
    addLink("Visita [B]http://bit.ly/fightnightaddons[/B]",'',tvporpath + art + 'listas-ver2.png')
    addLink('ou contacta "fightnight.addons@gmail.com"','',tvporpath + art + 'listas-ver2.png')

def downloader(url,dest, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create("TV Portuguesa","A fazer download...",'')

    if useReq:
        import urllib2
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled(): 
                raise Exception("Canceled")                
                dp.close()

            chunk = resp.read(size)
            if not chunk:            
                f.close()
                break

            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)       
    else:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Canceled")
        dp.close()

def xmltostrm(name,url):
    link=abrir_url(url)
    print link
    nomestreamfile='streamxml.strm'
    #savefile(nomestreamfile, 'plugin://plugin.video.veetle/?channel=' + chname)
    savefile(nomestreamfile, link)
    streamfile = os.path.join(pastaperfil, nomestreamfile)
    xbmc.executebuiltin("XBMC.RunPlugin(" + link+ ")")
    #print streamfile
    #comecarvideo(streamfile,name,True)
    

def obter_lista(name,url):
    GA("None",name)
    link=abrir_url(url)
    link2=clean(link)
    listas=re.compile('<title>(.+?)</title>(.+?)<thumbnail>(.+?)</thumbnail>').findall(link2)
    for nomecanal,streams,thumb in listas:
        streams2=re.compile('<link>(.+?)</link>').findall(streams)
        for rtmp in streams2:
            if re.search('.strm',rtmp):
                addDir(nomecanal,rtmp,11,thumb,1,False)
                print "HEY"
            else:
                addLink(nomecanal,rtmp,thumb)

def abrir_lista_canais():
    info_servidores()
    canais()

def canais():
    nrcanais=30
    empty='nada'
    GA("None","listacanais")
    if selfAddon.getSetting("abrirlogolista") == "true":
        if selfAddon.getSetting("abrirlogolista-botao") == "true": addDir("[B]Menu Principal[/B]",TVDezURL,1,tvporpath + art + 'defs-ver2.png',1,True)
    #####
    if selfAddon.getSetting("restarttv") == "true": addDir("[B]Restart TV[/B]",TVDezURL,2,tvporpath + art + 'restart-ver2.png',1,True)
    if selfAddon.getSetting("listas-pessoais") == "true": addDir("[B]Listas Pessoais[/B]",TVDezURL,6,tvporpath + art + 'listas-ver2.png',1,True)
    if selfAddon.getSetting("canais-optimusalive") == "true": addDir("[B]Optimus Alive 2013[/B] " + programacao('RTP1',False),empty,16,tvporpath + art + 'alive-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-rtp1") == "true": addDir("[B]RTP 1[/B] " + programacao('RTP1',False),empty,16,tvporpath + art + 'rtp1-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-rtp2") == "true": addDir("[B]RTP 2[/B] " + programacao('RTP2',False),empty,16,tvporpath + art + 'rtp2-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sic") == "true": addDir("[B]SIC[/B] " + programacao('SIC',False),empty,16,tvporpath + art + 'sic-ver3.png',nrcanais,False)
    if selfAddon.getSetting("canais-tvi") == "true": addDir("[B]TVI[/B] " + programacao('TVI',False),empty,16,tvporpath + art + 'tvi-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sporttv1") == "true":
        addDir("[B]SPORTTV 1[/B] " + programacao('SPTV1',False),empty,16,tvporpath + art + 'sptv1-ver2.png',nrcanais,False)
        addDir("[B]SPORTTV 1 HD[/B]" + programacao('SPTV1',False),empty,16,tvporpath + art + 'sptvhd-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sporttv2") == "true": addDir("[B]SPORTTV 2[/B] " + programacao('SPTV2',False),empty,16,tvporpath + art + 'sptv2-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sporttv3") == "true": addDir("[B]SPORTTV 3[/B] " + programacao('SPTV3',False),empty,16,tvporpath + art + 'sptv3-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sporttv4") == "true": addDir("[B]SPORTTV 4[/B] " + programacao('SPTV4',False),empty,16,tvporpath + art + 'sptv4-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-bigbrothervip") == "true": addDir("[B]Big Brother VIP[/B] " + programacao('BBV',False),empty,16,tvporpath + art + 'bbvip-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sick") == "true": addDir("[B]SIC K[/B] " + programacao('SICK',False),empty,16,tvporpath + art + 'sick-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sicmulher") == "true": addDir("[B]SIC Mulher[/B] " + programacao('SICM',False),empty,16,tvporpath + art + 'sicm-ver3.png',nrcanais,False)
    if selfAddon.getSetting("canais-sicnoticias") == "true": addDir("[B]SIC Noticias[/B] " + programacao('SICN',False),empty,16,tvporpath + art + 'sicn-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-sicradical") == "true": addDir("[B]SIC Radical[/B] " + programacao('SICR',False),empty,16,tvporpath + art + 'sicrad-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-tvi24") == "true": addDir("[B]TVI24[/B] " + programacao('TVI24',False),empty,16,tvporpath + art + 'tvi24-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-tvificcao") == "true": addDir("[B]TVI Ficção[/B] " + programacao('TVIF',False),empty,16,tvporpath + art + 'tvif-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-maistvi") == "true": addDir("[B]Mais TVI[/B] " + programacao('MTVI',False),empty,16,tvporpath + art + 'maistvi-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-hollywood") == "true": addDir("[B]Hollywood[/B] " + programacao('HOLLW',False),empty,16,tvporpath + art + 'hwd-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-mov") == "true": addDir("[B]MOV[/B] " + programacao('MOV',False),empty,16,tvporpath + art + 'mov-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-axn") == "true": addDir("[B]AXN[/B] " + programacao('AXN',False),empty,16,tvporpath + art + 'axn-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-axnblack") == "true": addDir("[B]AXN Black[/B] " + programacao('AXNBL',False),empty,16,tvporpath + art + 'axnb-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-axnwhite") == "true": addDir("[B]AXN White[/B] " + programacao('AXNWH',False),empty,16,tvporpath + art + 'axnw-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-fox") == "true": addDir("[B]FOX[/B] " + programacao('FOX',False),empty,16,tvporpath + art + 'fox-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-foxcrime") == "true": addDir("[B]FOX Crime[/B] " + programacao('FOXCR',False),empty,16,tvporpath + art + 'foxc-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-foxlife") == "true": addDir("[B]FOX Life[/B] " + programacao('FLIFE',False),empty,16,tvporpath + art + 'foxl-ver3.png',nrcanais,False)
    if selfAddon.getSetting("canais-foxmovies") == "true": addDir("[B]FOX Movies[/B] " + programacao('FOXM',False),empty,16,tvporpath + art + 'foxm-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-syfy") == "true": addDir("[B]Syfy[/B] " + programacao('SYFY',False),empty,16,tvporpath + art + 'syfy-ver1.png',nrcanais,False)
    if selfAddon.getSetting("canais-cpanda") == "true": addDir("[B]Canal Panda[/B] " + programacao('PANDA',False),empty,16,tvporpath + art + 'panda-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-discovery") == "true": addDir("[B]Discovery Channel[/B] " + programacao('DISCV',False),empty,16,tvporpath + art + 'disc-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-odisseia") == "true": addDir("[B]Odisseia[/B] " + programacao('ODISS',False),empty,16,tvporpath + art + 'odisseia-ver1.png',nrcanais,False)
    if selfAddon.getSetting("canais-historia") == "true": addDir("[B]História[/B] " + programacao('HIST',False),empty,16,tvporpath + art + 'historia-ver1.png',nrcanais,False)
    if selfAddon.getSetting("canais-ngc") == "true": addDir("[B]National Geographic Channel[/B] " + programacao('NGC',False),empty,16,tvporpath + art + 'natgeo-ver1.png',nrcanais,False)
    if selfAddon.getSetting("canais-eurosport") == "true": addDir("[B]Eurosport[/B] " + programacao('EURSP',False),empty,16,tvporpath + art + 'eusp-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-vh1") == "true": addDir("[B]VH1[/B] " + programacao('VH1',False),empty,16,tvporpath + art + 'vh1-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-mtv") == "true": addDir("[B]MTV[/B] " + programacao('MTV',False),empty,16,tvporpath + art + 'mtv-ver1.png',nrcanais,False)
    #if selfAddon.getSetting("canais-benficatv") == "true": addDir("[B]Benfica TV[/B] " + programacao('SLB',False),empty,16,tvporpath + art + 'bentv-ver2.png',nrcanais,False)
    if selfAddon.getSetting("canais-portocanal") == "true": addDir("[B]Porto Canal[/B] " + programacao('PORTO',False),empty,16,tvporpath + art + 'pcanal-ver2.png',nrcanais,False)
    xbmc.executebuiltin("Container.SetViewMode(500)")
    #xbmcplugin.setContent(int(sys.argv[1]), 'movies')
'''
    addDir("[B]A Bola TV[/B] " + programacao('BOLA',False),empty,16,'',nrcanais,False)
    addDir("[B]Chelsea TV[/B] " + programacao('CHELS',False),empty,16,'',nrcanais,False)
    addDir("[B]Discovery Turbo[/B] " + programacao('DISCT',False),empty,16,'',nrcanais,False)
    addDir("[B]Disney Channel[/B] " + programacao('DISNY',False),empty,16,'',nrcanais,False)
    addDir("[B]Disney Junior[/B] " + programacao('DISNJ',False),empty,16,'',nrcanais,False)
    addDir("[B]Económico TV[/B] " + programacao('ECONO',False),empty,16,'',nrcanais,False)
    addDir("[B]ESPN America[/B] " + programacao('ESPNA',False),empty,16,'',nrcanais,False)
    addDir("[B]ESPN Classic[/B] " + programacao('ESPN',False),empty,16,'',nrcanais,False)
    addDir("[B]Eurosport 2[/B] " + programacao('EURS2',False),empty,16,'',nrcanais,False)
    addDir("[B]Fashion TV[/B] " + programacao('FASH',False),empty,16,'',nrcanais,False)
    addDir("[B]Fuel TV[/B] " + programacao('FUEL',False),empty,16,'',nrcanais,False)
    addDir("[B]Motors TV[/B] " + programacao('MOTOR',False),empty,16,'',nrcanais,False)
    addDir("[B]Nickelodeon[/B] " + programacao('NICK',False),empty,16,'',nrcanais,False)
    addDir("[B]Panda Biggs[/B] " + programacao('PANDAB',False),empty,16,'',nrcanais,False)
    #addDir("[B]RTP Açores[/B] " + programacao('RTPAC',False),empty,16,'',nrcanais,False)
    #addDir("[B]RTP Informação[/B] " + programacao('RTPIN',False),empty,16,'',nrcanais,False)
    #addDir("[B]RTP Internacional[/B] " + programacao('RTPINT',False),empty,16,'',nrcanais,False)
    #addDir("[B]RTP Madeira[/B] " + programacao('RTPMD',False),empty,16,'',nrcanais,False)
    #addDir("[B]RTP Memória[/B] " + programacao('RTPM',False),empty,16,'',nrcanais,False)
    addDir("[B]SBT[/B] " + programacao('SBT',False),empty,16,'',nrcanais,False)
    addDir("[B]TLC[/B] " + programacao('TLC',False),empty,16,'',nrcanais,False)
    addDir("[B]TV Globo[/B] " + programacao('GLOBO',False),empty,16,'',nrcanais,False)
    addDir("[B]TV Record[/B] " + programacao('TVrec',False),empty,16,'',nrcanais,False)
    #addDir("[COLOR blue][B]Nr. de canais:[/B][/COLOR]" + nrcanais,'',16,'',nrcanais,False)
'''      

#################################### RESTART TV ##################
def restarttv():
    nrcanais=5
    GA("None","Restart TV")
    if selfAddon.getSetting("mensagemrestart") == "true":
            ok = mensagemok('TV Portuguesa','Serviço disponibilizado por Vídeos Bacanas.','Visita o site oficial.','http://www.videosbacanas.com/')
            selfAddon.setSetting('mensagemrestart',value='false')
    addDir("[B]RTP[/B]","RTP",3,tvporpath + art + 'rtp1-ver2.png',nrcanais,True)
    addDir("[B]SIC[/B]","SIC",3,tvporpath + art + 'sic-ver3.png',nrcanais,True)
    addDir("[B]SIC Noticias[/B]","SIC Notícias",3,tvporpath + art + 'sicn-ver2.png',nrcanais,True)
    addDir("[B]TVI[/B]","TVI",3,tvporpath + art + 'tvi-ver2.png',nrcanais,True)
    addDir("[B]TVI24[/B]","TVI 24",3,tvporpath + art + 'tvi24-ver2.png',nrcanais,True)
    addDir("[B]Pesquisa[/B]","Pesquisa",10,tvporpath + art + 'pesquisa-ver2.png',nrcanais,True)
    xbmc.executebuiltin("Container.SetViewMode(500)")

def restarttv_lista(name,url):
    GA("Restart TV",url)
    link=abrir_url(VBURL)
    link=clean(link)
    infocanal=re.compile('<a href="#">'+url+'</a><ul class="sub-menu">(.+?)</ul>').findall(link)[0]
    programas=re.compile('<li class=""><a title=".+?" href="(.+?)">(.+?)</a></li>').findall(infocanal)
    programas+=re.compile('<li class=""><a href="(.+?)">(.+?)</a></li>').findall(infocanal)
    #if not programas: programas=re.compile('<li class=""><a href="(.+?)">(.+?)</a></li>').findall(infocanal)
    for endereco,nomeprog in programas:
        addDir(nomeprog,endereco,4,tvporpath + art + 'restart-ver2.png',len(programas),True)

def restarttv_progs(name,url):
    link=abrir_url(url)
    link=link.replace('&#8211;','-').replace('&#8216;','').replace('&#8217;','')
    progs=re.compile('<h2><a href="(.+?)" title="(.+?)">').findall(link)
    for endereco,nomeprog in progs:
        addDir(nomeprog,endereco,8,tvporpath + art + 'restart-ver2.png',len(progs),False)
    restarttv_paginas(link)

def restarttv_play(name,url):
    mensagemprogresso.create('TV Portuguesa', 'A carregar...')       
    mensagemprogresso.update(50)
    import urlresolver
    link=abrir_url(url)
    try:embedvideo=re.compile('<iframe frameborder="0" width=".+?" height=".+?" src="http://www.dailymotion.com/embed/video/(.+?)"></iframe>').findall(link)[0]
    except: embedvideo=False
    if embedvideo: embedvideo='http://www.dailymotion.com/video/' + embedvideo
    if not embedvideo:
        embedvideo=re.compile('<iframe.+?src="http://www.youtube.com/embed/(.+?)".+?></iframe>').findall(link)[0]
        if embedvideo: embedvideo='http://www.youtube.com/watch?v=' + embedvideo
        if not embedvideo: ok=mensagemok("TV Portuguesa", "Nenhum servidor compativel"); return 
    mensagemprogresso.update(100)
    mensagemprogresso.close()
    sources=[]
    hosted_media = urlresolver.HostedMediaFile(url=embedvideo)
    sources.append(hosted_media)
    source = urlresolver.choose_source(sources)
    if source:
        linkescolha=source.resolve()
        if linkescolha==False:
            okcheck = xbmcgui.Dialog().ok
            okcheck(traducao(40000),traducao(40019))
            return
        comecarvideo(linkescolha,name,False)

def restarttv_pesquisa():
      keyb = xbmc.Keyboard('', 'TV Portuguesa - Restart TV')
      keyb.doModal()
      if (keyb.isConfirmed()):
            search = keyb.getText()
            encode=urllib.quote_plus(search)
            if encode=='': pass
            else: restarttv_progs('',VBURL + '?s=' + encode)

def restarttv_paginas(link):
    try:
        paginas=re.compile('<span class="current">.+?</span>' + "<a href='(.+?)'" + ' class="inactive">(.+?)</a>').findall(link)
        for endereco, nrseg in paginas:
            addDir('[B][COLOR blue]Próxima pagina ('+nrseg+') >>[/COLOR][/B]',endereco,4,'',len(paginas),True)
    except: pass

#################### CAPTURA SERVERS ###############

def info_servidores():
    pleasewait='Por favor aguarde. '
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('A capturar fontes','A carregar lista de servidores.',pleasewait)
    if selfAddon.getSetting("fontes-resharetv") == "true":
        try:
            dialogWait.update(0,'',pleasewait + '(ReshareTV)')
            resharetvlink=abrir_url(ResharetvURL)
            savefile('resharetv', resharetvlink)
            if dialogWait.iscanceled(): return
        except: savefile('resharetv', '')
    if selfAddon.getSetting("fontes-thesporttveu") == "true":
        try:
            dialogWait.update(15,'',pleasewait + '(Thesporttv.eu)')
            sptveulink=abrir_url(SptveuURL + 'Live-television.html')
            savefile('thesporttveu', sptveulink)
            if dialogWait.iscanceled(): return
        except: savefile('thesporttveu', '')
    if selfAddon.getSetting("fontes-tugastream") == "true":
        try:
            dialogWait.update(30,'',pleasewait + '(Tugastream)')
            tugastreamlink=abrir_url(TugastreamURL)
            savefile('tugastream', tugastreamlink)
            if dialogWait.iscanceled(): return
        except: savefile('tugastream', '')
    if selfAddon.getSetting("fontes-tvacores") == "true":
        try:
            dialogWait.update(45,'',pleasewait + '(TV a Cores)')
            tvacoreslink=abrir_url(TVCoresURL + '/sporttv-directo')
            savefile('tvacores', tvacoreslink)
            if dialogWait.iscanceled(): return
        except: savefile('tvacores', '')
    if selfAddon.getSetting("fontes-tvdez") == "true":
        try:
            dialogWait.update(60,'',pleasewait + '(TVDez)')
            tvdezlink= abrir_url_cookie(TVDezURL)
            savefile('tvdez', tvdezlink)
            if dialogWait.iscanceled(): return
        except: savefile('tvdez', '')
    if selfAddon.getSetting("fontes-tvzune") == "true":
        try:
            dialogWait.update(75,'',pleasewait + '(TVZune)')
            tvzunelink=abrir_url(TVZuneURL)
            savefile('tvzune', tvzunelink)
            if dialogWait.iscanceled(): return
        except: savefile('tvzune', '')
    if selfAddon.getSetting("fontes-tvpthdorg") == "true":
        try:
            dialogWait.update(100,'',pleasewait + '(TVPortugalHD.org)')
            tvpthdorglink=abrir_url(TVPTHDZuukURL)
            savefile('tvportugalhd', tvpthdorglink)
            if dialogWait.iscanceled(): return
        except: savefile('tvportugalhd', '')
    #if selfAddon.getSetting("fontes-wiimov") == "true":
    #    try:
    #        dialogWait.update(100,'',pleasewait + '(Wiimov)')
    #        wiimovlink=abrir_url(WiimovURL + '/canais/show_news.php')
    #        savefile('wiimov', wiimovlink)
    #        if dialogWait.iscanceled(): return
    #    except: savefile('wiimov','')
    dialogWait.close()

def request_servidores(url,name):
    name=name.replace('[','-')
    nome=re.compile('B](.+?)/B]').findall(name)[0]
    nomega=nome.replace('-','')
    GA("listacanais",nomega)
    titles=[]; ligacao=[]
    dialogWait = xbmcgui.DialogProgress()

    if nome=='Optimus Alive 2013-':
        livesoccerhd='sim'
        if livesoccerhd:
            titles.append('Optimus Alive 2013')
            ligacao.append('http://media.rtp.pt/blogs/optimusalive/emissao-online/')

    ########################################LIVESOCCERHD############################
    if selfAddon.getSetting("fontes-livesoccerhd") == "true":
        try:
            if nome=='SPORTTV 1-':
                livesoccerhd='sim'
                if livesoccerhd:
                    titles.append('Livesoccer HD')
                    ligacao.append('http://lvshd.altervista.org/programacao2.php')
        except: pass

    ########################################RESHARETV############################
    if selfAddon.getSetting("fontes-resharetv") == "true":
        try:
            resharetv=False
            resharetvref=int(0)
            resharetvlink=openfile('resharetv')
            if nome=='SPORTTV 1-' or nome=='SPORTTV 2-': resharetvlink=limparcomentarioshtml(resharetvlink,'')
            nomeresharetv=nome.replace('SPORTTV 1-','Sport Tv1').replace('SPORTTV 2-','Sport Tv2').replace('SPORTTV 3-','Sport Tv3').replace('SPORTTV 4-','Sport Tv4').replace('RTP 1-','Rtp 1').replace('RTP 2-','Rtp 2').replace('SIC-','Sic').replace('TVI-','Tvi').replace('Big Brother VIP-','Tvi Direct').replace('SIC Noticias-','Sic Not&iacute;cias').replace('MTV-','Mtv').replace('VH1-','Vh1')
            resharetv=re.compile('<li><a href="/(.+?)" target="box" >'+nomeresharetv+'</a></li>').findall(resharetvlink)
            if not resharetv:
                resharetvlink=clean(resharetvlink)
                resharetv=re.compile('<li><a href="/(.+?)" target="box" >'+nomeresharetv+'</a>.+?</ul>').findall(resharetvlink)
                extralinks=re.compile('<li><a href="/.+?" target="box" >'+nomeresharetv+'</a>(.+?)</ul>').findall(resharetvlink)[0]
                blabla=re.compile('<li><a href="/(.+?)" target="box" >').findall(extralinks)
                for links in blabla:
                    resharetv.append(links)
            if resharetv:
                for codigo in resharetv:
                    resharetvref=int(resharetvref + 1)
                    if len(resharetv)==1: resharetv2=str('')
                    else: resharetv2=' #' + str(resharetvref)
                    titles.append('ReshareTV' + resharetv2)
                    ligacao.append(ResharetvURL + codigo)
        except: pass


    ########################################THESPORTTVEU############################
    if selfAddon.getSetting("fontes-thesporttveu") == "true":
        try:
            sptveuref=int(0)
            sptveulink=openfile('thesporttveu')
            nomesptveu=nome.replace('SPORTTV 1-','Sporttv1').replace('SPORTTV 1 HD-','Sporttv1-v').replace('SPORTTV 2-','Sporttv2').replace('SPORTTV 3-','Sporttv3').replace('SPORTTV 4-','Sporttv4')
            sptveu=re.compile('<a href="' + nomesptveu + '(.+?)" target="_blank"><img src=').findall(sptveulink)
            if sptveu:
                for resto in sptveu:
                    sptveuref=int(sptveuref + 1)
                    if len(sptveu)==1:
                        sptveu2=str('')
                    else:
                        sptveu2=' #' + str(sptveuref)
                    titles.append('Thesporttv.eu' + sptveu2)
                    ligacao.append('http://thesporttv.eu/' + nomesptveu + resto)
                    
        except: pass


    ########################################TV A CORES############################
    if selfAddon.getSetting("fontes-tvacores") == "true":
        try:
            tvacoresref=int(0)
            tvacoreslink=openfile('tvacores')
            nometvacores=nome.replace('RTP 1-','RTP 1').replace('RTP 2-','RTP 2').replace('SIC-','SIC').replace('TVI-','TVI ').replace('SPORTTV 1-','Sport TV (flash)').replace('Big Brother VIP-','BB VIP').replace('SIC K-','SIC K').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC Noticias-','SIC Notícias').replace('TVI24-','TVI24').replace('Hollywood-','Hollywood').replace('MOV-','Canal MOV').replace('AXN-','AXN').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX-','FOX').replace('FOX Crime-','FOX Crime').replace('FOX Life-','FOX Life').replace('FOX Movies-','FOX Movies').replace('Canal Panda-','Canal Panda').replace('Discovery Channel-','Discovery Channel').replace('Eurosport-','Eurosport PT').replace('Benfica TV-','Benfica TV').replace('Porto Canal-','Porto Canal').replace('Syfy-','SyFy Channel').replace('Odisseia-','Odisseia').replace('História-','História').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV')
            tvacores=re.compile('<span class="top"><a href="(.+?)">'+nometvacores + '</a></span>').findall(tvacoreslink)
            if nome=='SPORTTV 1-':
                pass
            if tvacores:
                for codigo in tvacores:
                    tvacoresref=int(tvacoresref + 1)
                    if len(tvacores)==1: tvacores2=str('')
                    else: tvacores2=' #' + str(tvacoresref)
                    titles.append('TV a Cores' + tvacores2)
                    ligacao.append(TVCoresURL + codigo)
        except: pass
    
                  
    ########################################TUGASTREAM############################
    if selfAddon.getSetting("fontes-tugastream") == "true":
        try:
            tugastreamref=int(0)
            tugastreamlink=openfile('tugastream')
            nometugastream=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('SIC-','sic').replace('AXN Black-','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV 4-','sporttv4').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Porto Canal-','portocanal').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao').replace('Syfy-','syfy')
            tugastream=re.compile('<a href="'+nometugastream + '(.+?)php">').findall(tugastreamlink)
            if tugastream:
                for codigo in tugastream:
                    tugastreamref=int(tugastreamref + 1)
                    if len(tugastream)==1: tugastream2=str('')
                    else: tugastream2=' #' + str(tugastreamref)
                    titles.append('Tugastream' + tugastream2)
                    ligacao.append(TugastreamURL + nometugastream + codigo + 'php?altura=432&largura=768')
        except: pass
            
    ########################################TVDEZ############################
    if selfAddon.getSetting("fontes-tvdez") == "true":
        try:
            tvdezref=int(0)
            tvdezlink=openfile('tvdez')
            tvdezlink=tvdezlink.replace('+ TVI','Mais TVI')
            nometvdez=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('FOX-','FOX').replace('AXN-','AXN').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('SPORTTV 3-','Sport TV 3').replace('SPORTTV 4-','Sport TV 4').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','Canal MOV').replace('VH1-','VH1 Hits').replace('Porto Canal-','Porto Canal').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('TVI Ficção-','TVI Fic&ccedil;&atilde;o').replace('Benfica TV-','Benfica TV').replace('Discovery Channel-','Discovery Channel').replace('TVI24-','TVI 24').replace('Mais TVI-','Mais TVI').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Hist&oacute;ria').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV')
            tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
            if not tvdez:
                nometvdez=nome.replace('SPORTTV 1-','Sport TV 1').replace('SPORTTV 2-','Sport TV 2').replace('SIC-','SIC').replace('TVI-','TVI').replace('SIC Noticias-','SIC Not&iacute;cias').replace('Big Brother VIP-','Big Brother VIP 2013')
                tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                nometvdez=nome.replace('SPORTTV 1-','Sporttv em Directo').replace('SPORTTV 2-','Sporttv 2').replace('SIC-','SIC Online - Stream 2').replace('TVI-','TVI Online - Stream 2').replace('SIC Noticias-','SIC Not&iacute;cias Online').replace('Big Brother VIP-','Big Brother Portugal')
                tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                nometvdez=nome.replace('SPORTTV 1-','Sporttv HD')
                tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
            if tvdez:
                for codigo in tvdez:
                    tvdezref=int(tvdezref + 1)
                    if len(tvdez)==1: tvdez2=str('')
                    else: tvdez2=' #' + str(tvdezref)
                    titles.append('TVDez' + tvdez2)
                    ligacao.append(TVDezURL + codigo)
        except: pass


    ########################################TVZUNE############################
    if selfAddon.getSetting("fontes-tvzune") == "true":
        try:
            tvzuneref=int(0)
            tvzunelink=openfile('tvzune')
            nometvzune=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('SIC-','sic').replace('SPORTTV 1-','sporttv').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('Discovery Channel-','discovery').replace('AXN Black','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('TVI24-','tvi24').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao')
            tvzune=re.compile("parent.Player.location.href='canais/" + nometvzune + '.php').findall(tvzunelink)
            if tvzune:
                for resto in tvzune:
                    tvzuneref=int(tvzuneref + 1)
                    if len(tvzune)==1: tvzune2=str('')
                    else: tvzune2=' #' + str(tvzuneref)
                    titles.append('TVZune' + tvzune2)
                    ligacao.append('http://www.tvzune.com/canais/' + nometvzune + '.php')
        except: pass  

    ######################################TVPORTUGALHD.ORG########################
    if selfAddon.getSetting("fontes-tvpthdorg") == "true":
        try:
            nometvpthdorg=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('SIC-','SIC').replace('SPORTTV 1-','SPORTTV 1').replace('SPORTTV 2-','SPORTTV 2').replace('SPORTTV 3-','SPORTTV 3').replace('SPORTTV 4-','SPORTTV 4').replace('SIC-','SIC').replace('TVI-','TVI').replace('FOX-','FOX').replace('AXN-','AXN').replace('Discovery Channel-','Discovery Channel').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','MOV').replace('VH1-','VH1').replace('Benfica TV-','Benfica TV').replace('Porto Canal-','Porto Canal').replace('TVI24-','TVI24').replace('SIC Noticias-','SIC Noticias').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('Big Brother VIP-','Big Brother Vip1').replace('TVI Ficção-','TVI Ficção').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Historia').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV')
            tvpthdorglink=openfile('tvportugalhd')
            tvpthdorgref=int(0)
            nometvpthdorg=urllib.quote(nometvpthdorg)
            print nometvpthdorg
            tvpthdorg=re.compile("<a dir='ltr' href='http://www.zuuk.pw/search/label/" + nometvpthdorg + "'>.+?</a>").findall(tvpthdorglink)
            reftvpth=1
            if not tvpthdorg:
                tvpthdorg=re.compile("<a dir='ltr' href='http://www.zuuk.pw/search/label/" + nometvpthdorg + "(.+?)>.+?</a>").findall(tvpthdorglink)
                reftvpth=0
            if tvpthdorg:
                for codigotv in tvpthdorg:
                    tvpthdorgref=int(tvpthdorgref + 1)
                    if len(tvpthdorg)==1: tvpthdorg2=str('')
                    else:
                        if tvpthdorgref==1: tvpthdorg2=' #' + str(tvpthdorgref)
                        else: tvpthdorg2=' #' + str(tvpthdorgref)# + '[COLOR red] (indisponivel)[/COLOR]'
                    codigotv=codigotv.replace("'",'')
                    titles.append('TVPortugal HD.org' + tvpthdorg2)
                    if reftvpth==1: ligacao.append('http://www.zuuk.pw/search/label/' + nometvpthdorg)
                    else: ligacao.append('http://www.zuuk.pw/search/label/' + nometvpthdorg + codigotv)
        except: pass
    
    ######################################WIIMOV########################
    #if selfAddon.getSetting("fontes-wiimov") == "true":
    #    try:
    #        wiimovlink=openfile('wiimov')
    #        nomewiimov=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('SIC-','sic').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV 4-','sporttv4').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('Discovery Channel-','discovery').replace('AXN Black-','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Benfica TV-','benficatv').replace('Porto Canal-','porto').replace('TVI24-','tvi24').replace('SIC Noticias-','sicn').replace('SIC Radical-','sicr').replace('SIC Mulher-','sicm').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao')
    #        wiimovref=int(0)
    #        wiimov=re.compile('<strong><a href="/canais/news/' + nomewiimov+ '.php.+?">(.+?)</a></strong>').findall(wiimovlink)
    #        if wiimov:
    #            for codigo in wiimov:
    #                wiimovref=int(wiimovref + 1)
    #                if len(wiimov)==1: wiimov2=str('')
    #                else: wiimov2=' #' + str(wiimovref)
    #                titles.append('Wiimov' + wiimov2)
    #                ligacao.append(WiimovURL + '/canais/news/' + nomewiimov + '.php?archive=&number=1000&category=1')
    #    except: pass
    print len(ligacao)
    if len(ligacao)==1: index=0
    elif len(ligacao)==0: ok=mensagemok('TV Portuguesa', 'Nenhum stream disponivel.'); return     
    else: index = xbmcgui.Dialog().select('Escolha o servidor', titles)
    try:
        import buggalo
        buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
        sys.argv[2]=sys.argv[2]+ titles[index]
        if index > -1:
            linkescolha=ligacao[index]
            if linkescolha:
                print linkescolha
                if re.search('estadiofutebol',linkescolha):
                    link=abrir_url_cookie(linkescolha)
                    if re.search('televisaofutebol',link):
                        codigo=re.compile('<iframe src="http://www.televisaofutebol.com/(.+?)"').findall(link)[0]
                        descobrirresolver('http://www.televisaofutebol.com/' + codigo, nome,False)
                    else:descobrirresolver(linkescolha, nome,False)
                elif re.search('tvfree4',linkescolha):
                    link=abrir_url(linkescolha)
                    if re.search('antena24',link):
                        #####
                        from t0mm0.common.net import Net
                        net = Net()
                        #####
                        frame=re.compile('<iframe id="player".+?src="(.+?)"').findall(link)[0]
                        ref_data = {'Referer': linkescolha}
                        link = net.http_GET(frame,ref_data).content
                        descobrirresolver(frame, nome,link)
                    else: descobrirresolver(linkescolha, nome,False)
                    
                elif re.search('thesporttv',linkescolha):
                    link=abrir_url(linkescolha)
                    try:
                        linkcod=re.compile("id='(.+?)'.+?</script><script type='text/javascript' src='http://thesporttv.eu/teste/").findall(link)[0]
                        descobrirresolver('http://thesporttv.eu/teste/c0d3r.php?id=' + linkcod,nome,'hdm1.tv')
                    except:
                        frame=re.compile('<iframe allowtransparency="true" frameborder="0" scrolling="No" src="(.+?)"').findall(link)[0]
                        link=abrir_url(frame)
                        if re.search('var urls = new Array',link):
                            frame=re.compile('new Array.+?"(.+?)",').findall(link)[0]
                        descobrirresolver(frame, nome,False)
                elif re.search('lvshd',linkescolha):
                    link=abrir_url(linkescolha)
                    endereco=re.compile('href="(.+?)"><img src=".+?flash.+?.png" border="0">').findall(link)[0]
                    link=abrir_url(endereco)
                    endereco=re.compile('src="(.+?)" marginheight="0"').findall(link)[0]
                    descobrirresolver(endereco, nome,False)
                elif re.search('wiimov',linkescolha):
                    link=abrir_url(linkescolha)
                    if re.search("src='/canais/news/scripts/live.js'",link):
                         codigo=re.compile("file='(.+?)'.+?</script>").findall(link)[0]
                         descobrirresolver('http://wiimov.org/canais/news/scripts/livebru.php?bru='+codigo,nome,False)
                    else: descobrirresolver(linkescolha,nome,False)
                else: descobrirresolver(linkescolha, nome,False)
    except Exception:
        buggalo.onExceptionRaised()

def programacao(url,playerinfo):
      if selfAddon.getSetting("prog-lista2") == "false": return ''
      else:
            dia=time.strftime("%Y-%m-%d", time.gmtime())
            hora=time.strftime("%H", time.gmtime())
            minutos=time.strftime("%M", time.gmtime())
            link=abrir_url('http://tv.sapo.pt/json/epg/channels/?date='+dia+'&channels='+url)
            link=link.replace(':','')
            ref=hora+minutos
            reftempo=0
            if playerinfo==True: noinfo=''
            else: noinfo='(Sem informação)'
            try:
                  pr=re.compile('class="epg_sp" value="(.+?)">(.+?)</span><span class="epg_st" value=".+?">(.+?)</span></a>').findall(link)
                  for idprog,nome,tempo in pr:
                        if (ref>=tempo) and (tempo>reftempo):
                              #print tempo + url
                              nomefinal=nome
                              idfinal=idprog
                        reftempo=tempo
                  #print "NOME ANTES DA PROCURA " + nomefinal
                  #print idfinal
                  try:
                        link=abrir_url('http://tv.sapo.pt/json/epg/prog/?programId=' + idfinal)
                        amostra=re.compile('"Title":"(.+?)"').findall(link)[0]
                  #print amostra
                        if amostra:
                              nomefinal2=amostra
                        #else: nomefinal2=nomefinal
                  except: pass
                  nomefinal=nomefinal.replace('\u00e1','á').replace('\u00e7','ç').replace('\u00e3','ã').replace('\u00f3','ó').replace('\u00e9','é').replace('\u00e0','à').replace('\u00fa','ú')
                  if playerinfo==True: pass
                  else: nomefinal='(' + nomefinal + ')'
                  return nomefinal
            except: return noinfo


def mensagemaviso():
    xbmc.executebuiltin("ActivateWindow(10147)")
    window = xbmcgui.Window(10147)
    xbmc.sleep(100)
    window.getControl(1).setLabel( "%s - %s" % ('AVISO','TV Portuguesa',))
    window.getControl(5).setText("[COLOR red][B]É necessário actualizar o libRTMP do XBMC para alguns streams funcionarem a 100%.\nMais informações em: [/B][/COLOR] http://bit.ly/fightnightaddons\n\nAlguns streams não funcionam porque estão offline na própria fonte. \n[B]Acompanhe o tópico oficial deste plugin:[/B] http://bit.ly/fightnightaddons\n[B]Faz like na pagina oficial do facebook:[/B] http://fb.com/fightnightxbmc \n\n\n[COLOR red][B]Outros Avisos:[/B][/COLOR]\nEste plugin não pretende substituir o acesso aos serviços de televisão pagos. Apenas funciona como um suplemento extra.\n\nEste plugin apenas indexa links de outros sites, não alojando quaisquer conteúdos.\n\nEste plugin não pretende substituir o acesso aos sites de streaming, mas sim facilitar o acesso a estes via plataformas móveis (RPi, android, etc.)\n\nVisitem os sites oficiais e suportem os sites clicando na publicidade.\n\nUm obrigado a todos eles. (www.livesoccerhd.net, www.reshare.net, www.thesporttv.eu, www.tugastream.com, www.tvdez.com, www.tvfree4.me, www.tvportugalhd.org, www.tvzune.com). Restart TV (www.videosbacanas.com)\n\n\n[B]Data de actualização do aviso: [/B] 15 de Maio de 2013")

def limparcomentarioshtml(link,url_frame):
    print "A limpar: " + url_frame
    if re.search('Sporttv1-veetle-iframe',url_frame) or re.search('Sporttv2-veetle-iframe',url_frame):
        return link
    else:
        link=clean(link)
        htmlcomments=re.compile('<!--(?!<!)[^\[>].*?-->').findall(link)
        for comentario in htmlcomments:
            link=link.replace(comentario,'oioioioi')
        return link

def descobrirresolver(url_frame,nomecanal,linkrecebido):
    try:
        import buggalo
        buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
        from t0mm0.common.net import Net
        net = Net()

        if linkrecebido==False:
            print "Resolver: O url da frame e " + url_frame
            url_frame=url_frame.replace(' ','%20')
            link=abrir_url_cookie(url_frame)
            try:link=limparcomentarioshtml(link,url_frame)
            except: pass
        else:
            print "Resolver: O produto final no descobrirresolver"
            link=limparcomentarioshtml(linkrecebido,url_frame)
            link=link.replace('<title>Zuuk.net</title>','').replace('http://s.zuuk.net/300x250.html','').replace('www.zuuk.net\/test.php?ch=','').replace('cdn.zuuk.net\/boi.php','')
            
        if re.search("<iframe src='http://www.zuuk.pw",link):
            name=re.compile("<iframe src='http://www.zuuk.pw(.+?)'").findall(link)[0]
            descobrirresolver('http://www.zuuk.pw' + name,nomecanal,False)
        
        elif re.search("zuuk.net",link):
            try:
                print "Catcher: zuuk"
                l
#                try:chname=re.compile("file='(.+?)'.+?</script>").findall(link)[0]
#                except:chname=False
#                if not chname:
#                    chname=re.compile('src=.+?http://www.zuuk.net/el.php.+?ch=(.+?)&').findall(link)[0]
#                    link=abrir_url_cookie('http://www.zuuk.net/el.php?ch='+chname)
#                streamurl='rtmp://198.7.58.79/edge playPath='+ chname +' swfUrl=http://cdn.zuuk.net/ply.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.zuuk.net/'
#                comecarvideo(streamurl,nomecanal,True)
            except:
                print "Catcher: zuuk outro"
                if re.search('<script type="text/javascript">var urls = new Array',link): url_final=re.compile('new Array.+?"(.+?)",').findall(link)[0]
                ##derbie##
                else:
                    name=re.compile('<iframe.+?src="http://.+?zuuk.net/(.+?)"').findall(link)[0]
                    url_final="http://www.zuuk.net/" + name
                link=abrir_url_cookie(url_final)
                link=limparcomentarioshtml(link,url_frame)
                try:
                    info=re.compile("<div id='mediaspace'>"+'<script language="javascript".+?' + "document.write.+?unescape.+?'(.+?)'").findall(link)[0]
                    if info=="' ) );</script> <script type=": info=False
                except:info=False
                if info: infotratada=urllib.unquote(info)
                else: infotratada=link
                descobrirresolver(url_final,nomecanal,infotratada)

        #### ALIVE REMOVER DEPOIS ####

        elif re.search('http://media.rtp.pt/blogs/optimusalive/emissao-online/',url_frame):
            print "Catcher: Optimus Alive"
            link=abrir_url_cookie(url_frame)
            #print link
            urlalive=re.compile('<iframe src="(.+?)".+?></iframe>').findall(link)[0]
            import cookielib
            cookie = cookielib.CookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
            opener.addheaders = [('Host','www.rtp.pt'), ('User-Agent', user_agent), ('Referer',url_frame)]
            linkfinal = opener.open(urlalive).read()
            rtmpendereco=re.compile('streamer=(.+?)&').findall(linkfinal)[0]
            filepath=re.compile('file=(.+?)&').findall(linkfinal)[0]
            swf=re.compile('<embed type="application/x-shockwave-flash" src="(.+?)"').findall(linkfinal)[0]
            streamurl=rtmpendereco + ' playPath=' + filepath + ' swfUrl=' + swf + ' live=1 timeout=15 pageUrl=' + url_frame
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('720Cast',link) or re.search('ilive',link):
            print "Catcher: ilive"
            setecast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            if not setecast: setecast=re.compile('file: ".+?/app/(.+?)/.+?",').findall(link)
            if not setecast: setecast=re.compile('flashvars="file=(.+?)&').findall(link)
            if not setecast: setecast=re.compile('src="/ilive.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            for chname in setecast:
                embed='http://www.ilive.to/embedplayer.php?width=640&height=400&channel=' + chname + '&autoplay=true'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                rtmp=re.compile('streamer: "(.+?)",').findall(html)[0]
                filelocation=re.compile('file: "(.+?).flv",').findall(html)[0]
                swf=re.compile("type: 'flash', src: '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + filelocation + ' swfUrl=' + swf + ' swfVfy=1 live=1 timeout=15 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('aliez',link):
            print "Catcher: aliez"
            aliez=re.compile('src="http://emb.aliez.tv/player/live.php.+?id=(.+?)&').findall(link)
            for chid in aliez:
                embed='http://emb.aliez.tv/player/live.php?id=' + chid + '&w=700&h=420'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('swfobject.embedSWF\("([^"]+)"').findall(html)[0]
                rtmp=urllib.unquote(re.compile('"file":\s."([^"]+)"').findall(html)[0])
                streamurl=rtmp + ' live=true swfVfy=1 swfUrl=' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('castalba', link):
            print "Catcher: castalba"
            castalba=re.compile('id="(.+?)";.+?></script>').findall(link)
            for chname in castalba:
                embed='http://castalba.tv/embed.php?cid=' + chname + '&wh=640&ht=385&r=www.zuuk.net'
                ref_data = {'Referer': 'http://www.zuuk.net'}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + '?id=' + ' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('castamp',link):
            print "Catcher: castamp"
            castamp=re.compile('channel="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://castamp.com/embed.php?c='+chname
                ref_data = {'Referer': 'http://www.zuuk.net'}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playpath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)
                
        elif re.search('cast3d', link): ##nao esta
            print "Catcher: cast3d"
            cast3d=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in cast3d:
                embed='http://www.cast3d.tv/embed.php?channel=' + '&vw=640&vh=385&domain=lsh.lshunter.tv'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)
                filelocation=re.compile("'file': '(.+?)',").findall(html)
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + '?id=' + ' swfUrl=' + swf[0] + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('castto.me',link):
            print "Catcher: castto.me"
            castamp=re.compile('fid="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://static.castto.me/embed.php?channel='+chname+'&vw=650&vh=500&domain='+url_frame
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                print html
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)[0]
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)[0]
                streamurl=rtmpendereco + ' playpath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 token=#ed%h0#w@1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('ChelTV',link):
            print "Catcher: cheltv"
            chelsea=re.compile("file=(.+?).flv&streamer=(.+?)&logo").findall(link)
            swf=re.compile('src="(.+?)" type="application/x-shockwave-flash">').findall(link)[0]
            streamurl=chelsea[0][1] + ' playPath=' + chelsea[0][0] + ' swfUrl=' + swf + ' live=true pageUrl=http://www.casadossegredos.tv'
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('ezcast', link):
            print "Catcher: ezcast"
            ezcast=re.compile("channel='(.+?)',.+?</script>").findall(link)
            if not ezcast: ezcast=re.compile('src="/ezcast.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            for chname in ezcast:
                embed='http://www.ezcast.tv/embedded/' + chname + '/1/555/435'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                link=abrir_url('http://www.ezcast.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                idnum=re.compile("'FlashVars', '.+?&id=(.+?)&s=.+?'").findall(html)[0]
                chnum=re.compile("'FlashVars', '.+?&id=.+?&s=(.+?)'").findall(html)[0]
                streamurl='rtmp://' + rtmpendereco + '/live playPath=' + chnum + '?id=' + idnum + ' swfUrl=http://www.ezcast.tv/static/scripts/eplayer.swf live=true conn=S:OK swfVfy=1 timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('fcast', link):
            print "Catcher: fcast"
            fcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            if not fcast: fcast=re.compile("e-fcast.tv.php.+?fid=(.+?).flv").findall(link)
            for chname in fcast:
                embed='http://www.fcast.tv/embed.php?live=' + chname + '&vw=600&vh=400'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf[0] + ' live=true timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('flashi', link):
            print "Catcher: flashi"
            flashi=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in flashi:
                embed='http://www.flashi.tv/embed.php?v=' + chname +'&vw=640&vh=490&typeplayer=0&domain=f1-tv.info'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                if re.search('This Channel is not Existed !',html):
                    ok=mensagemok('TV Portuguesa','Stream indisponivel')
                    return
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filename=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                #rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(link)
                streamurl='rtmp://flashi.tv:1935/lb' + ' playPath=' + filename[0] + ' swfUrl=http://www.flashi.tv/' + swf + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('hdcast.tv',link):
            chid=re.compile('fid=(.+?)"').findall(link)[0]
            chid=chid.replace('.flv','')
            streamurl='rtmp://origin.hdcast.tv:1935/redirect/ playPath='+chid+' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.hdcast.tv'
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('hdcaster.net', link):
            print "Catcher: hdcaster"
            hdcaster=re.compile("<script type='text/javascript'>id='(.+?)'").findall(link)
            for chid in hdcaster:
                urltemp='rtmp://188.138.121.99/hdcaster playpath=' + chid + ' swfUrl=http://hdcaster.net/player.swf pageUrl=http://hdcaster.net/player.php?channel_id=101634&width=600&height=430'
                token = '%Xr8e(nKa@#.'
                streamurl=urltemp + ' token=' + token
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('longtail', link):
            print "Catcher: longtail"
            longtail=re.compile("src='http://player.longtailvideo.com/player.swf' flashvars='file=(.+?)&streamer=(.+?)&").findall(link)
            for chname,rtmp in longtail:
                streamurl=rtmp + ' playpath=' + chname + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl=http://longtailvideo.com/'
                comecarvideo(streamurl,nomecanal,True)
            if not longtail:
                streamurl=re.compile('file: "(.+?)"').findall(link)[0]
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('hdm1.tv',link):
            print "Catcher: hdm1.tv"
            hdmi=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in hdmi:
                embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)
            if not hdmi:
                hdmi=re.compile("src='(.+?).swf.+?file=(.+?)&streamer=(.+?)&autostart=true").findall(link)
                for swf,chid,rtmp in hdmi:
                    embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                    streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                    comecarvideo(streamurl,nomecanal,True)

        elif re.search('jimey',link):
            print "Catcher: jimey"
            chname=re.compile("file='(.+?)';.+?</script>").findall(link)[0]
            embed= 'http://jimey.tv/player/embedplayer.php?channel=' + chname + '&width=640&height=490'
            ref_data = {'Referer': url_frame}
            html = net.http_GET(embed,ref_data).content
            rtmp=re.compile('&streamer=(.+?)/redirect').findall(html)[0]
            streamurl= rtmp + ' playPath='+chname + " token=zyklPSak>3';CyUt%)'ONp" + ' swfUrl=http://jimey.tv/player/fresh.swf live=true timeout=15 swfVfy=1 pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('jwlive',link):
            print "Catcher: jwlive"
            endereco=re.compile('src="(.+?)" id="innerIframe"').findall(link)[0]
            link=abrir_url(TVCoresURL + endereco)
            streamurl=re.compile('file: "(.+?)"').findall(link)[0]
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('liveflash', link):
            print "Catcher: liveflash"
            flashtv=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not flashtv: flashtv=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not flashtv: flashtv=re.compile('iframe src="/cc-liveflash.php.+?channel=(.+?)"').findall(link)
            if not flashtv: flashtv=re.compile("window.open.+?'/e-liveflash.tv.php.+?channel=(.+?)'").findall(link)
            #if not flashtv: flashtv=re.compile("http://tvph.googlecode.com/svn/players/liveflash.html.+?ver=(.+?)'").findall(link)
            for chname in flashtv:
                embed='http://www.liveflash.tv/embedplayer/' + chname + '/1/640/460'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                print chid
                print nocanal
                #chid=re.compile("id=(.+?)&s=.+?").findall(html)
                link=abrir_url('http://www.liveflash.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)
                streamurl='rtmp://' + rtmpendereco[0] + '/stream/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.liveflash.tv' + swf[0] + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('livestream', link):
            print "Catcher: livestream"
            livestream=re.compile("videoborda.+?channel=(.+?)&").findall(link)
            for chname in livestream:
                streamurl='rtmp://extondemand.livestream.com/ondemand playpath=trans/dv04/mogulus-user-files/ch'+chname+'/2009/07/21/1beb397f-f555-4380-a8ce-c68189008b89 live=true swfVfy=1 swfUrl=http://cdn.livestream.com/chromelessPlayer/v21/playerapi.swf pageUrl=http://cdn.livestream.com/embed/' + chname + '?layout=4&amp;autoplay=true'
                comecarvideo(streamurl,nomecanal,True)



        elif re.search('megom', link):
            print "Catcher: megom.tv"
            megom=re.compile('HEIGHT=432 SRC="http://distro.megom.tv/player-inside.php.+?id=(.+?)&width=768&height=432"></IFRAME>').findall(link)
            for chname in megom:
                embed='http://distro.megom.tv/player-inside.php?id='+chname+'&width=768&height=432'
                link=abrir_url(embed)
                swf=re.compile(".*'flashplayer':\s*'([^']+)'.*").findall(link)[0]
                streamer=re.compile("'streamer': '(.+?)',").findall(link)[0]
                streamer=streamer.replace('live.megom.tv','37.221.172.85')
                streamurl=streamer + ' playpath=' + chname + ' swfVfy=1 swfUrl=' + swf + ' live=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('micast', link):
            print "Catcher: micast"
            micast=re.compile('micast.tv:1935/live/(.+?)/').findall(link)
            if not micast: micast=re.compile('ca="(.+?)".+?></script>').findall(link)
            for chname in micast:
                link=abrir_url('http://micast.tv/gen.php?ch='+chname)
                if re.search('refresh',link):
                    chname=re.compile('refresh" content="0; url=http://micast.tv/gen.php.+?ch=(.+?)"').findall(link)[0]                
                    link=abrir_url('http://micast.tv/gen.php?ch='+chname)
                final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                comecarvideo(streamurl,nomecanal,True)
            if not micast:
                try:
                    micast=re.compile('<iframe src="(.+?)" id="innerIframe"').findall(link)[0]
                    link=abrir_url(TVCoresURL + micast)
                    micast=re.compile('//(.+?).micast.tv/').findall(link)[0]
                    linkfinal='http://' + micast+  '.micast.tv'
                    #print linkfinal
                    link=abrir_url(linkfinal)
                    final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                    #if not final: final=re.compile("file=(.+?)&streamer=(.+?)'").findall(link)[0]
                    streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                    comecarvideo(streamurl,nomecanal,True)
                except: pass


        elif re.search('mips', link):
            print "Catcher: mips"
            mips=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not mips: mips=re.compile('channel="(.+?)",.+?></script>').findall(link)
            if not mips: mips=re.compile('<iframe src="/mips.tv.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            for chname in mips:
                embed='http://www.mips.tv/embedplayer/' + chname + '/1/500/400'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&e=").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                print nocanal
                print chid
                link=abrir_url('http://www.mips.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 live=true timeout=15 conn=S:OK swfUrl=http://www.mips.tv' + swf + ' pageUrl=' + embed
                print streamurl
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('putlive', link):
            print "Catcher: putlive"
            putlivein=re.compile("<iframe.+?src='.+?.swf.+?file=(.+?)&.+?'.+?></iframe>").findall(link)
            if not putlivein: putlivein=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not putlivein: putlivein=re.compile('src="http://www.putlive.in/e/(.+?)"></iframe>').findall(link)
            for chname in putlivein:
                streamurl='rtmpe://199.195.199.172:443/liveedge2/ playPath=' + chname + ' swfUrl=http://www.megacast.io/player59.swf live=true timeout=15 swfVfy=1 pageUrl=http://putlive.in/'
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('rtps',link):
            print "Catcher: rtps"
            ficheiro=re.compile("file='(.+?).flv'.+?</script>").findall(link)[0]
            streamurl='rtmp://ec21.rtp.pt/livetv/ playPath=' + ficheiro + ' swfUrl=http://museu.rtp.pt/app/templates/templates/swf/pluginplayer.swf live=true timeout=15 pageUrl=http://www.rtp.pt/'
            comecarvideo(streamurl, nomecanal,True)

        elif re.search('resharetv',link): #reshare tv
            ref_data = {'Referer': 'http://resharetv.com'}
            html = net.http_GET(url_frame,ref_data).content
            html=clean(html)
            try:
                try: streamurl=re.compile(',  file: "(.+?)"').findall(html)[0]
                except: streamurl=re.compile('file: "(.+?)"').findall(html)[0]
            except:
                try:
                    swf=re.compile('<param name="movie" value="/(.+?)"></param>').findall(html)[0]
                    rtmp=re.compile('<param name="flashvars" value="src=http%3A%2F%2F(.+?)%2F_definst_%2F.+?%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                    play=re.compile('_definst_%2F(.+?)%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                except:
                    swf=re.compile('src="(.+?)" type="application/x-shockwave-flash"').findall(html)[0]
                    rtmp=re.compile('streamer=(.+?)&amp').findall(html)[0]
                    play=re.compile('flashvars="file=(.+?).flv&').findall(html)[0]
                streamurl='rtmp://' + urllib.unquote(rtmp) + ' playPath=' + play + ' live=true timeout=15 swfVfy=1 swfUrl=' + ResharetvURL + swf + ' pageUrl=' + ResharetvURL

            comecarvideo(streamurl, nomecanal,True)

        elif re.search('sapo.pt',link):
            print "Catcher: sapo.pt"
            chname=re.compile('live/(.+?)&').findall(link)[0]
            filepath=re.compile('file=(.+?)&amp').findall(link)[0]
            host=abrir_url('http://videos.sapo.pt/hosts_stream.html')
            hostip=re.compile('<host>(.+?)</host>').findall(host)[0]
            streamurl='rtmp://' + hostip + '/live' + ' playPath=' + chname  + ' swfUrl=http://imgs.sapo.pt/sapovideo/swf/flvplayer-sapo.swf?v11 live=true pageUrl=http://videos.sapo.pt/playhtml?file='+filepath+'&live=rtmp://{$hostname}/live/'+chname+'&autoStart=1&relatedVideos=none%22'
            ok=mensagemok('TV Portuguesa','Servidor não suportado')
            #comecarvideo(streamurl,nomecanal,True)

        elif re.search('televisaofutebol',link):
            print "Catcher: televisaofutebol"
            tuga=re.compile('src="http://www.televisaofutebol.com/(.+?)".+?/iframe>').findall(link)[0]
            descobrirresolver('http://www.televisaofutebol.com/' + tuga,nomecanal,False)

        elif re.search('tugastream',link):
            print "Catcher: tugastream"
            tuga=re.compile('src=".+?tugastream.com/(.+?)".+?/iframe>').findall(link)[0]
            descobrirresolver('http://tugastream.com/' + tuga,nomecanal,False)

        elif re.search('tvph.googlecode.com',link):
            print "Catcher: tvph google code"
            streamurl=re.compile("cid=(.+?)'").findall(link)[0]
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('veetle',url_frame) or re.search("src='http://veetle.com",link):
            print "Catcher: veetle"
            if selfAddon.getSetting("verif-veetle") == "false":
                ok = mensagemok('TV Portuguesa','Necessita de instalar o addon veetle.','Este irá ser instalado já de seguida.')
                import extract
                urlfusion='http://fightnight-xbmc.googlecode.com/svn/veetle/plugin.video.veetle.zip' #v2.2
                path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
                lib=os.path.join(path, 'plugin.video.veetle.zip')
                downloader(urlfusion,lib)
                addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
                xbmc.sleep(2000)
                dp = xbmcgui.DialogProgress()
                dp.create("TV Portuguesa", "A instalar...")
                try:
                    extract.all(lib,addonfolder,dp)
                    ok = mensagemok('TV Portuguesa','Veetle instalado / actualizado.','Necessita de reiniciar o XBMC.')
                    selfAddon.setSetting('verif-veetle',value='true')
                except:
                    ok = mensagemok('TV Portuguesa','Sem acesso para instalar Veetle. Efectue o download em','http://db.tt/G5QUEtEN e instale como zip nas definicoes do','XBMC. De seguida, active o Veetle nas definições do addon.')
            else:
                print link
                try:idembed=re.compile('veetle.com/index.php/widget/index/(.+?)/0/true').findall(link)[0]
                except: idembed=re.compile('veetle.com/index.php/widget#(.+?)/true/16:9').findall(link)[0]
                print "ID embed: " + idembed
                try:
                    chname=abrir_url('http://tvmpt.x10.mx/fightnight/decode.php?id=' + idembed)
                    chname=chname.replace(' ','')
                    if re.search('DOCTYPE HTML PUBLIC',chname):
                        ok = mensagemok('TV Portuguesa','Erro a obter link do stream. Tenta novamente.')
                        return
                    print "ID final obtido pelo TvM."
                except:
                    chname=abrir_url('http://fightnight-xbmc.googlecode.com/svn/veetle/sporttvhdid.txt')
                    print "ID final obtido pelo txt."
                print "ID final: " + chname
                link=abrir_url('http://veetle.com/index.php/channel/ajaxStreamLocation/'+chname+'/flash')
                if re.search('"success":false',link): ok = mensagemok('TV Portuguesa','O stream está offline.')
                else:
                    nomestreamfile='sporttv1hd.strm'
                    savefile(nomestreamfile, 'plugin://plugin.video.veetle/?channel=' + chname)
                    streamfile = os.path.join(pastaperfil, nomestreamfile)
                    comecarvideo(streamfile,nomecanal,True)

        elif re.search('wcast', link):
            print "Catcher: wcast"
            wcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in wcast:
                embed='http://www.wcast.tv/embed.php?u=' + chid+ '&vw=600&vh=470'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf='http://www.wcast.tv/player/player.swf'
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('ucaster', link):
            print "Catcher: ucaster"
            ucaster=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&s=(.+?)&g=1&a=1&l=').findall(link)
            if not ucaster: ucaster=re.compile('src="/ucaster.eu.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            if not ucaster: ucaster=re.compile("flashvars='id=.+?&s=(.+?)&").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            for chname in ucaster:
                embed='http://www.ucaster.eu/embedded/' + chname + '/1/600/430'
                ref_data = {'Referer': url_frame}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                print chid
                print nocanal
                link=abrir_url('http://www.ucaster.eu:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)
                streamurl='rtmp://' + rtmpendereco[0] + '/live playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.ucaster.eu' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('xuuby',link): ##proteccao tvdez
            print "Catcher: xuuby"
            chname=re.compile('chname="(.+?)".+?</script>').findall(link)[0]
            streamurl='rtmp://fml.9c26.edgecastcdn.net:1935/209C26/' +chname + '?58ea3a29e596b505ca6781ce06e4f648c2ba3d3f97253f2fa3103599fb7750aa57893e535489ef​6ef9dbfc5f24ca43c4930f1b36a7c361e94f3a2f1e00671c2dee3a74b71b842ddc swfUrl=http://www.xuuby.com/player/iplayer2.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.xuuby.com/'
            comecarvideo(streamurl,nomecanal,True)

        elif re.search('yukons', link):
            print "Catcher: yukons"
            yukons=re.compile('kuyo&file=(.+?)&').findall(link)
            if not yukons: yukons=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not yukons: yukons=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not yukons: yukons=re.compile('file=(.+?)&').findall(link)
            for chname in yukons:
                streamurl='rtmp://198.144.153.143:443/kuyo playpath=' + chname + '?id=id=39302e3230362e3133312e3135 swfUrl=http://yukons.net/yplay.swf live=true timeout=15 swfVfy=true pageUrl=http://yukons.net'
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('yycast', link):
            print "Catcher: yycast"
            yycast=re.compile('fid="(.+?)";.+?</script><script type="text/javascript" src="http://www.yycast.com/javascript/embedPlayer.js"></script>').findall(link)
            if not yycast: yycast=re.compile("file='(.+?).flv'.+?</script>").findall(link)
            if not yycast: yycast=re.compile('fid="(.+?)".+?</script>').findall(link)
            for chname in yycast:
                streamurl='rtmp://live.yycast.com/lb playpath=' + chname + ' live=true timeout=15 swfUrl=http://cdn.yycast.com/player/player.swf pageUrl=http://www.yycast.com/embed.php?fileid='+chname+'&vw=768&vh=432'
                comecarvideo(streamurl,nomecanal,True)

        elif re.search('zcast.us', link):
            print "Catcher: zcast"
            zcast=re.compile('channel="(.+?)";.+?></script>').findall(link)
            for chname in zcast:
                embed='http://zcast.us/gen.php?ch=' + chname + '&width=700&height=480'
                streamurl='rtmp://gabon.zcast.us/liveedge' + ' playpath=' + url_frame + ' live=true timeout=15 swfVfy=1 swfUrl=http://player.zcast.us/player58.swf pageUrl=http://www.xuuby.com/'
                comecarvideo(streamurl,nomecanal,True)

        else:
            print "Catcher: noserver" 
            ok=mensagemok('TV Portuguesa','Servidor não suportado')
    except Exception:
        buggalo.onExceptionRaised()


def redirect(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    gurl=response.geturl()
    return gurl

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]                         
    return param

def comecarvideo(finalurl,name,directo):
    playlist = xbmc.PlayList(1)
    playlist.clear()
    if directo==True:
        thumb=''
        print name
        thumb=name.replace('Mais TVI-','maistvi-ver2.png').replace('AXN-','axn-ver2.png').replace('FOX-','fox-ver2.png').replace('RTP 1-','rtp1-ver2.png').replace('RTP 2-','rtp2-ver2.png').replace('SIC-','sic-ver3.png').replace('SPORTTV 1-','sptv1-ver2.png').replace('SPORTTV 1 HD-','sptv1-ver2.png').replace('SPORTTV 2-','sptv2-ver2.png').replace('SPORTTV 3-','sptv3-ver2.png').replace('SPORTTV 4-','sptv4-ver2.png').replace('TVI-','tvi-ver2.png').replace('Discovery Channel-','disc-ver2.png').replace('AXN Black-','axnb-ver2.png').replace('AXN White-','axnw-ver2.png').replace('FOX Crime-','foxc-ver2.png').replace('FOX Life-','foxl-ver3.png').replace('FOX Movies-','foxm-ver2.png').replace('Eurosport-','eusp-ver2.png').replace('Hollywood-','hwd-ver2.png').replace('MOV-','mov-ver2.png').replace('Canal Panda-','panda-ver2.png').replace('VH1-','vh1-ver2.png').replace('Benfica TV-','bentv-ver2.png').replace('Porto Canal-','pcanal-ver2.png').replace('Big Brother VIP-','bbvip-ver2.png').replace('SIC K-','sick-ver2.png').replace('SIC Mulher-','sicm-ver3.png').replace('SIC Noticias-','sicn-ver2.png').replace('SIC Radical-','sicrad-ver2.png').replace('TVI24-','tvi24-ver2.png').replace('TVI Ficção-','tvif-ver2.png').replace('Syfy-','syfy-ver1.png').replace('Odisseia-','odisseia-ver1.png').replace('História-','historia-ver1.png').replace('National Geographic Channel-','natgeo-ver1.png').replace('MTV-','mtv-ver1.png').replace('Optimus Alive 2013-','alive-ver2.png')
        print thumb
        name=name.replace('-','')
        progname=name
        if selfAddon.getSetting("prog-player2") == "true":
            try:
                progname=name.replace('SPORTTV 1','SPTV1').replace('SPORTTV 2','SPTV2').replace('SPORTTV 3','SPTV3').replace('SPORTTV 4','SPTV4').replace('Discovery Channel','DISCV').replace('AXN Black','AXNBL').replace('AXN White','AXNWH').replace('FOX Crime','FOXCR').replace('FOX Life','FLIFE').replace('FOX Movies','FOXM').replace('Eurosport','EURSP').replace('Hollywood','HOLLW').replace('Canal Panda','PANDA').replace('Benfica TV','SLB').replace('Porto Canal','PORTO').replace('Big Brother VIP','BBV').replace('SIC K','SICK').replace('SIC Mulher','SICM').replace('SIC Noticias','SICN').replace('SIC Radical','SICR').replace('TVI24','TVI24').replace('TVI Ficção','TVIF').replace('Mais TVI','MTVI').replace('Syfy-','SYFY').replace('Odisseia','ODIS').replace('História','HIST').replace('National Geographic Channel','NGC').replace('MTV','MTV')
                progname=programacao(progname,True)
                if progname=='':pass
                else: name=name + ' - ' + progname
            except: pass
        listitem = xbmcgui.ListItem(progname, iconImage="DefaultVideo.png", thumbnailImage=tvporpath + art + thumb)
    else: listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage='')
    listitem.setInfo("Video", {"Title":name})
    listitem.setProperty('IsPlayable', 'true')
    dialogWait = xbmcgui.DialogProgress()
    dialogWait.create('TV Portuguesa', 'A carregar')
    playlist.add(finalurl, listitem)
    dialogWait.close()
    del dialogWait
    if selfAddon.getSetting("playertype") == "0": player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    elif selfAddon.getSetting("playertype") == "1": player = xbmc.Player(xbmc.PLAYER_CORE_MPLAYER)
    elif selfAddon.getSetting("playertype") == "2": player = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
    elif selfAddon.getSetting("playertype") == "3": player = xbmc.Player(xbmc.PLAYER_CORE_PAPLAYER)
    else: player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    GA("player",name)
    player.play(playlist)

def addLink(name,url,iconimage):
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def addDir(name,url,mode,iconimage,total,pasta):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "overlay":6 } )
    liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

def clean(text):
    command={'\r':'','\n':'','\t':'','&nbsp;':''}
    regex = re.compile("|".join(map(re.escape, command.keys())))
    return regex.sub(lambda mo: command[mo.group(0)], text)

def parseDate(dateString):
    try: return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except: return datetime.datetime.today() - datetime.timedelta(days = 1) #force update

def checkGA():
    secsInHour = 60 * 60
    threshold  = 2 * secsInHour
    now   = datetime.datetime.today()
    prev  = parseDate(selfAddon.getSetting('ga_time'))
    delta = now - prev
    nDays = delta.days
    nSecs = delta.seconds
    doUpdate = (nDays > 0) or (nSecs > threshold)
    if not doUpdate:
        return
    selfAddon.setSetting('ga_time', str(now).split('.')[0])
    APP_LAUNCH()    
    
                    
def send_request_to_google_analytics(utm_url):
    try:
        req = urllib2.Request(utm_url, None,{'User-Agent':user_agent})
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)         
    return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VISITOR = selfAddon.getSetting('ga_visitor')
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
        except:
            print "================  CANNOT POST TO ANALYTICS  ================" 
            
            
def APP_LAUNCH():
        versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
        if versionNumber < 12:
            if xbmc.getCondVisibility('system.platform.osx'):
                if xbmc.getCondVisibility('system.platform.atv2'):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
            elif xbmc.getCondVisibility('system.platform.ios'):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility('system.platform.windows'):
                log_path = xbmc.translatePath('special://home')
                log = os.path.join(log_path, 'xbmc.log')
                logfile = open(log, 'r').read()
            elif xbmc.getCondVisibility('system.platform.linux'):
                log_path = xbmc.translatePath('special://home/temp')
            else:
                log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        elif versionNumber > 11:
            print '======================= more than ===================='
            log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        else:
            logfile='Starting XBMC (Unknown Git:.+?Platform: Unknown. Built.+?'
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        print '==========================   '+PATH+' '+versao+'  =========================='
        try:
            from hashlib import md5
        except:
            from md5 import md5
        from random import randint
        import time
        from urllib import unquote, quote
        from os import environ
        from hashlib import sha1
        import platform
        VISITOR = selfAddon.getSetting('ga_visitor')
        for build, PLATFORM in match:
            if re.search('12',build[0:2],re.IGNORECASE): 
                build="Frodo" 
            if re.search('11',build[0:2],re.IGNORECASE): 
                build="Eden" 
            if re.search('13',build[0:2],re.IGNORECASE): 
                build="Gotham" 
            print build
            print PLATFORM
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + versao + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except:
                print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================" 
checkGA()

params=get_params()
url=None
name=None
mode=None
srt=None
fic=None
instalada=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
    if selfAddon.getSetting("mensagemlibrtmp2") == "false":
        ok = mensagemok('TV Portuguesa','[B][COLOR red]IMPORTANTE! Nova actualização LIBRTMP.[/COLOR][/B]','Visite http://bit.ly/fightnightaddons para mais informacoes.','Mensagem: 23 de Junho')
    if selfAddon.getSetting("abrirlogolista") == "false": menu_principal()
    else: abrir_lista_canais()

elif mode==1: menu_principal()
elif mode==2: restarttv()
elif mode==3: restarttv_lista(name,url)
elif mode==4: restarttv_progs(name,url)
elif mode==5: obter_lista(name,url)
elif mode==6: listascanais()
elif mode==7: descobrirresolver(url,nomecanal,linkrecebido)
elif mode==8: restarttv_play(name,url)
elif mode==10: restarttv_pesquisa()
elif mode==11: xmltostrm(name,url)
elif mode==13: abrir_lista_canais()    
elif mode==15: ok = mensagemok('TV Portuguesa','A actualizacao é automática. Caso nao actualize va ao','repositorio fightnight e prima c ou durante 2seg','e force a actualizacao. De seguida, reinicie o XBMC.')
elif mode==16: request_servidores(url,name)
elif mode==22: selfAddon.openSettings()
elif mode==23: mensagemaviso()
#except Exception:
    #buggalo.onExceptionRaised()        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
