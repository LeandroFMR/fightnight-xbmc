# -*- coding: utf-8 -*-

""" TV Portuguesa
    2013 fightnight"""

import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re,sys, urllib, urllib2,time,datetime,os

versao = '0.1.02'
SptveuURL = 'http://www.sporttvhdmi.com/'
TVDezURL = 'http://www.estadiofutebol.com'
TVTugaURL = 'http://www.tvtuga.com'
TugastreamURL = 'http://www.tugastream.com/'
TVPTHDURL = 'http://www.tvportugalhd.org'
TVPTHDZuukURL = 'http://www.zuuk.pw'
TVCoresURL = 'http://tvfree2.me'
LSHDURL= 'http://livesoccerhq.com'
TVZuneURL = 'http://www.tvzune.tv/'
VBURL= 'http://www.videosbacanas.com/'
ResharetvURL = 'http://resharetv.com/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36'
addon_id = 'plugin.video.tvpor'
art = '/resources/art/'
selfAddon = xbmcaddon.Addon(id=addon_id)
tvporpath = selfAddon.getAddonInfo('path')
mensagemok = xbmcgui.Dialog().ok
menuescolha = xbmcgui.Dialog().select
mensagemprogresso = xbmcgui.DialogProgress()
pastaperfil = xbmc.translatePath(selfAddon.getAddonInfo('profile')).decode('utf-8')
downloadPath = selfAddon.getSetting('pastagravador')
PATH = "XBMC_TVPOR"
UATRACK="UA-39199007-1"

MODE_EPG = 'EPG'
MODE_TV = 'TV'
MODE_OSD = 'OSD'

ACTION_LEFT = 1
ACTION_RIGHT = 2
ACTION_UP = 3
ACTION_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_SELECT_ITEM = 7
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_SHOW_INFO = 11
ACTION_NEXT_ITEM = 14
ACTION_PREV_ITEM = 15

ACTION_MOUSE_WHEEL_UP = 104
ACTION_MOUSE_WHEEL_DOWN = 105
ACTION_MOUSE_MOVE = 107

KEY_NAV_BACK = 92
KEY_CONTEXT_MENU = 117
KEY_HOME = 159

CHANNELS_PER_PAGE = 9

#try:
if selfAddon.getSetting('ga_visitor')=='':
    from random import randint
    selfAddon.setSetting('ga_visitor',str(randint(0, 0x7fffffff)))

def entraraddon():
    buggalo_fix114()
    if selfAddon.getSetting("mensagemlibrtmp2") == "false": ok = mensagemok('TV Portuguesa','[B][COLOR red]IMPORTANTE! Nova actualização LIBRTMP.[/COLOR][/B]','Visite http://bit.ly/fightnightaddons para mais informacoes.','Mensagem: 23 de Junho')
    try:
        req = urllib2.Request('http://google.pt')
        req.add_header('User-Agent', user_agent)
        response = urllib2.urlopen(req)
        link=response.read()
        print "Com acesso a internet"
        resultado=True
    except:
        print "Sem acesso a internet"
        resultado=False

    if resultado==True:
        if selfAddon.getSetting("abrirlogolista") == "false": menu_principal()
        else: abrir_lista_canais()
    else:
        opcao= xbmcgui.Dialog().yesno('TV Portuguesa', 'Sem acesso à internet.', "", "",'Voltar a tentar', 'OK')
        if not opcao: entraraddon()


def menu_principal():
    GA("None","menuprincipal")
    if selfAddon.getSetting("mensagemfb2") == "true":
        ok = mensagemok('TV Portuguesa','Faz like na pagina do facebook para','obteres todas as novidades.','http://fb.com/fightnightxbmc')
        selfAddon.setSetting('mensagemfb2',value='false')
    addDir("Ver Canais",TVDezURL,13,tvporpath + art + 'vercanais-ver2.png',1,'',True)
    disponivel=versao_disponivel()
    if disponivel==versao: addLink('Última versao (' + versao+ ')','',tvporpath + art + 'versao-ver2.png')
    else: addDir('Instalada v' + versao + ' | Actualização v' + disponivel,TVDezURL,15,tvporpath + art + 'versao-ver2.png',1,'',False)
    addDir("Definições do addon",TVDezURL,22,tvporpath + art + 'defs-ver2.png',1,'',False)
    addDir("[COLOR red][B]LER AVISO[/B][/COLOR]",'nada',23,tvporpath + art + 'aviso-ver2.png',1,'',False)
    xbmc.executebuiltin("Container.SetViewMode(500)")

def abrir_url(url,erro=True):
    print "A fazer request de: " + url
    try:
        req = urllib2.Request(url)
        req.add_header('User-Agent', user_agent)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
    except urllib2.HTTPError, e:
        if erro==True:
            mensagemok('TV Portuguesa',str(urllib2.HTTPError(e.url, e.code, "Erro na página.", e.hdrs, e.fp)))
            sys.exit(0)
    except urllib2.URLError, e:
        if erro==True:
            mensagemok('TV Portuguesa',"Erro na página.")
            sys.exit(0)

def abrir_url_cookie(url,erro=True):

    print "A fazer request de: " + url
    try:
        hdr = {'User-Agent': user_agent, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}
        req = urllib2.Request(url, headers=hdr)
        page = urllib2.urlopen(req)
        content = page.read()
        return content
    except urllib2.HTTPError, e:
        if erro==True:
            mensagemok('TV Portuguesa',str(urllib2.HTTPError(e.url, e.code, "Erro na página.", e.hdrs, e.fp)))
            sys.exit(0)
    except urllib2.URLError, e:
        if erro==True:
            mensagemok('TV Portuguesa',"Erro na página.")
            sys.exit(0)

def versao_disponivel():
    try:
        link=abrir_url('http://fightnight-xbmc.googlecode.com/svn/addons/fightnight/plugin.video.tvpor/addon.xml')
        match=re.compile('name="TV Portuguesa"\r\n       version="(.+?)"\r\n       provider-name="fightnight">').findall(link)[0]
    except:
        ok = mensagemok('TV Portuguesa','Addon não conseguiu conectar ao servidor','de actualização. Verifique a situação.','')
        match='Erro. Verificar origem do erro.'
    return match

def savefile(filename, contents):
    try:
        destination = os.path.join(pastaperfil,filename)
        fh = open(destination, 'wb')
        fh.write(contents)  
        fh.close()
    except: print "Nao gravou os temporarios de: %s" % filename

def openfile(filename):
    try:
        destination = os.path.join(pastaperfil, filename)
        fh = open(destination, 'rb')
        contents=fh.read()
        fh.close()
        return contents
    except:
        print "Nao abriu os temporarios de: %s" % filename
        return None

def listascanais():
    addDir("[B]Desporto[/B]",'http://dl.dropbox.com/u/74834278/Desporto.xml',5,tvporpath + art + 'ces-desp-ver1.png',1,'',True)
    addDir("[B]Música[/B]",'http://dl.dropboxusercontent.com/u/74834278/Musica.xml',5,tvporpath + art + 'ces-mus-ver1.png',1,'',True)
    #addDir("[B]Infantil[/B]",'https://dl.dropboxusercontent.com/s/jmviwx7z9dakk6u/Canais%20Infantis.xml',5,tvporpath + art + 'ces-inf-ver1.png',1,'',True)
    addDir("[B]Ciências[/B]",'http://dl.dropbox.com/u/74834278/Tv%20Ciencia.xml',5,tvporpath + art + 'ces-ciencia-ver1.png',1,'',True)
    addDir("[B]Alemanha[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20Alema.xml',5,tvporpath + art + 'ces-alem-ver1.png',1,'',True)
    #addDir("[B]Brasil[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20Brasil.xml',5,tvporpath + art + 'ces-bras-ver1.png',1,'',True)
    addDir("[B]Espanha[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20Espanhola.xml',5,tvporpath + art + 'ces-espa-ver1.png',1,'',True)
    #addDir("[B]França[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20Francesa.xml',5,tvporpath + art + 'ces-fran-ver1.png',1,'',True)
    #addDir("[B]Itália[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20Italiana.xml',5,tvporpath + art + 'ces-ita-ver1.png',1,'',True)
    addDir("[B]UK[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20UK.xml',5,tvporpath + art + 'ces-uk-ver1.png',1,'',True)
    addDir("[B]USA[/B]",'http://dl.dropboxusercontent.com/u/74834278/Tv%20USA.xml',5,tvporpath + art + 'ces-usa-ver1.png',1,'',True)
    addDir("[B]Global[/B]",'http://dl.dropbox.com/u/88295111/pissos13.xml',5,tvporpath + art + 'pissos-ver1.png',1,'',True)
    addDir("[B]Portugal[/B]",'http://dl.dropboxusercontent.com/s/h9s0oiop70tjwe8/TV%20PORTUGUESA.txt',5,tvporpath + art + 'vercanais-ver2.png',1,'',True)
    addDir("[B]Filmes[/B]",'http://dl.dropboxusercontent.com/s/kk79s083x208zug/xml%20pt%20tv%20-%20nova.txt',5,tvporpath + art + 'vercanais-ver2.png',1,'',True)
    addDir("[B]Infantil[/B]",'http://dl.dropboxusercontent.com/s/kbly079op7kwaz2/INFANTIL%20TV%20POR.txt',5,tvporpath + art + 'vercanais-ver2.png',1,'',True)
    addDir("[B]Brasil[/B]",'http://dl.dropboxusercontent.com/s/9ilbiv4d83dlcrr/TV%20BRASILEIRA%20POR.txt',5,tvporpath + art + 'vercanais-ver2.png',1,'',True)
    #addLink("",'',tvporpath + art + 'listas-ver2.png')
    
    addDir("[B][COLOR white]A tua lista aqui?[/COLOR][/B]",TVDezURL,14,tvporpath + art + 'versao-ver2.png',1,'',False)
    xbmc.executebuiltin("Container.SetViewMode(500)")

def downloader(url,dest, useReq = False):
    dp = xbmcgui.DialogProgress()
    dp.create("TV Portuguesa","A fazer download...",'')

    if useReq:
        import urllib2
        req = urllib2.Request(url)
        req.add_header('Referer', 'http://wallpaperswide.com/')
        f       = open(dest, mode='wb')
        resp    = urllib2.urlopen(req)
        content = int(resp.headers['Content-Length'])
        size    = content / 100
        total   = 0
        while True:
            if dp.iscanceled(): 
                raise Exception("Canceled")                
                dp.close()

            chunk = resp.read(size)
            if not chunk:            
                f.close()
                break

            f.write(chunk)
            total += len(chunk)
            percent = min(100 * total / content, 100)
            dp.update(percent)       
    else:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        raise Exception("Canceled")
        dp.close()

def obter_lista(name,url):
    GA("None",name)
    titles = []; ligacao = []; thumb=[]
    link=abrir_url(url)
    link2=clean(link)
    listas=re.compile('<title>(.+?)</title>(.+?)<thumbnail>(.+?)</thumbnail>').findall(link2)
    for nomecanal,streams,thumbcanal in listas:
        streams2=re.compile('<link>(.+?)</link>').findall(streams)
        for rtmp in streams2:
#            if re.search('$doregex',rtmp):
#                #parametros=re.compile('<regex></regex>').findall(rtmp)
#                doRegexs = re.compile('\$doregex\[([^\]]*)\]').findall(rtmp)
#                    for k in doRegexs:
#                    
#                        if k in regexs:
#                            m = regexs[k]
#                            #if m['page'] in cachedPages:
#                            #    link = cachedPages[m['page']]
#                            #else:
#                            page=re.compile('<page>(.+?)</page>').findall(streams2)[0]
#                            req = urllib2.Request(page)
#                            req.add_header('User-Agent', user_agent)
#                            if re.search('<referer>',streams2):
#                                referer=re.compile('<referer>(.+?)</referer>').findall(streams2)[0]
#                                req.add_header('Referer', referer)
#                            response = urllib2.urlopen(req)
#                            link = response.read()
#                            response.close()
#                            expres=re.compile("""<expres>'file':'([^']*)<expres>""").findall(streams2)[0]
#                            reg = re.compile(expres).search(link)
#                            rtmp = url.replace("$doregex[" + k + "]", reg.group(1).strip())
                        

            if name=='[B]Eventos[/B] (Cesarix)':
                titles.append(nomecanal)
                ligacao.append(rtmp)
                thumb.append(thumbcanal)
            else:
                addCanal(nomecanal,rtmp,17,thumbcanal,len(listas),'')
                xbmcplugin.setContent(int(sys.argv[1]), 'Movies')

                    
    if name=='[B]Eventos[/B] (Cesarix)':
        if len(ligacao)==1: index=0
        elif len(ligacao)==0: ok=mensagemok('TV Portuguesa', 'Sem eventos disponiveis.'); return     
        else:
            index = xbmcgui.Dialog().select('Escolha o servidor', titles)
            if index > -1:
                urlescolha=ligacao[index]
                nomecanal=titles[index]
                #thumb123=thumbcanal[index]
                #print thumb123
                comecarvideo(urlescolha,nomecanal,'listas',False,thumb=tvporpath + art + 'vercanais-ver2.png')

def abrir_lista_canais():
    info_servidores()
    canais()

def canais():
    nrcanais=49
    canaison=[]
    empty='nada'
    GA("None","listacanais")
    programas=p_todos()
    #### GRAVADOR #####
    if selfAddon.getSetting("gravadoractivar") == "true": colorgravador='[COLOR green]ON[/COLOR]'
    else: colorgravador='[COLOR red]OFF[/COLOR]'

    ##### PREVENCAO OUTROS OS NAO SUPORTADOS:
    if xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.windows') or xbmc.getCondVisibility('system.platform.osx'):
        if selfAddon.getSetting("gravacoes") == "true": addDir('[B][COLOR white]Gravador[/COLOR] '+colorgravador+'[/B]',TVDezURL,12,tvporpath + art + 'gravador-ver1.png',1,'Aceda à lista das gravações já efectuadas',False)
    else: selfAddon.setSetting('gravadoractivar',value='false')
    ##### FIM GRAVADOR #####
    if selfAddon.getSetting("abrirlogolista") == "true":
        if selfAddon.getSetting("abrirlogolista-botao") == "true": addDir("[B][COLOR white]Menu Principal[/COLOR][/B]",TVDezURL,1,tvporpath + art + 'defs-ver2.png',1,'Clique aqui para voltar ao menu principal.',True)
    if selfAddon.getSetting("restarttv") == "true": addDir("[B][COLOR white]Restart TV[/COLOR][/B]",TVDezURL,2,tvporpath + art + 'restart-ver2.png',1,'Veja ou reveja os programas que já passaram na TV Portuguesa.',True)
    if selfAddon.getSetting("listas-pessoais") == "true": addDir("[B][COLOR white]Listas Pessoais[/COLOR][/B]",TVDezURL,6,tvporpath + art + 'listas-ver2.png',1,'Outras listas de canais criadas pela comunidade.',True)
    #addDir("[B][COLOR white]Zapping[/COLOR][/B]",empty,16,tvporpath + art + 'zapp-ver1.png',nrcanais,'Com esta funcionalidade, pode utilizar a tecla » do seu comando e correr a lista de todos os canais comodamente.',False)
    if selfAddon.getSetting("alterarvista") == "true": addDir("[B][COLOR white]Alterar Vista[/COLOR][/B]",TVDezURL,9,tvporpath + art + 'aviso-ver2.png',1,'Opção para alterar a vista da lista de canais.',False)
    #addDir("[B][COLOR red]TESTE[/COLOR][/B]",TVDezURL,2013,'',1,'Para testes',False)

    if selfAddon.getSetting("eventos") == "true": canaison.append('[B]Eventos[/B]'); addCanal("[B]Eventos[/B] (Cesarix)",'http://dl.dropboxusercontent.com/s/uppgigfhbt2rzo7/Eventos.xml',16,tvporpath + art + 'vercanais-ver2.png',nrcanais,'')
    if selfAddon.getSetting("canais-rtp1") == "true": canaison.append('[B]RTP 1[/B]'); addCanal("[B]RTP 1[/B] " + p_umcanal(programas,'RTP1',False),empty,16,tvporpath + art + 'rtp1-ver2.png',nrcanais,p_umcanal(programas,'RTP1',True))
    if selfAddon.getSetting("canais-rtp2") == "true":  canaison.append('[B]RTP 2[/B]'); addCanal("[B]RTP 2[/B] " + p_umcanal(programas,'RTP2',False),empty,16,tvporpath + art + 'rtp2-ver2.png',nrcanais,p_umcanal(programas,'RTP2',True))
    if selfAddon.getSetting("canais-sic") == "true":  canaison.append('[B]SIC[/B]'); addCanal("[B]SIC[/B] " + p_umcanal(programas,'SIC',False),empty,16,tvporpath + art + 'sic-ver3.png',nrcanais,p_umcanal(programas,'SIC',True))
    if selfAddon.getSetting("canais-tvi") == "true":  canaison.append('[B]TVI[/B]'); addCanal("[B]TVI[/B] " + p_umcanal(programas,'TVI',False),empty,16,tvporpath + art + 'tvi-ver2.png',nrcanais,p_umcanal(programas,'TVI',True))
    if selfAddon.getSetting("canais-sporttv1") == "true":
        canaison.append('[B]SPORTTV 1[/B]'); addCanal("[B]SPORTTV 1[/B] " + p_umcanal(programas,'SPTV1',False),empty,16,tvporpath + art + 'sptv1-ver2.png',nrcanais,p_umcanal(programas,'SPTV1',True))
        canaison.append('[B]SPORTTV 1 HD[/B]'); addCanal("[B]SPORTTV 1 HD[/B] " + p_umcanal(programas,'SPTV1',False),empty,16,tvporpath + art + 'sptvhd-ver2.png',nrcanais,p_umcanal(programas,'SPTV1',True))
    if selfAddon.getSetting("canais-sporttv2") == "true": canaison.append('[B]SPORTTV 2[/B]'); addCanal("[B]SPORTTV 2[/B] " + p_umcanal(programas,'SPTV2',False),empty,16,tvporpath + art + 'sptv2-ver2.png',nrcanais,p_umcanal(programas,'SPTV2',True))
    if selfAddon.getSetting("canais-sporttv3") == "true": canaison.append('[B]SPORTTV 3[/B]'); addCanal("[B]SPORTTV 3[/B] " + p_umcanal(programas,'SPTV3',False),empty,16,tvporpath + art + 'sptv3-ver2.png',nrcanais,p_umcanal(programas,'SPTV3',True))
    if selfAddon.getSetting("canais-sporttvlive") == "true": canaison.append('[B]SPORTTV LIVE[/B]'); addCanal("[B]SPORTTV LIVE[/B] " + p_umcanal(programas,'SPTVL',False),empty,16,tvporpath + art + 'sptvlive-ver1.png',nrcanais,p_umcanal(programas,'SPTVL',True))
    if selfAddon.getSetting("canais-benficatv") == "true": canaison.append('[B]Benfica TV[/B]'); addCanal("[B]Benfica TV[/B] " + p_umcanal(programas,'SLB',False),empty,16,tvporpath + art + 'bentv-ver2.png',nrcanais,p_umcanal(programas,'SLB',True))
    if selfAddon.getSetting("canais-portocanal") == "true": canaison.append('[B]Porto Canal[/B]'); addCanal("[B]Porto Canal[/B] " + p_umcanal(programas,'PORTO',False),empty,16,tvporpath + art + 'pcanal-ver2.png',nrcanais,p_umcanal(programas,'PORTO',True))
    if selfAddon.getSetting("canais-casadossegredos") == "true": canaison.append('[B]Casa dos Segredos 4[/B]'); addCanal("[B]Casa dos Segredos 4[/B] " + p_umcanal(programas,'SS',False),empty,16,tvporpath + art + 'casadseg-ver1.png',nrcanais,p_umcanal(programas,'ss',True))
    if selfAddon.getSetting("canais-abolatv") == "true": canaison.append('[B]A Bola TV[/B]'); addCanal("[B]A Bola TV[/B] " + p_umcanal(programas,'ABOLA',False),empty,16,tvporpath + art + 'abola-ver1.png',nrcanais,p_umcanal(programas,'ABOLA',True))
    if selfAddon.getSetting("canais-cmtv") == "true": canaison.append('[B]CM TV[/B]'); addCanal("[B]CM TV[/B] " + p_umcanal(programas,'CMTV',False),empty,16,tvporpath + art + 'cmtv-ver1.png',nrcanais,p_umcanal(programas,'CMTV',True))    
    if selfAddon.getSetting("canais-rtpac") == "true": canaison.append('[B]RTP Açores[/B]'); addCanal("[B]RTP Açores[/B] " + p_umcanal(programas,'RTPAC',False),empty,16,tvporpath + art + 'rtpac-ver1.png',nrcanais,p_umcanal(programas,'RTPAC',True))
    if selfAddon.getSetting("canais-rtpaf") == "true": canaison.append('[B]RTP Africa[/B]'); addCanal("[B]RTP Africa[/B] " + p_umcanal(programas,'RTPA',False),empty,16,tvporpath + art + 'rtpaf-ver1.png',nrcanais,p_umcanal(programas,'RTPA',True))
    if selfAddon.getSetting("canais-rtpi") == "true": canaison.append('[B]RTP Informação[/B]'); addCanal("[B]RTP Informação[/B] " + p_umcanal(programas,'RTPIN',False),empty,16,tvporpath + art + 'rtpi-ver1.png',nrcanais,p_umcanal(programas,'RTPIN',True))
    if selfAddon.getSetting("canais-rtpint") == "true": canaison.append('[B]RTP Internacional[/B]'); addCanal("[B]RTP Internacional[/B] " + p_umcanal(programas,'RTPINT',False),empty,16,tvporpath + art + 'rtpint-ver1.png',nrcanais,p_umcanal(programas,'RTPINT',True))
    if selfAddon.getSetting("canais-rtpmad") == "true": canaison.append('[B]RTP Madeira[/B]'); addCanal("[B]RTP Madeira[/B] " + p_umcanal(programas,'RTPMD',False),empty,16,tvporpath + art + 'rtpmad-ver1.png',nrcanais,p_umcanal(programas,'RTPMD',True))
    if selfAddon.getSetting("canais-rtpmem") == "true": canaison.append('[B]RTP Memória[/B]'); addCanal("[B]RTP Memória[/B] " + p_umcanal(programas,'RTPM',False),empty,16,tvporpath + art + 'rtpmem-ver1.png',nrcanais,p_umcanal(programas,'RTPM',True))   
    if selfAddon.getSetting("canais-sick") == "true": canaison.append('[B]SIC K[/B]'); addCanal("[B]SIC K[/B] " + p_umcanal(programas,'SICK',False),empty,16,tvporpath + art + 'sick-ver2.png',nrcanais,p_umcanal(programas,'SICK',True))
    if selfAddon.getSetting("canais-sicmulher") == "true": canaison.append('[B]SIC Mulher[/B]'); addCanal("[B]SIC Mulher[/B] " + p_umcanal(programas,'SICM',False),empty,16,tvporpath + art + 'sicm-ver3.png',nrcanais,p_umcanal(programas,'SICM',True))
    if selfAddon.getSetting("canais-sicnoticias") == "true": canaison.append('[B]SIC Noticias[/B]'); addCanal("[B]SIC Noticias[/B] " + p_umcanal(programas,'SICN',False),empty,16,tvporpath + art + 'sicn-ver2.png',nrcanais,p_umcanal(programas,'SICN',True))
    if selfAddon.getSetting("canais-sicradical") == "true": canaison.append('[B]SIC Radical[/B]'); addCanal("[B]SIC Radical[/B] " + p_umcanal(programas,'SICR',False),empty,16,tvporpath + art + 'sicrad-ver2.png',nrcanais,p_umcanal(programas,'SICR',True))
    if selfAddon.getSetting("canais-tvi24") == "true": canaison.append('[B]TVI24[/B]'); addCanal("[B]TVI24[/B] " + p_umcanal(programas,'TVI24',False),empty,16,tvporpath + art + 'tvi24-ver2.png',nrcanais,p_umcanal(programas,'TVI24',True))
    if selfAddon.getSetting("canais-tvificcao") == "true": canaison.append('[B]TVI Ficção[/B]'); addCanal("[B]TVI Ficção[/B] " + p_umcanal(programas,'TVIFIC',False),empty,16,tvporpath + art + 'tvif-ver2.png',nrcanais,p_umcanal(programas,'TVIFIC',True))
    if selfAddon.getSetting("canais-maistvi") == "true": canaison.append('[B]Mais TVI[/B]'); addCanal("[B]Mais TVI[/B] " + p_umcanal(programas,'SEM',False),empty,16,tvporpath + art + 'maistvi-ver2.png',nrcanais,p_umcanal(programas,'SEM',True))
    if selfAddon.getSetting("canais-hollywood") == "true": canaison.append('[B]Hollywood[/B]'); addCanal("[B]Hollywood[/B] " + p_umcanal(programas,'HOLLW',False),empty,16,tvporpath + art + 'hwd-ver2.png',nrcanais,p_umcanal(programas,'HOLLW',True))
    if selfAddon.getSetting("canais-mov") == "true": canaison.append('[B]MOV[/B]'); addCanal("[B]MOV[/B] " + p_umcanal(programas,'SEM',False),empty,16,tvporpath + art + 'mov-ver2.png',nrcanais,p_umcanal(programas,'SEM',True))
    if selfAddon.getSetting("canais-axn") == "true": canaison.append('[B]AXN[/B]'); addCanal("[B]AXN[/B] " + p_umcanal(programas,'AXN',False),empty,16,tvporpath + art + 'axn-ver2.png',nrcanais,p_umcanal(programas,'AXN',True))
    if selfAddon.getSetting("canais-axnblack") == "true": canaison.append('[B]AXN Black[/B]'); addCanal("[B]AXN Black[/B] " + p_umcanal(programas,'AXNBL',False),empty,16,tvporpath + art + 'axnb-ver2.png',nrcanais,p_umcanal(programas,'AXNBL',True))
    if selfAddon.getSetting("canais-axnwhite") == "true": canaison.append('[B]AXN White[/B]'); addCanal("[B]AXN White[/B] " + p_umcanal(programas,'AXNWH',False),empty,16,tvporpath + art + 'axnw-ver2.png',nrcanais,p_umcanal(programas,'AXNWH',True))
    if selfAddon.getSetting("canais-fox") == "true": canaison.append('[B]FOX[/B]'); addCanal("[B]FOX[/B] " + p_umcanal(programas,'FOX',False),empty,16,tvporpath + art + 'fox-ver2.png',nrcanais,p_umcanal(programas,'FOX',True))
    if selfAddon.getSetting("canais-foxcrime") == "true": canaison.append('[B]FOX Crime[/B]'); addCanal("[B]FOX Crime[/B] " + p_umcanal(programas,'FOXCR',False),empty,16,tvporpath + art + 'foxc-ver2.png',nrcanais,p_umcanal(programas,'FOXCR',True))
    if selfAddon.getSetting("canais-foxlife") == "true": canaison.append('[B]FOX Life[/B]'); addCanal("[B]FOX Life[/B] " + p_umcanal(programas,'FLIFE',False),empty,16,tvporpath + art + 'foxl-ver3.png',nrcanais,p_umcanal(programas,'FLIFE',True))
    if selfAddon.getSetting("canais-foxmovies") == "true": canaison.append('[B]FOX Movies[/B]'); addCanal("[B]FOX Movies[/B] " + p_umcanal(programas,'FOXM',False),empty,16,tvporpath + art + 'foxm-ver2.png',nrcanais,p_umcanal(programas,'FOXM',True))
    if selfAddon.getSetting("canais-syfy") == "true": canaison.append('[B]Syfy[/B]'); addCanal("[B]Syfy[/B] " + p_umcanal(programas,'SYFY',False),empty,16,tvporpath + art + 'syfy-ver1.png',nrcanais,p_umcanal(programas,'SYFY',True))
    if selfAddon.getSetting("canais-disney") == "true": canaison.append('[B]Disney Channel[/B]'); addCanal("[B]Disney Channel[/B] " + p_umcanal(programas,'DISNY',False),empty,16,tvporpath + art + 'disney-ver1.png',nrcanais,p_umcanal(programas,'DISNY',True))
    if selfAddon.getSetting("canais-cpanda") == "true": canaison.append('[B]Canal Panda[/B]'); addCanal("[B]Canal Panda[/B] " + p_umcanal(programas,'PANDA',False),empty,16,tvporpath + art + 'panda-ver2.png',nrcanais,p_umcanal(programas,'PANDA',True))
    if selfAddon.getSetting("canais-motors") == "true": canaison.append('[B]Motors TV[/B]'); addCanal("[B]Motors TV[/B] " + p_umcanal(programas,'MOTOR',False),empty,16,tvporpath + art + 'motors-ver1.png',nrcanais,p_umcanal(programas,'MOTOR',True))
    if selfAddon.getSetting("canais-discovery") == "true": canaison.append('[B]Discovery Channel[/B]'); addCanal("[B]Discovery Channel[/B] " + p_umcanal(programas,'DISCV',False),empty,16,tvporpath + art + 'disc-ver2.png',nrcanais,p_umcanal(programas,'DISCV',True))
    if selfAddon.getSetting("canais-odisseia") == "true": canaison.append('[B]Odisseia[/B]'); addCanal("[B]Odisseia[/B] " + p_umcanal(programas,'ODISS',False),empty,16,tvporpath + art + 'odisseia-ver1.png',nrcanais,p_umcanal(programas,'ODISS',True))
    if selfAddon.getSetting("canais-historia") == "true": canaison.append('[B]História[/B]'); addCanal("[B]História[/B] " + p_umcanal(programas,'HIST',False),empty,16,tvporpath + art + 'historia-ver1.png',nrcanais,p_umcanal(programas,'HIST',True))
    if selfAddon.getSetting("canais-ngc") == "true": canaison.append('[B]National Geographic Channel[/B]'); addCanal("[B]National Geographic Channel[/B] " + p_umcanal(programas,'NGC',False),empty,16,tvporpath + art + 'natgeo-ver1.png',nrcanais,p_umcanal(programas,'NGC',True))
    if selfAddon.getSetting("canais-eurosport") == "true": canaison.append('[B]Eurosport[/B]'); addCanal("[B]Eurosport[/B] " + p_umcanal(programas,'EURSP',False),empty,16,tvporpath + art + 'eusp-ver2.png',nrcanais,p_umcanal(programas,'EURSP',True))
    if selfAddon.getSetting("canais-espna") == "true": canaison.append('[B]ESPN America[/B]'); addCanal("[B]ESPN America[/B] " + p_umcanal(programas,'SEM',False),empty,16,tvporpath + art + 'espna-ver1.png',nrcanais,p_umcanal(programas,'SEM',True))
    if selfAddon.getSetting("canais-fashion") == "true": canaison.append('[B]Fashion TV[/B]'); addCanal("[B]Fashion TV[/B] " + p_umcanal(programas,'FASH',False),empty,16,tvporpath + art + 'fash-ver1.png',nrcanais,p_umcanal(programas,'FASH',True))
    if selfAddon.getSetting("canais-vh1") == "true": canaison.append('[B]VH1[/B]'); addCanal("[B]VH1[/B] " + p_umcanal(programas,'VH1',False),empty,16,tvporpath + art + 'vh1-ver2.png',nrcanais,p_umcanal(programas,'VH1',True))
    if selfAddon.getSetting("canais-mtv") == "true": canaison.append('[B]MTV[/B]'); addCanal("[B]MTV[/B] " + p_umcanal(programas,'MTV',False),empty,16,tvporpath + art + 'mtv-ver1.png',nrcanais,p_umcanal(programas,'MTV',True))
    try:
        canaison=''.join(canaison)      
        #savefile('canaison', canaison)
    except: pass
    xbmc.executebuiltin("Container.SetViewMode(500)")
    xbmcplugin.setContent(int(sys.argv[1]), 'livetv')
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )

'''
    #addCanal("[B]Disney Junior[/B] " + p_umcanal(programas,'DISNJ',False),empty,16,tvporpath + art + 'djun-ver1.png',nrcanais,False)
    #addCanal("[B]Panda Biggs[/B] " + p_umcanal(programas,'PANDAB',False),empty,16,tvporpath + art + 'pbiggs-ver1.png',nrcanais,False)
    #addCanal("[B]ESPN[/B] " + p_umcanal(programas,'ESPN',False),empty,16,tvporpath + art + 'espn-ver1.png',nrcanais,False)
    
    addCanal("[B]Chelsea TV[/B] " + p_umcanal(programas,'CHELS',False),empty,16,'',nrcanais,False)
    addCanal("[B]Discovery Turbo[/B] " + p_umcanal(programas,'DISCT',False),empty,16,'',nrcanais,False)
    addCanal("[B]Económico TV[/B] " + p_umcanal(programas,'ECONO',False),empty,16,'',nrcanais,False)
    addCanal("[B]Eurosport 2[/B] " + p_umcanal(programas,'EURS2',False),empty,16,'',nrcanais,False)
    addCanal("[B]Fuel TV[/B] " + p_umcanal(programas,'FUEL',False),empty,16,'',nrcanais,False)
    addCanal("[B]Nickelodeon[/B] " + p_umcanal(programas,'NICK',False),empty,16,'',nrcanais,False)
    addCanal("[B]SBT[/B] " + p_umcanal(programas,'SBT',False),empty,16,'',nrcanais,False)
    addCanal("[B]TLC[/B] " + p_umcanal(programas,'TLC',False),empty,16,'',nrcanais,False)
    addCanal("[B]TV Globo[/B] " + p_umcanal(programas,'GLOBO',False),empty,16,'',nrcanais,False)
    addCanal("[B]TV Record[/B] " + p_umcanal(programas,'TVrec',False),empty,16,'',nrcanais,False)
    #addCanal("[COLOR blue][B]Nr. de canais:[/B][/COLOR]" + nrcanais,'',16,'',nrcanais,False)
'''      

#################################### RESTART TV ##################
def restarttv():
    nrcanais=5
    GA("None","Restart TV")
    if selfAddon.getSetting("mensagemrestart") == "true":
            ok = mensagemok('TV Portuguesa','Serviço disponibilizado por Vídeos Bacanas.','Visita o site oficial.','http://www.videosbacanas.com/')
            selfAddon.setSetting('mensagemrestart',value='false')
    addDir("[B]RTP[/B]","RTP",3,tvporpath + art + 'rtp1-ver2.png',nrcanais,'',True)
    addDir("[B]SIC[/B]","SIC",3,tvporpath + art + 'sic-ver3.png',nrcanais,'',True)
    addDir("[B]SIC Noticias[/B]","SIC Notícias",3,tvporpath + art + 'sicn-ver2.png',nrcanais,'',True)
    addDir("[B]TVI[/B]","TVI",3,tvporpath + art + 'tvi-ver2.png',nrcanais,'',True)
    addDir("[B]TVI24[/B]","TVI 24",3,tvporpath + art + 'tvi24-ver2.png',nrcanais,'',True)
    addDir("[B]Pesquisa[/B]","Pesquisa",10,tvporpath + art + 'pesquisa-ver2.png',nrcanais,'',True)
    #restarttv_dailymotionfix()
    xbmc.executebuiltin("Container.SetViewMode(500)")

def restarttv_lista(name,url):
    GA("Restart TV",url)
    link=abrir_url(VBURL)
    link=clean(link)
    infocanal=re.compile('<a href="#">'+url+'</a><ul class="sub-menu">(.+?)</ul>').findall(link)[0]
    programas=re.compile('<li class=""><a title=".+?" href="(.+?)">(.+?)</a></li>').findall(infocanal)
    programas+=re.compile('<li class=""><a href="(.+?)">(.+?)</a></li>').findall(infocanal)
    #if not programas: programas=re.compile('<li class=""><a href="(.+?)">(.+?)</a></li>').findall(infocanal)
    for endereco,nomeprog in programas:
        addDir(nomeprog,endereco,4,tvporpath + art + 'restart-ver2.png',len(programas),'',True)

def restarttv_progs(name,url):
    link=abrir_url(url)
    link=link.replace('&#8211;','-').replace('&#8216;','').replace('&#8217;','')
    progs=re.compile('<h2><a href="(.+?)" title="(.+?)">').findall(link)
    for endereco,nomeprog in progs:
        addDir(nomeprog,endereco,8,tvporpath + art + 'restart-ver2.png',len(progs),'',False)
    restarttv_paginas(link)

def restarttv_dailymotionfix():
    if selfAddon.getSetting("dailymotionfix") == "true":
        try:
            print "A actualizar dailymotion"
            path = xbmc.translatePath(os.path.join('special://home/addons/script.module.urlresolver/lib/urlresolver/plugins',''))
            lib=os.path.join(path, 'dailymotion.py')
            os.remove(lib)
            urldaily = 'http://raw.github.com/the-one-/script.module.urlresolver/master/lib/urlresolver/plugins/dailymotion.py'
            downloader(urldaily,lib)
            selfAddon.setSetting('dailymotionfix',value='false')
        except: print "Erro ao actualizar dailymotion"

def buggalo_fix114():
    if selfAddon.getSetting("buggalofix") == "true":
        try:
            urlfusion='http://fightnight-xbmc.googlecode.com/svn/buggalo/script.module.buggalo.zip' #v1.1.4
            path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
            lib=os.path.join(path, 'script.module.buggalo.zip')
            downloader(urlfusion,lib)
            addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
            xbmc.sleep(2000)
            dp = xbmcgui.DialogProgress()
            dp.create("TV Portuguesa", "A instalar...")
            try:
                print "A extrair buggalo"
                import extract
                extract.all(lib,addonfolder,dp)
            except: print "Nao conseguiu extrair buggalo"
            selfAddon.setSetting('buggalofix',value='false')
        except: print "Erro ao actualizar buggalo"

def restarttv_sapo(name,link):
    dp = xbmcgui.DialogProgress()
    dp.create("A criar lista de vídeos",'Criando...')
    dp.update(0)
    playlist = xbmc.PlayList(1)
    playlist.clear()
    videoindividual=re.compile('<iframe src="http://videos.sapo.pt/playhtml.+?file=(.+?)"').findall(link)
    dp.create("TV Portuguesa",'Criando...')
    dp.update(0)
    for endvideo in videoindividual:
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage='')
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(endvideo,listitem)
        progress = len(playlist) / float(len(videoindividual)) * 100               
        dp.update(int(progress), 'A adicionar à playlist.')
    dp.close()
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    xbmcPlayer.play(playlist)


def restarttv_play(name,url):
    mensagemprogresso.create('TV Portuguesa', 'A carregar...')
    if mensagemprogresso.iscanceled(): 
        raise Exception("Canceled")                
        mensagemprogresso.close()
    mensagemprogresso.update(50)
    import urlresolver
    link=abrir_url(url)
    if re.search('dailymotion',link):
        daily=re.compile('<iframe frameborder="0" width=".+?" height=".+?" src="http://www.dailymotion.com/embed/video/(.+?)"></iframe>').findall(link)[0]
        embedvideo='http://www.dailymotion.com/video/' + daily
    elif re.search('youtube',link):
        youtube=re.compile('<iframe.+?src="http://www.youtube.com/embed/(.+?)".+?></iframe>').findall(link)[0]
        embedvideo='http://www.youtube.com/watch?v=' + youtube
    elif re.search('videos.sapo.pt',link):
        restarttv_sapo(name,link)
        return
    else: ok=mensagemok("TV Portuguesa", "Nenhum servidor compativel"); return
    mensagemprogresso.update(100)
    mensagemprogresso.close()
    sources=[]
    hosted_media = urlresolver.HostedMediaFile(url=embedvideo)
    sources.append(hosted_media)
    source = urlresolver.choose_source(sources)
    if source:
        linkescolha=source.resolve()
        if linkescolha==False:
            mensagemok('TV Portuguesa','Conteudo não disponível (removido).')
            return
        comecarvideo(linkescolha,name,False,zapping)

def restarttv_pesquisa():
      keyb = xbmc.Keyboard('', 'TV Portuguesa - Restart TV')
      keyb.doModal()
      if (keyb.isConfirmed()):
            search = keyb.getText()
            encode=urllib.quote_plus(search)
            if encode=='': pass
            else: restarttv_progs('',VBURL + '?s=' + encode)

def restarttv_paginas(link):
    try:
        paginas=re.compile('<span class="current">.+?</span>' + "<a href='(.+?)'" + ' class="inactive">(.+?)</a>').findall(link)
        for endereco, nrseg in paginas:
            addDir('[B][COLOR blue]Próxima pagina ('+nrseg+') >>[/COLOR][/B]',endereco,4,'',len(paginas),'',True)
    except: pass

#################### CAPTURA SERVERS ###############

def info_servidores():
    pleasewait='Por favor aguarde. '
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('A capturar fontes','A carregar lista de servidores.',pleasewait)
    if selfAddon.getSetting("fontes-livesoccerhd") == "true":
        try:
            dialogWait.update(0,'',pleasewait + '(LivesoccerHD)')
            if dialogWait.iscanceled(): return
            from t0mm0.common.net import Net
            net = Net()
            linkinicial=abrir_url(LSHDURL + '/programacao.php')
            urlintermedio=re.compile('<iframe.+?src="(.+?)"').findall(linkinicial)[0]
            ref_data = {'Referer': LSHDURL,'User-Agent':user_agent}
            linkintermedio = net.http_GET(urlintermedio,ref_data).content
            linkintermedio=abrir_url_cookie(urlintermedio,erro=False)
            lshdfinal='\n'.join(re.compile("<a style='font-size:(.+?)</font></a>").findall(linkintermedio))
            savefile('livesoccerhd', lshdfinal)
        except: savefile('livesoccerhd', '')
    if selfAddon.getSetting("fontes-resharetv") == "true":
        try:
            dialogWait.update(12,'',pleasewait + '(ReshareTV)')
            if dialogWait.iscanceled(): return
            resharetvlink=limparcomentarioshtml(abrir_url(ResharetvURL,erro=False),ResharetvURL)
            resharefinal='\n'.join(re.compile('<li>(.+?)</li>').findall(resharetvlink))
            savefile('resharetv', resharefinal)
        except: savefile('resharetv', '')
    if selfAddon.getSetting("fontes-thesporttveu") == "true":
        try:
            dialogWait.update(25,'',pleasewait + '(Thesporttv.eu)')
            if dialogWait.iscanceled(): return
            sptveulink=abrir_url(SptveuURL,erro=False)
            if re.search('<script>window.location=',sptveulink) or re.search('jdfwkey',sptveulink):
                try:
                    key=re.compile('<script>window.location="/(.+?)";</script>').findall(sptveulink)[0]
                    sptveulink=abrir_url(SptveuURL + key,erro=False)
                except: pass
            sptvfinal='\n'.join(re.compile('<th scope="col">(.+?)</th>').findall(sptveulink))
            savefile('thesporttveu', sptvfinal)
        except: savefile('thesporttveu', '')
    if selfAddon.getSetting("fontes-tugastream") == "true":
        try:
            dialogWait.update(37,'',pleasewait + '(Tugastream)')
            if dialogWait.iscanceled(): return
            tugastreamlink=abrir_url(TugastreamURL,erro=False)
            savefile('tugastream', tugastreamlink)
        except: savefile('tugastream', '')
    if selfAddon.getSetting("fontes-tvacores") == "true":
        try:
            dialogWait.update(50,'',pleasewait + '(TV a Cores)')
            if dialogWait.iscanceled(): return
            tvacoreslink=clean(abrir_url(TVCoresURL + '/ver?limit=0&filter_order=&filter_order_Dir=&limitstart=',erro=False))
            tvcfinal='\n'.join(re.compile('<strong class="list-title">(.+?)</strong>').findall(tvacoreslink))
            savefile('tvacores', tvcfinal)
        except: savefile('tvacores', '')
    if selfAddon.getSetting("fontes-tvdez") == "true":
        try:
            dialogWait.update(62,'',pleasewait + '(TVDez)')
            tvdezlink= clean(abrir_url_cookie(TVDezURL,erro=False))
            tvdezfinal='\n'.join(re.compile('<div class="canal">(.+?)</div>').findall(tvdezlink))
            savefile('tvdez', tvdezfinal)
        except: savefile('tvdez', '')
    if selfAddon.getSetting("fontes-tvtuga") == "true":
        try:
            dialogWait.update(75,'',pleasewait + '(TVTuga)')
            if dialogWait.iscanceled(): return
            tvtugalink=abrir_url_cookie(TVTugaURL + '/category/portugal/',erro=False)
            tvtugafinal='\n'.join(re.compile('<option class="ddpl-form2" (.+?)/option>').findall(tvtugalink))
            savefile('tvtuga', tvtugafinal)
        except: savefile('tvtuga', '')
    if selfAddon.getSetting("fontes-tvzune") == "true":
        try:
            dialogWait.update(87,'',pleasewait + '(TVZune)')
            if dialogWait.iscanceled(): return
            tvzunelink=abrir_url_cookie(TVZuneURL,erro=False)
            tvzunefinal='\n'.join(re.compile('location.href=(.+?)"').findall(tvzunelink))
            savefile('tvzune', tvzunefinal)
        except: savefile('tvzune', '')
    if selfAddon.getSetting("fontes-tvpthdorg") == "true":
        try:
            dialogWait.update(100,'',pleasewait + '(TVPortugalHD.org)')
            if dialogWait.iscanceled(): return
            tvpthdorglink=clean(abrir_url(TVPTHDZuukURL,erro=False))
            tvptfinal='\n'.join(re.compile('<li>(.+?)</li>').findall(tvpthdorglink))
            savefile('tvportugalhd', tvptfinal)
        except: savefile('tvportugalhd', '')
    dialogWait.close()

def request_servidores(url,name):
    if name=='[B]Eventos[/B] (Cesarix)':
        obter_lista(name,url)
        return
    name=name.replace('[','-')
    nome=re.compile('B](.+?)/B]').findall(name)[0]
    nomega=nome.replace('-','')
    GA("listacanais",nomega)
    titles=[]; ligacao=[]
    if nome=='-COLOR white]Zapping-/COLOR]-': zapping(nome)
    else:
        ########################################LIVESOCCERHD############################
        if selfAddon.getSetting("fontes-livesoccerhd") == "true":
            try:
                lshdref=int(0)
                lshdlink=openfile('livesoccerhd')
                nomelshd=nome.replace('SPORTTV 1-','SPTV 1').replace('SPORTTV 2-','SPTV 2').replace('SPORTTV 3-','SPTV 3').replace('SPORTTV LIVE-','SPTV LIVE').replace('Benfica TV-','BENFICA TV')
                lshd=re.compile("href='(.+?)'>.+?</span>"+nomelshd+".+?/span>").findall(lshdlink)
                if lshd:
                    for resto in lshd:
                        lshdref=int(lshdref + 1)
                        if len(lshd)==1:
                            lshd2=str('')
                        else:
                            lshd2=' #' + str(lshdref)
                        titles.append('LivesoccerHD' + lshd2)
                        ligacao.append(resto)
                        
            except: pass

        ########################################RESHARETV############################
        if selfAddon.getSetting("fontes-resharetv") == "true":
            try:
                resharetv=False
                resharetvref=int(0)
                resharetvlink=openfile('resharetv')
                nomeresharetv=nome.replace('SPORTTV 1-','Sport Tv1').replace('SPORTTV 2-','Sport Tv2').replace('SPORTTV 3-','Sport Tv3').replace('SPORTTV LIVE-','Sport Tv Live').replace('RTP 1-','Rtp 1').replace('RTP 2-','Rtp 2').replace('SIC-','Sic').replace('TVI-','Tvi').replace('Big Brother VIP-','Tvi Direct').replace('SIC Noticias-','Sic Not&iacute;cias').replace('MTV-','Mtv').replace('RTP Informação-','Rtp Informa&ccedil;&atilde;o').replace('VH1-','Vh1').replace('Fashion TV-','FashionTV').replace('Benfica TV-','Benfica TV')
                resharetv=re.compile('<a href="/(.+?)".+?>'+nomeresharetv+'</a>').findall(resharetvlink)
                if not resharetv:
                    resharetvlink=clean(resharetvlink)
                    resharetv=re.compile('<a href="/(.+?)" target="box" >'+nomeresharetv+'</a>.+?</ul>').findall(resharetvlink)
                    extralinks=re.compile('<a href="/.+?" target="box" >'+nomeresharetv+'</a>(.+?)</ul>').findall(resharetvlink)[0]
                    blabla=re.compile('<a href="/(.+?)" target="box" >').findall(extralinks)
                    for links in blabla:
                        resharetv.append(links)
                if resharetv:
                    for codigo in resharetv:
                        resharetvref=int(resharetvref + 1)
                        if len(resharetv)==1: resharetv2=str('')
                        else: resharetv2=' #' + str(resharetvref)
                        titles.append('ReshareTV' + resharetv2)
                        ligacao.append(ResharetvURL + codigo)
            except: pass


        ########################################THESPORTTVEU############################
        if selfAddon.getSetting("fontes-thesporttveu") == "true":
            try:
                sptveuref=int(0)
                sptveulink=openfile('thesporttveu')
                nomesptveu=nome.replace('SPORTTV 1-','Sporttv1').replace('SPORTTV 1 HD-','Sporttv1-v').replace('SPORTTV 2-','Sporttv2').replace('SPORTTV 3-','Sporttv3').replace('SPORTTV LIVE-','Sporttv-live').replace('Benfica TV-','Benficatv').replace('TVI-','Tvi')
                sptveu=re.compile('<a href="' + nomesptveu + '(.+?)" target="_blank"><img src=').findall(sptveulink)
                if sptveu:
                    for resto in sptveu:
                        sptveuref=int(sptveuref + 1)
                        if len(sptveu)==1:
                            sptveu2=str('')
                        else:
                            sptveu2=' #' + str(sptveuref)
                        titles.append('Thesporttv.eu' + sptveu2)
                        ligacao.append(SptveuURL + nomesptveu + resto)
                        
            except: pass


        ########################################TV A CORES############################
        if selfAddon.getSetting("fontes-tvacores") == "true":
            try:
                tvacoresref=int(0)
                tvacoreslink=openfile('tvacores')
                nometvacores=nome.replace('RTP 1-','RTP 1 Online').replace('RTP 2-','RTP 2 Online').replace('SIC-','SIC Online').replace('TVI-','TVI Online').replace('SPORTTV 1-','Sporttv Direto').replace('Big Brother VIP-','BB VIP').replace('SIC K-','SIC K Online').replace('SIC Radical-','SIC Radical Online').replace('SIC Mulher-','SIC Mulher Online').replace('SIC Noticias-','SIC Noticias Online').replace('TVI24-','TVI24 online').replace('Hollywood-','Canal Hollywood').replace('MOV-','Canal MOV').replace('AXN-','AXN Portugal').replace('AXN Black-','AXN Black Online').replace('AXN White-','AXN White online').replace('FOX-','Fox Online PT').replace('FOX Crime-','FOX Crime Online').replace('FOX Life-','FOX Life Online').replace('FOX Movies-','FOX Movies Portugal').replace('Canal Panda-','Canal Panda').replace('Discovery Channel-','Discovery Channel PT').replace('Eurosport-','Eurosport Portugal').replace('Benfica TV-','Benfica TV Online').replace('Porto Canal-','Porto Canal - Emissão Online').replace('Syfy-','SYFY Channel Portugal').replace('Odisseia-','Canal Odisseia').replace('História-','Canal Historia Portugal').replace('National Geographic Channel-','National Geographic PT').replace('MTV-','MTV Portugal').replace('RTP Açores-','RTP Açores Online').replace('RTP Africa-','RTP África Online').replace('RTP Informação-','RTP Informação - Emissão Online').replace('RTP Madeira-','RTP Madeira Online').replace('RTP Memória-','RTP Memória').replace('Disney Channel-','Disney Portugal').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV Online').replace('ESPN-','ESPN USA').replace('ESPN America-','ESPN Online BR').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Açores-','RTP Açores').replace('A Bola TV-','A Bola TV').replace('Casa dos Segredos 4-','Secret Story 4 em Direto').replace('CM TV-','CMTV em direto').replace('TVI Ficção-','TVI Ficção online')
                tvacores=re.compile('<a href="(.*?)">'+nometvacores+'</a>').findall(tvacoreslink)
                if tvacores:
                    for codigo in tvacores:
                        tvacoresref=int(tvacoresref + 1)
                        if len(tvacores)==1: tvacores2=str('')
                        else: tvacores2=' #' + str(tvacoresref)
                        titles.append('TV a Cores' + tvacores2)
                        ligacao.append(TVCoresURL + codigo)
            except: pass
                  
        ########################################TUGASTREAM############################
        if selfAddon.getSetting("fontes-tugastream") == "true":
            try:
                tugastreamref=int(0)
                tugastreamlink=openfile('tugastream')
                nometugastream=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('SIC-','sic').replace('AXN Black-','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV LIVE-','sporttvlive').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Porto Canal-','portocanal').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao').replace('Syfy-','syfy').replace('Benfica TV-','benficatv').replace('CM TV-','cmtv').replace('RTP Africa-','rtpafrica').replace('RTP Informação-','rtpinformacao').replace('Fashion TV-','fashiontv').replace('ESPN-','espn').replace('RTP Africa-','rtpafrica').replace('RTP Madeira-','rtpmadeira').replace('RTP Internacional-','rtpinternacional').replace('Casa dos Segredos 4-','secretstory')
                tugastream=re.compile('<a href="'+nometugastream + '(.+?)php">').findall(tugastreamlink)
                if tugastream:
                    for codigo in tugastream:
                        tugastreamref=int(tugastreamref + 1)
                        if len(tugastream)==1: tugastream2=str('')
                        else: tugastream2=' #' + str(tugastreamref)
                        titles.append('Tugastream' + tugastream2)
                        ligacao.append(TugastreamURL + nometugastream + codigo + 'php?altura=432&largura=768')
            except: pass

        ########################################TVTUGA############################
        if selfAddon.getSetting("fontes-tvtuga") == "true":
            try:
                tvtugaref=int(0)
                tvtugalink=openfile('tvtuga')
                
                nometvtuga=nome.replace('RTP 1-','rtp-1').replace('RTP 2-','rtp-2').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('SIC-','sic').replace('AXN Black-','axnblack').replace('AXN White-','axn-white').replace('FOX Life-','fox-life').replace('FOX Crime-','fox-crime').replace('FOX Movies-','fox-movies').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('SPORTTV LIVE-','sporttvlive').replace('Canal Panda-','canal-panda').replace('Hollywood-','canal-hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('Porto Canal-','portocanal').replace('SIC Noticias-','sic-noticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvi-ficcao').replace('Syfy-','syfy').replace('Benfica TV-','benfica-tv').replace('CM TV-','cm-tv').replace('RTP Africa-','rtp-africa').replace('RTP Informação-','rtp-informacao').replace('Fashion TV-','fashiontv').replace('ESPN-','espn').replace('A Bola TV-','abola-tv').replace('Casa dos Segredos 4-','secret-story-4-casa-dos-segredos').replace('RTP Açores-','rtp-acores').replace('RTP Internacional-','rtp-internacional').replace('RTP Madeira-','rtp-madeira').replace('RTP Memória-','rtp-memoria').replace('TVI24-','tvi-24')

                tvtuga=re.compile('value="http://www.tvtuga.com/'+nometvtuga+'(.+?)">').findall(tvtugalink)
                if tvtuga:
                    for codigo in tvtuga:
                        tvtugaref=int(tvtugaref + 1)
                        if len(tvtuga)==1: tvtuga2=str('')
                        else: tvtuga2=' #' + str(tvtugaref)
                        titles.append('TVTuga' + tvtuga2)
                        ligacao.append(TVTugaURL + '/' + nometvtuga + codigo)
            except: pass

                
        ########################################TVDEZ############################
        if selfAddon.getSetting("fontes-tvdez") == "true":
            try:
                tvdezref=int(0)
                tvdezlink=openfile('tvdez')
                tvdezlink=tvdezlink.replace('+ TVI','Mais TVI')
                nometvdez=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('FOX-','FOX').replace('AXN-','AXN').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('SPORTTV 3-','Sport TV 3').replace('SPORTTV LIVE-','Sporttv Live').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','Canal MOV').replace('VH1-','VH1 Hits').replace('Porto Canal-','Porto Canal').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('TVI Ficção-','TVI Fic&ccedil;&atilde;o').replace('Benfica TV-','Benfica TV').replace('Discovery Channel-','Discovery Channel').replace('TVI24-','TVI 24').replace('Mais TVI-','Mais TVI').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Hist&oacute;ria').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV').replace('CM TV-','Correio da Manh&atilde; TV').replace('RTP Açores-','RTP A&ccedil;ores').replace('RTP Informação-','RTP Informa&ccedil;&atilde;o').replace('RTP Madeira-','RTP Madeira').replace('RTP Memória-','RTP Mem&oacute;ria').replace('Disney Channel-','Disney Channel').replace('Fashion TV-','Fashion TV').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV').replace('ESPN-','ESPN').replace('ESPN America-','ESPN').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Memória-','RTP Mem&oacute;ria').replace('RTP Açores-','RTP A&ccedil;ores').replace('Casa dos Segredos 4-','Casa dos segredos 4')
                tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                if not tvdez:
                    nometvdez=nome.replace('SPORTTV 1-','Sport TV 1').replace('SPORTTV 2-','Sport TV 2').replace('SIC-','SIC').replace('TVI-','TVI').replace('SIC Noticias-','SIC Not&iacute;cias').replace('Big Brother VIP-','Big Brother VIP 2013').replace('Benfica TV-','Benfica-TV').replace('Casa dos Segredos 4-','Casa dos segredos 4')
                    tvdez=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                    nometvdez=nome.replace('SPORTTV 1-','Sporttv em Directo').replace('SPORTTV 2-','Sporttv 2').replace('SIC-','SIC Online - Stream 2').replace('TVI-','TVI Online - Stream 2').replace('SIC Noticias-','SIC Not&iacute;cias Online').replace('Big Brother VIP-','Big Brother Portugal').replace('Benfica TV-','Benfica-TV')
                    tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                    nometvdez=nome.replace('SPORTTV 1-','Sporttv HD')
                    tvdez+=re.compile('<a href="(.+?)" title="'+nometvdez+'">').findall(tvdezlink)
                if tvdez:
                    for codigo in tvdez:
                        tvdezref=int(tvdezref + 1)
                        if len(tvdez)==1: tvdez2=str('')
                        else: tvdez2=' #' + str(tvdezref)
                        titles.append('TVDez' + tvdez2)
                        ligacao.append(TVDezURL + codigo)
            except: pass


        ########################################TVZUNE############################
        if selfAddon.getSetting("fontes-tvzune") == "true":
            try:
                tvzuneref=int(0)
                tvzunelink=openfile('tvzune')
                nometvzune=nome.replace('RTP 1-','rtp1').replace('RTP 2-','rtp2').replace('SIC-','sic').replace('SPORTTV 1-','sporttv1').replace('SPORTTV 2-','sporttv2').replace('SPORTTV 3-','sporttv3').replace('TVI-','tvi').replace('FOX-','fox').replace('AXN-','axn').replace('Discovery Channel-','discovery').replace('AXN Black','axnblack').replace('AXN White-','axnwhite').replace('FOX Life-','foxlife').replace('FOX Crime-','foxcrime').replace('FOX Movies-','foxmovies').replace('Canal Panda-','panda').replace('Hollywood-','hollywood').replace('Eurosport-','eurosport').replace('MOV-','mov').replace('VH1-','vh1').replace('TVI24-','tvi24').replace('SIC Noticias-','sicnoticias').replace('SIC Radical-','sicradical').replace('SIC Mulher-','sicmulher').replace('SIC K-','sick').replace('Big Brother VIP-','bigbrothervip').replace('TVI Ficção-','tvificcao')
                tvzune=re.compile("'iframe/channel.php.+?ch=" + nometvzune + "'").findall(tvzunelink)
                if tvzune:
                    for resto in tvzune:
                        tvzuneref=int(tvzuneref + 1)
                        if len(tvzune)==1: tvzune2=str('')
                        else: tvzune2=' #' + str(tvzuneref)
                        titles.append('TVZune' + tvzune2)
                        ligacao.append(TVZuneURL + 'iframe/channel.php?ch=' + nometvzune)
            except: pass  

        ######################################TVPORTUGALHD.ORG########################
        if selfAddon.getSetting("fontes-tvpthdorg") == "true":
            try:
                nometvpthdorg=nome.replace('RTP 1-','RTP').replace('RTP 2-','RTP 2').replace('SIC-','SIC').replace('SPORTTV 1-','SPORTTV 1').replace('SPORTTV 2-','SPORTTV 2').replace('SPORTTV 3-','SPORTTV 3').replace('SPORTTV LIVE-','SPORTTV Live').replace('SIC-','SIC').replace('TVI-','TVI').replace('FOX-','FOX').replace('AXN-','AXN').replace('Discovery Channel-','Discovery Channel').replace('AXN Black-','AXN Black').replace('AXN White-','AXN White').replace('FOX Life-','FOX Life').replace('FOX Crime-','FOX Crime').replace('FOX Movies-','FOX Movies').replace('Canal Panda-','Canal Panda').replace('Hollywood-','Hollywood').replace('Eurosport-','Eurosport').replace('MOV-','MOV').replace('VH1-','VH1').replace('Benfica TV-','Benfica TV').replace('Porto Canal-','Porto Canal').replace('TVI24-','TVI24').replace('SIC Noticias-','SIC Noticias').replace('SIC Radical-','SIC Radical').replace('SIC Mulher-','SIC Mulher').replace('SIC K-','SIC K').replace('Big Brother VIP-','Big Brother Vip1').replace('TVI Ficção-','TVI Ficção').replace('Syfy-','Syfy').replace('Odisseia-','Odisseia').replace('História-','Historia').replace('National Geographic Channel-','National Geographic').replace('MTV-','MTV').replace('RTP Africa-','RTP Africa').replace('RTP Informação-','RTP Informação').replace('RTP Madeira-','RTP Madeira').replace('Disney Channel-','Disney Channel').replace('Panda Biggs-','Panda Biggs').replace('A Bola TV-','A Bola TV').replace('RTP Açores-','RTP Açores').replace('RTP Informação-','RTP Informa&ccedil;&atilde;o').replace('RTP Madeira-','RTP Madeira').replace('Disney Channel-','Disney Channel').replace('Fashion TV-','Fashion TV').replace('Disney Junior-','Disney Junior').replace('Panda Biggs-','Panda Biggs').replace('Motors TV-','Motors TV').replace('ESPN-','ESPN').replace('ESPN America-','ESPN America').replace('A Bola TV-','A Bola TV').replace('RTP Africa-','RTP Africa').replace('RTP Madeira-','RTP Madeira').replace('RTP Internacional-','RTP Internacional').replace('RTP Memória-','RTP Memoria').replace('Casa dos Segredos 4-','Secret Story 4').replace('CM TV-','CMTV')
                tvpthdorglink=openfile('tvportugalhd')
                tvpthdorgref=int(0)
                nometvpthdorg=urllib.quote(nometvpthdorg)
                tvpthdorg=re.compile("<a dir='ltr' href='http://www.zuuk.pw/search/label/" + nometvpthdorg + "'>.+?</a>").findall(tvpthdorglink)
                reftvpth=1
                if not tvpthdorg:
                    tvpthdorg=re.compile("<a dir='ltr' href='http://www.zuuk.pw/search/label/" + nometvpthdorg + "(.+?)>.+?</a>").findall(tvpthdorglink)
                    reftvpth=0
                if tvpthdorg:
                    for codigotv in tvpthdorg:
                        tvpthdorgref=int(tvpthdorgref + 1)
                        if len(tvpthdorg)==1: tvpthdorg2=str('')
                        else:
                            if tvpthdorgref==1: tvpthdorg2=' #' + str(tvpthdorgref)
                            else: tvpthdorg2=' #' + str(tvpthdorgref)# + '[COLOR red] (indisponivel)[/COLOR]'
                        codigotv=codigotv.replace("'",'')
                        titles.append('TVPortugal HD.org' + tvpthdorg2)
                        if reftvpth==1: ligacao.append('http://www.zuuk.pw/search/label/' + nometvpthdorg)
                        else: ligacao.append('http://www.zuuk.pw/search/label/' + nometvpthdorg + codigotv)
            except: pass
        if selfAddon.getSetting("gravadoractivar") == "true":
            if selfAddon.getSetting("localizacaortmpdump") == "":
                ok = mensagemok('TV Portuguesa','Faz download do ficheiro gravador (rtmpdump) e','introduz nas definições do addon o caminho para o ficheiro','ou desactiva o gravador: [B]http://bit.ly/xbmcgravador[/B]')
                selfAddon.openSettings()
                return
            else:
                if downloadPath=='':
                    xbmcgui.Dialog().ok('TV Portuguesa','Necessitas de introduzir a pasta onde vão ficar','as gravações. Escolhe uma pasta com algum espaço','livre disponível.')
                    selfAddon.openSettings()
                    return
        if len(ligacao)==1: index=0
        elif len(ligacao)==0: ok=mensagemok('TV Portuguesa', 'Nenhum stream disponivel.'); return     
        else: index = xbmcgui.Dialog().select('Escolha o servidor', titles)
        try:
            if index > -1:
                mensagemprogresso.create('TV Portuguesa', 'A carregar stream. (' + titles[index] + ')','Por favor aguarde...')
                mensagemprogresso.update(0)
                if mensagemprogresso.iscanceled(): mensagemprogresso.close()
                import buggalo
                buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
                sys.argv[2]=sys.argv[2]+ titles[index]

                linkescolha=ligacao[index]
                if linkescolha:
                    print linkescolha
                    if re.search('estadiofutebol',linkescolha):
                        link=abrir_url_cookie(linkescolha)
                        if re.search('televisaofutebol',link):
                            from t0mm0.common.net import Net
                            net = Net()
                            
                            codigo=re.compile('<iframe src="http://www.televisaofutebol.com/(.+?)"').findall(link)[0]
                            embed='http://www.televisaofutebol.com/' + codigo
                            ref_data = {'Referer': 'http://www.estadiofutebol.com','User-Agent':user_agent}
                            html = net.http_GET(embed,ref_data).content
                            descobrirresolver(embed,nome,html,False)
                        else:descobrirresolver(linkescolha, nome,False,False)
                    elif re.search('tvfree2',linkescolha):
                        link=abrir_url(linkescolha)
                        if re.search('antena.tvfree',link) or re.search('iframe id="player"',link):
                            #####
                            from t0mm0.common.net import Net
                            net = Net()
                            
                            #####
                            frame=re.compile('<iframe id="player".+?src="(.+?)"').findall(link)[0]
                            if not re.search('antena.tvfree',frame): frame= TVCoresURL + frame
                            ref_data = {'Referer': linkescolha,'User-Agent':user_agent}
                            link = net.http_GET(frame,ref_data).content
                            descobrirresolver(frame, nome,link,False)
                        else: descobrirresolver(linkescolha, nome,False,False)
                    elif re.search('sporttvhd',linkescolha):
                        link=clean(abrir_url(linkescolha))
                        try:
                            linkcod=re.compile("id='(.+?)'.+?</script><script type='text/javascript' src='"+SptveuURL +"/teste/").findall(link)[0]
                            descobrirresolver(SptveuURL+ '/teste/c0d3r.php?id=' + linkcod,nome,'hdm1.tv',False)
                        except:
                            frame=re.compile('</p>          <iframe allowtransparency="true" frameborder="0" scrolling=".+?" src="(.+?)"').findall(link)[0]
                            link=clean(abrir_url(frame))
                            if re.search('var urls = new Array',link):
                                framedupla=re.compile('new Array.+?"(.+?)".+?"(.+?)"').findall(link)[0]
                                if framedupla[0]==framedupla[1]: frame=framedupla[0]
                                else:
                                    opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Escolha um stream da lista dos disponiveis.", "", "","Stream Extra", 'Stream Principal')
                                    if opcao: frame=framedupla[0]
                                    else: frame=framedupla[1]
                      
                            descobrirresolver(frame, nome,False,False)
                    elif re.search('lvshd',linkescolha):
                        link=abrir_url(linkescolha)
                        linkfinal=limparcomentarioshtml(link,linkescolha)
                        endereco=re.compile('<iframe.+?src="(.+?)".+?</iframe></div>').findall(link)[0]
                        descobrirresolver(endereco, nome,False,False)
                    elif re.search('tvzune',linkescolha):
                        from t0mm0.common.net import Net
                        net = Net()
                        ref_data = {'Referer': 'http://www.tvzune.tv','User-Agent':user_agent}
                        html = net.http_GET(linkescolha,ref_data).content
                        descobrirresolver(linkescolha, nome,html,False)
                    else: descobrirresolver(linkescolha, nome,False,False)
        except Exception:
            mensagemprogresso.close()
            buggalo.onExceptionRaised()

def horaportuguesa():
    dt  = datetime.datetime.now()
    dts = dt.strftime('%Y-%m-%d%%20%H:%M')
    return dts
    
def p_todos():
    if selfAddon.getSetting("prog-lista3") == "false": return ''
    else:
        try:
            dia=horaportuguesa()
            listacanais='RTP1,RTP2,SIC,TVI,SPTV1,SPTV2,SPTV3,SPTVL,SLB,PORTO,CMTV,BBV,RTPIN,SICK,SICM,SICN,SICR,TVI24,TVIFIC,HOLLW,AXN,AXNBL,AXNWH,FOX,FOXCR,FLIFE,FOXM,SYFY,DISNY,PANDA,MOTOR,DISCV,ODISS,HIST,NGC,EURSP,FASH,VH1,MTV,ABOLA,RTPAC,RTPA,RTPM,RTPMD'
            url='http://services.sapo.pt/EPG/GetChannelListByDateInterval?channelSiglas='+listacanais+'&startDate=' + dia +':01&endDate='+ dia + ':02'
            link=clean(abrir_url(url,erro=False))
            listas=re.compile('<Sigla>(.+?)</Sigla>.+?<Title>(.+?)</Title>.+?<Description>(.+?)</Description>').findall(link)
            return listas
        except: ''

def p_umcanal(listas,desejado,desc):
    try:
        for nomecanal, nomeprog, descricao in listas:
            if nomecanal==desejado:
                if desc==False:return '(' + nomeprog + ')'
                else: return descricao
    except: pass
    return ''

def mensagemaviso():
    try:
        xbmc.executebuiltin("ActivateWindow(10147)")
        window = xbmcgui.Window(10147)
        xbmc.sleep(100)
        window.getControl(1).setLabel( "%s - %s" % ('AVISO','TV Portuguesa',))
        window.getControl(5).setText("[COLOR red][B]Termos:[/B][/COLOR]\nEste addon não aloja quaisquer conteúdos. O conteúdo apresentado é da responsabilidade dos servidores e em nada está relacionado com este addon.\n\nEste plugin não pretende substituir o acesso aos serviços de televisão pagos. Apenas funciona como extra a esses serviços.\n\nEste plugin apenas indexa links de outros sites, não alojando quaisquer conteúdos.\n\nEste plugin não pretende substituir o acesso aos sites de streaming, mas sim facilitar o acesso a estes via plataformas móveis (RPi, android, etc.)\n\nVisitem os sites oficiais e suportem os sites clicando na publicidade.\n\nUm obrigado a todos eles. (www.livesoccerhq.com, www.reshare.net, www.thesporttv.eu, www.tugastream.com, www.tvdez.com, www.tvfree4.me, www.tvportugalhd.org, www.tvzune.tv). Restart TV (www.videosbacanas.com)\n\n\n[COLOR red][B]É necessário actualizar o libRTMP do XBMC para alguns streams funcionarem a 100%.\nMais informações em: [/B][/COLOR] http://bit.ly/fightnightaddons\n\n[B]Faz like na pagina oficial do facebook:[/B] http://fb.com/fightnightxbmc \n\n[B]Data de actualização do aviso: [/B] 10 de Novembro de 2013")
    except: pass

def limparcomentarioshtml(link,url_frame):
    print "A limpar: " + url_frame
    if re.search('Sporttv1-veetle-iframe',url_frame) or re.search('Sporttv2-veetle-iframe',url_frame):
        return link
    else:
        link=clean(link)
        htmlcomments=re.compile('<!--(?!<!)[^\[>].*?-->').findall(link)
        for comentario in htmlcomments:
            link=link.replace(comentario,'oioioioi')
        return link

def zapping(name):
    dp = xbmcgui.DialogProgress()
    #if dp.iscanceled(): dp.close()
    dp.create("A criar lista de canais",'Criando...')
    dp.update(0)
    playlist = xbmc.PlayList(1)
    playlist.clear()

    savefile('zapping', '')
    dp.update(25)
    #descobrirresolver('http://tugastream.com/bigbrothervip.php','Big Brother VIP-',False,True)
    dp.update(50)
    descobrirresolver('http://tugastream.com/sporttv1.php','SPORTTV 1-',False,True)
    dp.update(75)
    descobrirresolver('http://tugastream.com/rtp1.php','RTP 1-',False,True)
    dp.update(100)
    dp.close()
    conteudozapping=openfile('zapping')
    canalindividual=re.compile('_comeca_(.+?)_nomecanal_(.+?)_thumb_(.+?)_acaba_').findall(conteudozapping)
    dp.create("TV Portuguesa",'Criando...')
    dp.update(0)
    print canalindividual
    for nomecanal, rtmp,thumb in canalindividual:
        listitem = xbmcgui.ListItem(nomecanal, iconImage="DefaultVideo.png", thumbnailImage=tvporpath + art + thumb)
        listitem.setInfo("Video", {"Title":nomecanal})
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(rtmp,listitem)
        progress = len(playlist) / float(len(canalindividual)) * 100               
        print rtmp
        print nomecanal
        dp.update(int(progress), 'A adicionar à playlist.')
    dp.close()
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    xbmcPlayer.play(playlist)

def descobrirresolver(url_frame,nomecanal,linkrecebido,zapping):
    if zapping==False:mensagemprogresso.update(50)
    try:
        import buggalo
        buggalo.SUBMIT_URL = 'http://fightnight.pusku.com/exceptions/submit.php'
        from t0mm0.common.net import Net
        net = Net()

        if linkrecebido==False:
            print "Resolver: O url da frame e " + url_frame
            url_frame=url_frame.replace(' ','%20')
            link=abrir_url_cookie(url_frame)
            try:link=limparcomentarioshtml(link,url_frame)
            except: pass
            link=link.replace('cdn.zuuk.net\/boi.php','').replace('cdn.zuuk.net\/stats.php','')
        else:
            print "Resolver: O produto final no descobrirresolver"
            link=limparcomentarioshtml(linkrecebido,url_frame)
            link=link.replace('<title>Zuuk.net</title>','').replace('http://s.zuuk.net/300x250.html','').replace('www.zuuk.net\/test.php?ch=','').replace('cdn.zuuk.net\/boi.php','').replace('cdn.zuuk.net\/stats.php','')
            
        if re.search("<iframe src='http://www.zuuk.pw",link):
            name=re.compile("<iframe src='http://www.zuuk.pw(.+?)'").findall(link)[0]
            descobrirresolver('http://www.zuuk.pw' + name,nomecanal,False,zapping)
        
        elif re.search("zuuk.net",link):
            try:
                print "Catcher: zuuk"
                l
#                try:chname=re.compile("file='(.+?)'.+?</script>").findall(link)[0]
#                except:chname=False
#                if not chname:
#                    chname=re.compile('src=.+?http://www.zuuk.net/el.php.+?ch=(.+?)&').findall(link)[0]
#                    link=abrir_url_cookie('http://www.zuuk.net/el.php?ch='+chname)
#                streamurl='rtmp://198.7.58.79/edge playPath='+ chname +' swfUrl=http://cdn.zuuk.net/ply.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.zuuk.net/'
#                comecarvideo(streamurl,nomecanal,True,zapping)
            except:
                print "Catcher: zuuk outro"
                if re.search('<script type="text/javascript">var urls = new Array',link): url_final=re.compile('new Array.+?"(.+?)",').findall(link)[0]
                ##derbie##
                else:
                    try:name=re.compile('<iframe.+?src="http://.+?zuuk.net/(.+?)"').findall(link)[0]
                    except:name=re.compile("<iframe.+?src='http://.+?zuuk.net/(.+?)'").findall(link)[0]
                    url_final="http://cdn.zuuk.net/" + name
                link=abrir_url_cookie(url_final)
                link=limparcomentarioshtml(link,url_frame)
                try:
                    info=re.compile("<div id='mediaspace'>"+'<script language="javascript".+?' + "document.write.+?unescape.+?'(.+?)'").findall(link)[0]
                    if info=="' ) );</script> <script type=": info=False
                except:info=False
                if info: infotratada=urllib.unquote(info)
                else: infotratada=link
                descobrirresolver(url_final,nomecanal,infotratada,zapping)

        #### ALIVE REMOVER DEPOIS ####

        elif re.search('file=myStream.sdp',link) or re.search('ec21.rtp.pt',link):
            print "Catcher: RTP Proprio"
            #link=abrir_url_cookie(url_frame)
            #urlalive=re.compile('<iframe src="(.+?)".+?></iframe>').findall(link)[0]
            #import cookielib
            #cookie = cookielib.CookieJar()
            #opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookie))
            #opener.addheaders = [('Host','www.rtp.pt'), ('User-Agent', user_agent), ('Referer',url_frame)]
            #linkfinal = opener.open(urlalive).read()
            rtmpendereco=re.compile('streamer=(.+?)&').findall(link)[0]
            filepath=re.compile('file=(.+?)&').findall(link)[0]
            filepath=filepath.replace('.flv','')
            swf="http://player.longtailvideo.com/player.swf"
            streamurl=rtmpendereco + ' playPath=' + filepath + ' swfUrl=' + swf + ' live=1 timeout=15 pageUrl=' + url_frame
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('720Cast',link) or re.search('ilive',link):
            print "Catcher: ilive"
            setecast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            if not setecast: setecast=re.compile('file: ".+?/app/(.+?)/.+?",').findall(link)
            if not setecast: setecast=re.compile('flashvars="file=(.+?)&').findall(link)
            if not setecast: setecast=re.compile('src="/ilive.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            if not setecast: setecast=re.compile('http://www.ilive.to/embed/(.+?)&').findall(link)
            if not setecast: setecast=re.compile('http://www.ilive.to/embedplayer.php.+?&channel=(.+?)&').findall(link)
            for chname in setecast:
                embed='http://www.ilive.to/embedplayer.php?width=640&height=400&channel=' + chname + '&autoplay=true'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                rtmp=re.compile('streamer: "(.+?)",').findall(html)[0]
                filelocation=re.compile('file: "(.+?).flv",').findall(html)[0]
                swf=re.compile("type: 'flash', src: '(.+?)'").findall(html)[0]
                streamurl=rtmp + ' playPath=' + filelocation + ' swfUrl=' + swf + ' token=I8772LDKksadhGHGagf# swfVfy=1 live=1 timeout=15 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('aliez',link):
            print "Catcher: aliez"
            aliez=re.compile('src="http://emb.aliez.tv/player/live.php.+?id=(.+?)&').findall(link)
            for chid in aliez:
                embed='http://emb.aliez.tv/player/live.php?id=' + chid + '&w=700&h=420'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('swfobject.embedSWF\("([^"]+)"').findall(html)[0]
                rtmp=urllib.unquote(re.compile('"file":\s."([^"]+)"').findall(html)[0])
                streamurl=rtmp + ' live=true swfVfy=1 swfUrl=' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('castalba', link):
            print "Catcher: castalba"
            castalba=re.compile('<script type="text/javascript"> id="(.+?)";.+?></script>').findall(link)
            for chname in castalba:
                embed='http://castalba.tv/embed.php?cid=' + chname + '&wh=640&ht=385&r=cdn.thesporttv.eu'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + '?id=' + ' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('castamp',link):
            print "Catcher: castamp"
            castamp=re.compile('channel="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://castamp.com/embed.php?c='+chname
                ref_data = {'Referer': 'http://www.zuuk.net','User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)[0]
                filelocation=re.compile("'file': '(.+?)',").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
                
        elif re.search('cast3d', link): ##nao esta
            print "Catcher: cast3d"
            cast3d=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in cast3d:
                embed='http://www.cast3d.tv/embed.php?channel=' + '&vw=640&vh=385&domain=lsh.lshunter.tv'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("""flashplayer': "(.+?)",""").findall(html)
                filelocation=re.compile("'file': '(.+?)',").findall(html)
                rtmpendereco=re.compile("'streamer': '(.+?)',").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + '?id=' + ' swfUrl=' + swf[0] + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('castto.me',link):
            print "Catcher: castto.me"
            castamp=re.compile('fid="(.+?)".+?</script>').findall(link)
            for chname in castamp:
                embed='http://static.castto.me/embed.php?channel='+chname+'&vw=650&vh=500&domain='+url_frame
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                if re.search('Channel does not exist',html):
                    mensagemok('TV Portuguesa','Stream está offline.')
                    return
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)[0]
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)[0]
                streamurl=rtmpendereco + ' playPath=' + filelocation + ' swfUrl=' + swf + ' live=true timeout=15 swfVfy=1 token=#ed%h0#w@1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ChelTV',link) or re.search('visionip',link):
            print "Catcher: cheltv"
            chelsea=re.compile("file=(.+?).flv&streamer=(.+?)&").findall(link)
            swf=re.compile('src="(.+?)" type="application/x-shockwave-flash">').findall(link)[0]
            streamurl=chelsea[0][1] + ' playPath=' + chelsea[0][0] + ' swfUrl=' + swf + ' live=true pageUrl=http://www.casadossegredos.tv'
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ezcast', link):
            print "Catcher: ezcast"
            ezcast=re.compile("channel='(.+?)',.+?</script>").findall(link)
            if not ezcast: ezcast=re.compile('src="/ezcast.tv.php.+?id=(.+?)" id="innerIframe"').findall(link)
            for chname in ezcast:
                embed='http://www.ezcast.tv/embedded/' + chname + '/1/555/435'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                link=abrir_url('http://www.ezcast.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                idnum=re.compile("'FlashVars'.+?id=(.+?)&s=.+?&").findall(html)[0]
                chnum=re.compile("'FlashVars'.+?id=.+?&s=(.+?)&").findall(html)[0]
                streamurl='rtmp://' + rtmpendereco + '/live playPath=' + chnum + '?id=' + idnum + ' swfUrl=http://www.ezcast.tv/static/scripts/eplayer.swf live=true conn=S:OK swfVfy=1 timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('fcast', link):
            print "Catcher: fcast"
            fcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            if not fcast: fcast=re.compile("e-fcast.tv.php.+?fid=(.+?).flv").findall(link)
            for chname in fcast:
                embed='http://www.fcast.tv/embed.php?live=' + chname + '&vw=600&vh=400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("SWFObject.+?'(.+?)'").findall(html)
                filelocation=re.compile("so.addVariable.+?file.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?streamer.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf[0] + ' live=true timeout=14 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('flashi', link):
            print "Catcher: flashi"
            flashi=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in flashi:
                embed='http://www.flashi.tv/embed.php?v=' + chname +'&vw=640&vh=490&typeplayer=0&domain=f1-tv.info'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                if re.search('This Channel is not Existed !',html):
                    ok=mensagemok('TV Portuguesa','Stream indisponivel')
                    return
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filename=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                #rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(link)
                streamurl='rtmp://flashi.tv:1935/lb' + ' playPath=' + filename[0] + ' swfUrl=http://www.flashi.tv/' + swf + ' live=true timeout=15 swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hdcast.tv',link):
            chid=re.compile('fid=(.+?)"').findall(link)[0]
            chid=chid.replace('.flv','')
            streamurl='rtmp://origin.hdcast.tv:1935/redirect/ playPath='+chid+' swfUrl=http://www.udemy.com/static/flash/player5.9.swf live=true timeout=15 swfVfy=1 pageUrl=http://www.hdcast.tv'
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hdcaster.net', link):
            print "Catcher: hdcaster"
            hdcaster=re.compile("<script type='text/javascript'>id='(.+?)'").findall(link)
            for chid in hdcaster:
                urltemp='rtmp://188.138.121.99/hdcaster playPath=' + chid + ' swfUrl=http://hdcaster.net/player.swf pageUrl=http://hdcaster.net/player.php?channel_id=101634&width=600&height=430'
                token = '%Xr8e(nKa@#.'
                streamurl=urltemp + ' token=' + token
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('icasthd', link):
            print "Catcher: icastHD"
            icast=re.compile('fid="(.+?)";.+?></script>').findall(link)
            for chname in icast:
                embed='http://www.icasthd.tv/embed.php?v='+chname+'&vw=575&vh=390&domain=www.ihdsports.com'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                if re.search('This Channel is not Existed !',html):
                    ok=mensagemok('TV Portuguesa','Stream indisponivel')
                    return
                swf=re.compile("'flashplayer': 'http://www.icasthd.tv//(.+?)'").findall(html)[0]
                filename=re.compile("'file': '(.+?)'").findall(html)[0]
                rtmpendereco=re.compile("'streamer': '(.+?)redirect3").findall(html)[0]
                app=re.compile("Ticket=(.+?)'").findall(html)[0]
                streamurl=rtmpendereco+ 'live app=live?f=' + app + ' playPath=' + filename + ' swfUrl=http://www.icasthd.tv/' + swf + ' live=1 timeout=15 swfVfy=1 pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('longtail', link):
            print "Catcher: longtail"
            longtail=re.compile("src='http://player.longtailvideo.com/player.swf' flashvars='file=(.+?)&streamer=(.+?)&").findall(link)
            if not longtail: longtail=re.compile('flashvars="file=(.+?)&streamer=(.+?)&').findall(link)
            for chname,rtmp in longtail:
                chname=chname.replace('.flv','')
                streamurl=rtmp + ' playPath=' + chname + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl=http://longtailvideo.com/'
                comecarvideo(streamurl,nomecanal,True,zapping)
            if not longtail:
                streamurl=re.compile('file: "(.+?)"').findall(link)[0]
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('hdm1.tv',link):
            print "Catcher: hdm1.tv"
            hdmi=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in hdmi:
                embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile("new SWFObject.+?'(.+?)'").findall(html)[0]
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)
            if not hdmi:
                hdmi=re.compile("src='(.+?).swf.+?file=(.+?)&streamer=(.+?)&autostart=true").findall(link)
                for swf,chid,rtmp in hdmi:
                    embed='http://hdm1.tv/embed.php?live='+ chid +'&vw=600&vh=470'
                    streamurl=rtmp + ' playPath=' + chid + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                    comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('jimey',link):
            print "Catcher: jimey"
            chname=re.compile("file='(.+?)';.+?</script>").findall(link)[0]
            embed= 'http://jimey.tv/player/embedplayer.php?channel=' + chname + '&width=640&height=490'
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html = net.http_GET(embed,ref_data).content
            rtmp=re.compile('&streamer=(.+?)/redirect').findall(html)[0]
            streamurl= rtmp + ' playPath='+chname + " token=zyklPSak>3';CyUt%)'ONp" + ' swfUrl=http://jimey.tv/player/fresh.swf live=true timeout=15 swfVfy=1 pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('jwlive',link) or re.search('jw-play',link):
            print "Catcher: jwlive"
            endereco=TVCoresURL + re.compile('<iframe src="(.+?)" id="innerIframe".+?>').findall(link)[0]
            if re.search('tvfree2.me/jw-player.html',endereco):
                streamurl=endereco.replace('http://tvfree2.me/jw-player.html?cid=','')
            else:
                link=abrir_url(endereco)
                streamurl=re.compile('file: "(.+?)"').findall(link)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('liveflash', link):
            print "Catcher: liveflash"
            flashtv=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not flashtv: flashtv=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not flashtv: flashtv=re.compile('iframe src="/cc-liveflash.php.+?channel=(.+?)"').findall(link)
            if not flashtv: flashtv=re.compile("window.open.+?'/e-liveflash.tv.php.+?channel=(.+?)'").findall(link)
            if not flashtv: flashtv=re.compile("http://tvph.googlecode.com/svn/players/liveflash.html.+?ver=(.+?)'").findall(link)
            for chname in flashtv:
                embed='http://www.liveflash.tv/embedplayer/' + chname + '/1/640/460'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                if re.search('Channel is domain protected.',html):
                    url_frame='http://www.liveflash.tv/' + chname
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    html = net.http_GET(embed,ref_data).content
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=abrir_url('http://www.liveflash.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)
                streamurl='rtmp://' + rtmpendereco[0] + '/stream/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.liveflash.tv' + swf[0] + ' pageUrl=' + embed
                #print streamurl
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('livestream', link):
            print "Catcher: livestream"
            livestream=re.compile("videoborda.+?channel=(.+?)&").findall(link)
            for chname in livestream:
                streamurl='rtmp://extondemand.livestream.com/ondemand playPath=trans/dv04/mogulus-user-files/ch'+chname+'/2009/07/21/1beb397f-f555-4380-a8ce-c68189008b89 live=true swfVfy=1 swfUrl=http://cdn.livestream.com/chromelessPlayer/v21/playerapi.swf pageUrl=http://cdn.livestream.com/embed/' + chname + '?layout=4&amp;autoplay=true'
                comecarvideo(streamurl,nomecanal,True,zapping)



        elif re.search('megom', link):
            print "Catcher: megom.tv"
            megom=re.compile('HEIGHT=432 SRC="http://distro.megom.tv/player-inside.php.+?id=(.+?)&width=768&height=432"></IFRAME>').findall(link)
            for chname in megom:
                embed='http://distro.megom.tv/player-inside.php?id='+chname+'&width=768&height=432'
                link=abrir_url(embed)
                swf=re.compile(".*'flashplayer':\s*'([^']+)'.*").findall(link)[0]
                streamer=re.compile("'streamer': '(.+?)',").findall(link)[0]
                streamer=streamer.replace('live.megom.tv','37.221.172.85')
                streamurl=streamer + ' playPath=' + chname + ' swfVfy=1 swfUrl=' + swf + ' live=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('micast', link):
            print "Catcher: micast"
            micast=re.compile('micast.tv:1935/live/(.+?)/').findall(link)
            if not micast: micast=re.compile('ca="(.+?)".+?></script>').findall(link)
            if not micast: micast=re.compile('setTimeout.+?"window.open.+?' + "'http://micast.tv/gen.php.+?ch=(.+?)',").findall(link)
            for chname in micast:
                embed=redirect('http://micast.tv/gen.php?ch='+chname)
                link=abrir_url(embed)
                if re.search('refresh',link):
                    chname=re.compile('refresh" content="0; url=http://micast.tv/gen.php.+?ch=(.+?)"').findall(link)[0]                
                    link=abrir_url('http://micast.tv/gen.php?ch='+chname)
                try:
                    final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                    streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                except:
                    rtmp=re.compile('file: "(.+?),').findall(link)[0]
                    chid=re.compile('/liveedge/(.+?)"').findall(rtmp)[0]
                    chidplay=chid.replace('.flv','')
                    rtmp=rtmp.replace(chid+'"','')
                    #rtmp://89.248.168.21/liveedge/<playpath>live5 <swfUrl>http://micast.tv/jwplayer/jwplayer.flash.swf <pageUrl>http://micast.tv/gens2.php?ch=live5
                    streamurl=rtmp + ' playPath=' + chidplay + ' swfUrl=http://micast.tv/jwplayer/jwplayer.flash.swf live=true pageUrl=' + embed

                comecarvideo(streamurl,nomecanal,True,zapping)
            if not micast:
                try:
                    micast=re.compile('<iframe src="(.+?)" id="innerIframe"').findall(link)[0]
                    link=abrir_url(TVCoresURL + micast)
                    if re.search('privatecdn',link):
                        descobrirresolver(url_frame,nomecanal,link,zapping)
                    else:
                        micast=re.compile('//(.+?).micast.tv/').findall(link)[0]
                        linkfinal='http://' + micast+  '.micast.tv'
                        link=abrir_url(linkfinal)
                        final=re.compile('file=(.+?)&amp;streamer=(.+?)&amp').findall(link)[0]
                        #if not final: final=re.compile("file=(.+?)&streamer=(.+?)'").findall(link)[0]
                        streamurl=final[1] + ' playPath=' + final[0] + ' swfUrl=http://files.mica.st/player.swf live=true timeout=15 swfVfy=1 pageUrl=http://micast.tv/gen.php?ch='+final[0]
                        comecarvideo(streamurl,nomecanal,True,zapping)
                except: pass
                
        elif re.search('mips', link):
            print "Catcher: mips"
            mips=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not mips: mips=re.compile('channel="(.+?)",.+?></script>').findall(link)
            if not mips: mips=re.compile('<iframe src="/mips.tv.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            for chname in mips:
                embed='http://www.mips.tv/embedplayer/' + chname + '/1/500/400'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                flashvars=flashvars.replace("')","&nada").split('l=&')
                if flashvars[1]=='nada':
                    nocanal=re.compile("&s=(.+?)&e=").findall(flashvars[0])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[0]
                else:
                    nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                    chid=re.compile("id=(.+?)&s=").findall(html)[1]
                nocanal=nocanal.replace('&','')
                link=abrir_url('http://www.mips.tv:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 live=true timeout=15 conn=S:OK swfUrl=http://www.mips.tv' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('privatecdn',link):
            print "Catcher: privatecdn"
            privatecdn=re.compile('<script type="text/javascript">id="(.+?)"').findall(link)
            for chid in privatecdn:
                embed='http://privatecdn.tv/ch.php?id='+chid
                link=abrir_url(embed)
                rtmp=re.compile('file: "(.+?)"').findall(link)[0]
                rtmp=rtmp.replace('/'+chid,'')
                streamurl=rtmp + ' playPath='+chid + ' live=true swfUrl=http://player.longtailvideo.com/player.swf pageUrl='+embed
                comecarvideo(streamurl,nomecanal,True,zapping)
                
        elif re.search('putlive', link):
            print "Catcher: putlive"
            putlivein=re.compile("<iframe.+?src='.+?.swf.+?file=(.+?)&.+?'.+?></iframe>").findall(link)
            if not putlivein: putlivein=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not putlivein: putlivein=re.compile('src="http://www.putlive.in/e/(.+?)"></iframe>').findall(link)
            for chname in putlivein:
                streamurl='rtmpe://199.195.199.172:443/liveedge2/ playPath=' + chname + ' swfUrl=http://www.megacast.io/player59.swf live=true timeout=15 swfVfy=1 pageUrl=http://putlive.in/'
                comecarvideo(streamurl,nomecanal,True,zapping)

        ##livesoccerhd
        elif re.search('src="http://cdn.sporttvhdmi.com',link):
            print "Catcher: livesoccerhd stolen sptvhd"
            ups=re.compile('<iframe.+?src="(.+?)"').findall(link)[0]
            descobrirresolver(ups,nomecanal,False,zapping)
        
        elif re.search('ptcanal', link):
            print "Catcher: ptcanal"
            ptcanal=re.compile('<p><a href="(.+?)" onclick="window.open').findall(link)[0]
            descobrirresolver(ptcanal,nomecanal,False,zapping)

        elif re.search('rtps',link):
            print "Catcher: rtps"
            ficheiro=re.compile("file='(.+?).flv'.+?</script>").findall(link)[0]
            streamurl='rtmp://ec21.rtp.pt/livetv/ playPath=' + ficheiro + ' swfUrl=http://museu.rtp.pt/app/templates/templates/swf/pluginplayer.swf live=true timeout=15 pageUrl=http://www.rtp.pt/'
            comecarvideo(streamurl, nomecanal,True,zapping)

        elif re.search('h2e.rtp.pt',link) or re.search('h2g2.rtp.pt',link):
            link=link.replace('\\','').replace('">',"'>")
            try:streamurl=re.compile("cid=(.+?).m3u8").findall(link)[0]
            except:streamurl=re.compile("file=(.+?).m3u8").findall(link)[0]
            #streamurl='rtmp://ec21.rtp.pt/livetv/ playPath=' + ficheiro + ' swfUrl=http://museu.rtp.pt/app/templates/templates/swf/pluginplayer.swf live=true timeout=15 pageUrl=http://www.rtp.pt/'
            comecarvideo(streamurl + '.m3u8', nomecanal,True,zapping)

        elif re.search('resharetv',link): #reshare tv
            ref_data = {'Referer': 'http://resharetv.com','User-Agent':user_agent}
            html = net.http_GET(url_frame,ref_data).content
            html=clean(html)
            try:
                try: streamurl=re.compile(',  file: "(.+?)"').findall(html)[0]
                except: streamurl=re.compile('file: "(.+?)"').findall(html)[0]
            except:
                try:
                    swf=re.compile('<param name="movie" value="/(.+?)"></param>').findall(html)[0]
                    rtmp=re.compile('<param name="flashvars" value="src=http%3A%2F%2F(.+?)%2F_definst_%2F.+?%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                    play=re.compile('_definst_%2F(.+?)%2Fmanifest.f4m&loop=true.+?">').findall(html)[0]
                except:
                    try:
                        swf=re.compile('src="(.+?)" type="application/x-shockwave-flash"').findall(html)[0]
                        rtmp=re.compile('streamer=(.+?)&amp').findall(html)[0]
                        play=re.compile('flashvars="file=(.+?).flv&').findall(html)[0]
                        streamurl='rtmp://' + urllib.unquote(rtmp) + ' playPath=' + play + ' live=true timeout=15 swfVfy=1 swfUrl=' + ResharetvURL + swf + ' pageUrl=' + ResharetvURL
                    except:
                        try:
                            frame=re.compile('<iframe.+?src="(.+?)">').findall(html)[0]
                            descobrirresolver(frame,nomecanal,False,zapping)
                            return
                        except:
                            ok = mensagemok('TV Portuguesa','Não e possível carregar stream.')
                            return
            comecarvideo(streamurl, nomecanal,True,zapping)

        elif re.search('p,a,c,k,e,r',link):
            print "Catcher: zuuk ruu.php"
            link=link.replace('|','')
            tuga=re.compile('ruuphpnr(.+?)style').findall(link)[0]
            descobrirresolver("http://www.zuuk.net/ruu.php?nr=" + tuga,nomecanal,False,zapping)

        elif re.search('sharecast',link):
            print "Catcher: sharecast"
            chname=re.compile('src="http://sharecast.to/embed/(.+?)"></iframe>').findall(link)[0]
            embed= 'http://sharecast.to/embed/' + chname
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            html = net.http_GET(embed,ref_data).content
            if re.search('Channel not found',html):
                ok = mensagemok('TV Portuguesa','Stream offline.')
                return
            rtmp= re.compile('file: "(.+?)",').findall(html)[0]
            streamurl=rtmp + ' live=true pageUrl=' + embed
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('sapo.pt',link):
            print "Catcher: sapo.pt"
            try:
                chname=re.compile('live/(.+?)&').findall(link)[0]
                filepath=re.compile('file=(.+?)&amp').findall(link)[0]
                l
            except:
                chname=re.compile('http://videos.sapo.pt/(.+?)"').findall(link)[0]
                info=abrir_url('http://videos.sapo.pt/'+chname)
                filepath=re.compile('/live/(.+?)",').findall(info)[0]
            host=abrir_url('http://videos.sapo.pt/hosts_stream.html')
            hostip=re.compile('<host>(.+?)</host>').findall(host)[0]
            streamurl='rtmp://' + hostip + '/live' + ' playPath=' + filepath  + ' swfUrl=http://imgs.sapo.pt/sapovideo/swf/flvplayer-sapo.swf?v11 live=true pageUrl=http://videos.sapo.pt/'+chname
            #ok=mensagemok('TV Portuguesa','Servidor não suportado')
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('telewizja',link):
            codigo=re.compile('<iframe src="(.+?)" id="innerIframe".+?>').findall(link)[0]
            ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            embed=TVCoresURL + codigo
            html = net.http_GET(embed,ref_data).content
            descobrirresolver(embed,nomecanal,html,zapping)

        elif re.search('televisaofutebol',link):
            print "Catcher: televisaofutebol"
            link=link.replace('\\','')
            tuga=re.compile('src="http://www.televisaofutebol.com/(.+?)".+?/iframe>').findall(link)[0]
            embed='http://www.televisaofutebol.com/' + tuga
            ref_data = {'Referer': 'http://www.estadiofutebol.com','User-Agent':user_agent}
            html = net.http_GET(embed,ref_data).content
            descobrirresolver(embed,nomecanal,html,zapping)

        elif re.search('tugastream',link):
            print "Catcher: tugastream"
            tuga=re.compile('src=".+?tugastream.com/(.+?)".+?/iframe>').findall(link)[0]
            descobrirresolver('http://www.tugastream.com/' + tuga,nomecanal,False,zapping)

        elif re.search('secretstory4_s.php',link):
            descobrirresolver('http://cdn.zuuk.net/secretstory4_s.php',nomecanal,False,zapping)

        elif re.search('tv-msn',link):
            print "Catcher: tv-msn"
            idcanal= 'http://tv-msn.com/' + re.compile('<iframe src="http://tv-msn.com/(.+?)" marginheight="0" marginwidth="0"').findall(link)[0]
            link=abrir_url(idcanal)
            frame=re.compile('<iframe.+?src="(.+?)".+?></iframe>').findall(link)[0]
            conteudo=abrir_url_cookie(frame)
            print conteudo
            variaveis=re.compile("flashvars='file=(.+?)&streamer=(.+?)&autostart=true").findall(conteudo)[0]
            streamurl=variaveis[1] + ' playPath=' + variaveis[0]  + ' swfUrl=http://www.cdnbr.biz/swf/player.swf live=true pageUrl='+frame


        elif re.search("<iframe style='position:relative; overflow:hidden; width:508px; height:408px; top:-8px; left:-8px;' src='http://tvzune.tv",link):
            print "Catcher: tvzune em tvpthd"
            streamurl=re.compile("<iframe.+?src='(.+?)'").findall(link)[0]
            descobrirresolver(streamurl,nomecanal,False,zapping)

        elif re.search('sicnoticias_sp.php',link):
            print "Catcher: sicnoticias"
            descobrirresolver('http://www.tugastream.com/sicnoticias_sp.php',nomecanal,False,zapping)
        
        elif re.search('tvph.googlecode.com',link):
            print "Catcher: tvph google code"
            if re.search('playeer.html',link):
                info=re.compile("cid=file=(.+?)&streamer=(.+?)'").findall(link)[0]
                rtmp=info[1]
                streamurl=rtmp + ' playPath='+info[0]+' swfUrl=http://www.tvzune.tv/jwplayer/jwplayer.flash.swf live=true pageUrl=' + url_frame
            else:
                streamurl=re.compile("cid=(.+?)'").findall(link)[0]
            comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('player_tvzune',link):
            print "Catcher: player tvzune"
            rtmp=re.compile('file: "(.+?)"').findall(link)[0] + '-'
            chid=re.compile('/tvzune/(.+?)-').findall(rtmp)[0]
            chidplay=chid.replace('.flv','')
            rtmp=rtmp.replace(chid+'-','')
            streamurl=rtmp + ' playPath=' + chidplay + ' swfUrl=http://www.tvzune.tv/jwplayer/jwplayer.flash.swf live=true pageUrl=' + url_frame
            comecarvideo(streamurl,nomecanal,True,zapping)
            

        elif re.search('veetle',url_frame) or re.search("src='http://veetle",link):
            print "Catcher: veetle"
            if selfAddon.getSetting("verif-veetle") == "false":
                ok = mensagemok('TV Portuguesa','Necessita de instalar o addon veetle.','Este irá ser instalado já de seguida.')
                import extract
                urlfusion='http://fightnight-xbmc.googlecode.com/svn/veetle/plugin.video.veetle.zip' #v2.2
                path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
                lib=os.path.join(path, 'plugin.video.veetle.zip')
                downloader(urlfusion,lib)
                addonfolder = xbmc.translatePath(os.path.join('special://home/addons',''))
                xbmc.sleep(2000)
                dp = xbmcgui.DialogProgress()
                #if dp.iscanceled(): dp.close()
                dp.create("TV Portuguesa", "A instalar...")
                try:
                    extract.all(lib,addonfolder,dp)
                    ok = mensagemok('TV Portuguesa','Veetle instalado / actualizado.','Necessita de reiniciar o XBMC.')
                    selfAddon.setSetting('verif-veetle',value='true')
                except:
                    ok = mensagemok('TV Portuguesa','Sem acesso para instalar Veetle. Efectue o download em','http://db.tt/G5QUEtEN e instale como zip nas definicoes do','XBMC. De seguida, active o Veetle nas definições do addon.')
            else:
                try:idembed=re.compile('/index.php/widget/index/(.+?)/').findall(link)[0]
                except: idembed=re.compile('/index.php/widget#(.+?)/true/16:9').findall(link)[0]
                print "ID embed: " + idembed
                try:
                    chname=abrir_url('http://tvmpt.x10.mx/fightnight/decode.php?id=' + idembed)
                    chname=chname.replace(' ','')
                    if re.search('DOCTYPE HTML PUBLIC',chname):
                        ok = mensagemok('TV Portuguesa','Erro a obter link do stream. Tenta novamente.')
                        return
                    print "ID final obtido pelo TvM."
                except:
                    chname=abrir_url('http://fightnight-xbmc.googlecode.com/svn/veetle/sporttvhdid.txt')
                    print "ID final obtido pelo txt."
                print "ID final: " + chname
                link=abrir_url('http://veetle.com/index.php/channel/ajaxStreamLocation/'+chname+'/flash')
                if re.search('"success":false',link): ok = mensagemok('TV Portuguesa','O stream está offline.')
                else:
                    #nomestreamfile='sporttv1hd.strm'
                    #caminhoveetle='plugin://plugin.video.veetle/?channel=' + chname
                    #print caminhoveetle
                    #savefile(nomestreamfile, caminhoveetle)
                    #streamfile = os.path.join(pastaperfil, nomestreamfile)
                    streamfile='plugin://plugin.video.veetle/?channel=' + chname
                    comecarvideo(streamfile,nomecanal,True,zapping)

        elif re.search('wcast', link):
            print "Catcher: wcast"
            wcast=re.compile("fid='(.+?)';.+?></script>").findall(link)
            for chid in wcast:
                embed='http://www.wcast.tv/embed.php?u=' + chid+ '&vw=600&vh=470'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                swf='http://www.wcast.tv/player/player.swf'
                filelocation=re.compile("so.addVariable.+?'file'.+?'(.+?)'").findall(html)
                rtmpendereco=re.compile("so.addVariable.+?'streamer'.+?'(.+?)'").findall(html)
                streamurl=rtmpendereco[0] + ' playPath=' + filelocation[0] + ' swfUrl=' + swf + ' live=true swfVfy=true pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('ucaster', link):
            print "Catcher: ucaster"
            ucaster=re.compile("channel='(.+?)',.+?></script>").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&s=(.+?)&g=1&a=1&l=').findall(link)
            if not ucaster: ucaster=re.compile('src="/ucaster.eu.php.+?fid=(.+?)" id="innerIframe"').findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            if not ucaster: ucaster=re.compile("flashvars='id=.+?&s=(.+?)&").findall(link)
            if not ucaster: ucaster=re.compile('flashvars="id=.+?id=.+?&amp;s=(.+?)&amp;g=1').findall(link)
            if not ucaster: ucaster=re.compile('channel="(.+?)".+?g="1"').findall(link)
            #if not ucaster:
                #mensagemok('TV Portuguesa','Stream não é o do site responsável','logo não é possível visualizar.')
            for chname in ucaster:
                embed='http://www.ucaster.eu/embedded/' + chname + '/1/600/430'
                try:
                    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                    html = net.http_GET(embed,ref_data).content
                    swf=re.compile('SWFObject.+?"(.+?)",').findall(html)[0]
                    flashvars=re.compile("so.addParam.+?'FlashVars'.+?'(.+?);").findall(html)[0]
                    flashvars=flashvars.replace("')","&nada").split('l=&')
                    if flashvars[1]=='nada':
                        nocanal=re.compile("&s=(.+?)&").findall(flashvars[0])[0]
                        chid=re.compile("id=(.+?)&s=").findall(html)[0]
                    else:
                        nocanal=re.compile("&s=(.+?)&nada").findall(flashvars[1])[0]
                        chid=re.compile("id=(.+?)&s=").findall(html)[1]
                    nocanal=nocanal.replace('&','')
                except:
                    nocanal=chname
                    chid=re.compile("flashvars='id=(.+?)&s").findall(link)[0]
                    swf=re.compile("true' src='http://www.ucaster.eu(.+?)'").findall(link)[0]
                link=abrir_url('http://www.ucaster.eu:1935/loadbalancer')
                rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
                streamurl='rtmp://' + rtmpendereco + '/live playPath=' + nocanal + '?id=' + chid + ' swfVfy=1 conn=S:OK live=true swfUrl=http://www.ucaster.eu' + swf + ' pageUrl=' + embed
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('xuuby',link): ##proteccao tvdez
            print "Catcher: xuuby"
            xuuby=re.compile('chname="(.+?)".+?</script>').findall(link)
            if not xuuby: xuuby=re.compile('chname=(.+?)&').findall(link)
            for chname in xuuby:
                embed='http://www.xuuby.com/show2.php?chname='+chname+'&width=555&height=555&a=1'
                ref_data = {'Referer': url_frame,'User-Agent':user_agent}
                html = net.http_GET(embed,ref_data).content
                html=urllib.unquote(html)
                streamurl=re.compile('file: "(.+?)"').findall(html)[0]
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('youtube.com/v',link):
            idvideo=re.compile('type="application/x-shockwave-flash" src="http://www.youtube.com/v/(.+?)&.+?"></object>').findall(link)[0]
            sources=[]
            import urlresolver
            embedvideo='http://www.youtube.com/watch?v=' + idvideo
            hosted_media = urlresolver.HostedMediaFile(url=embedvideo)
            sources.append(hosted_media)
            source = urlresolver.choose_source(sources)
            if source:
                streamurl=source.resolve()
                comecarvideo(streamurl,nomecanal,True,zapping)
                    

        elif re.search('yukons', link):
            print "Catcher: yukons"
            yukons=re.compile('kuyo&file=(.+?)&').findall(link)
            if not yukons: yukons=re.compile("file='(.+?)'.+?</script>").findall(link)
            if not yukons: yukons=re.compile('channel="(.+?)".+?</script>').findall(link)
            if not yukons: yukons=re.compile('file=(.+?)&').findall(link)
            for chname in yukons:
                #<playpath>tasdasdeas?id=a5e1d95d34a78be2f17553e5458dfdf9&pid=322e38322e3130362e3836 <swfUrl>http://yukons.net/yplay.swf <pageUrl>http://yukons.net/embed/3734363137333634363137333634363536313733/98054e35838bba6626d7c8c695f12b07/768/432
                 #rtmp://198.144.153.140:443/kuyo<playpath>novoid?id=38382e3231342e3138312e3838 <swfUrl>http://yukons.net/yplayerv2.swf <pageUrl>http://yukons.net/embed/364536463736364636393634/bed617f5db1a30236e4f7d58394f55b5/650/500
                streamurl='rtmp://198.144.153.143:443/kuyo playPath=' + chname + '?id=a5e1d95d34a78be2f17553e5458dfdf9&pid=322e38322e3130362e3836 swfUrl=http://yukons.net/yplay.swf live=true conn=S:OK timeout=15 swfVfy=true pageUrl=http://yukons.net/embed/3734363137333634363137333634363536313733/98054e35838bba6626d7c8c695f12b07/768/432'
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('yycast', link): ##requires librtmp 14-9-2013
            print "Catcher: yycast"
            mensagemok("TV Portuguesa","Servidor incompativel.")
            #yycast=re.compile('fid="(.+?)";.+?</script><script type="text/javascript" src="http://www.yycast.com/javascript/embedPlayer.js"></script>').findall(link)
            #if not yycast: yycast=re.compile("file='(.+?).flv'.+?</script>").findall(link)
            #if not yycast: yycast=re.compile('fid="(.+?)".+?</script>').findall(link)
            #if not yycast: yycast=re.compile('channel="(.+?)".+?</script>').findall(link)
            #for chname in yycast:
            #    embed='http://yycast.com/embedded/'+ chname + '/1/555/435'
            #    ref_data = {'Referer': url_frame,'User-Agent':user_agent}
            #    html = net.http_GET(embed,ref_data).content
            #    #print html
            #    link=abrir_url('http://yycast.com:1935/loadbalancer')
            #    rtmpendereco=re.compile(".*redirect=([\.\d]+).*").findall(link)[0]
            #    print rtmpendereco                
            #    #so.addParam('FlashVars', 'id=1516&s=sic880809&g=1&a=1&l=');
            #    swf=re.compile('SWFObject.+?"(.+?)"').findall(html)[0]
            #    idnum=re.compile("'FlashVars', 'id=(.+?)&s=.+?'").findall(html)[0]
            #    chnum=re.compile("'FlashVars', 'id=.+?&s=(.+?)&").findall(html)[0]
            #    #streamurl='rtmp://yycast.com:1935/live/_definst_/sicasdf. app=live playPath=' + chnum + '?id=' + idnum + ' swfVfy=1 timeout=15 conn=S:OK live=true swfUrl=http://yycast.com' + swf + ' pageUrl=' + embed
            #    streamurl='rtmp://' + rtmpendereco + '/live/ playPath=' + chnum + '?id=' + idnum + ' swfVfy=1 timeout=15 conn=S:OK live=true swfUrl=http://yycast.com' + swf + ' pageUrl=' + embed
            #    #print html
            #    #streamurl='rtmp://live.yycast.com/lb playPath=' + chname + ' live=true timeout=15 swfUrl=http://cdn.yycast.com/player/player.swf pageUrl=http://www.yycast.com/embed.php?fileid='+chname+'&vw=768&vh=432'
            #    comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('zcast.us', link):
            print "Catcher: zcast"
            zcast=re.compile('channel="(.+?)";.+?></script>').findall(link)
            for chname in zcast:
                embed='http://zcast.us/gen.php?ch=' + chname + '&width=700&height=480'
                streamurl='rtmp://gabon.zcast.us/liveedge' + ' playPath=' + url_frame + ' live=true timeout=15 swfVfy=1 swfUrl=http://player.zcast.us/player58.swf pageUrl=http://www.xuuby.com/'
                comecarvideo(streamurl,nomecanal,True,zapping)

        elif re.search('<p><script language="JavaScript">setTimeout', link):
            print "Catcher: tvtuga zuuk"
            ptcanal=redirect(re.compile('setTimeout.+?"window.open.+?' + "'(.+?)',").findall(link)[0])
            html=urllib.unquote(abrir_url(ptcanal))
            descobrirresolver(ptcanal,nomecanal,html,zapping)

        else:
            print "Catcher: noserver" 
            ok=mensagemok('TV Portuguesa','Servidor não suportado')
            mensagemprogresso.close()
    except Exception:
        mensagemprogresso.close()
        buggalo.onExceptionRaised()


def redirect(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    gurl=response.geturl()
    return gurl

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'): params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2: param[splitparams[0]]=splitparams[1]                         
    return param

def menugravador():
    if selfAddon.getSetting("gravadoractivar") == "true":
        texto='O modo de gravador está [COLOR green]activo[/COLOR].'
        textobotao='Desactivar'
        textonotificacao='Modo gravador desactivado'
    else:
        texto='O modo de gravador está [COLOR red]desactivado[/COLOR].'
        textobotao='Activar'
        textonotificacao='Modo gravador activado'
    opcao= xbmcgui.Dialog().yesno("TV Portuguesa", texto, "O que deseja fazer?", "",textobotao, 'Ver gravações')
    if opcao==1:
        if selfAddon.getSetting("localizacaortmpdump") == "":
            ok = mensagemok('TV Portuguesa','Faz download do ficheiro gravador (rtmpdump) e','introduz nas definições do addon o caminho para o ficheiro','ou desactiva o gravador: [B]http://bit.ly/xbmcgravador[/B]')
            selfAddon.openSettings()
            return
        else:
            if downloadPath=='':
                xbmcgui.Dialog().ok('TV Portuguesa','Necessitas de introduzir a pasta onde vão ficar','as gravações. Escolhe uma pasta com algum espaço','livre disponível.')
                selfAddon.openSettings()
                return
        xbmc.executebuiltin("ActivateWindow(VideoFiles," + downloadPath + ")")
    else:
        if textobotao=='Desactivar': selfAddon.setSetting('gravadoractivar',value='false')
        else: selfAddon.setSetting('gravadoractivar',value='true')
        xbmc.executebuiltin("XBMC.Notification(TV Portuguesa," + textonotificacao + ",'10000'," + tvporpath + art + "icon32-ver1.png)")
        xbmc.executebuiltin("XBMC.Container.Refresh")    

def comecarvideo(finalurl,name,directo,zapping,thumb=''):
    siglacanal=''
    namega=name.replace('-','')
    GA("player",namega)
    if directo==True:
        thumb=name.replace('Mais TVI-','maistvi-ver2.png').replace('AXN-','axn-ver2.png').replace('FOX-','fox-ver2.png').replace('RTP 1-','rtp1-ver2.png').replace('RTP 2-','rtp2-ver2.png').replace('SIC-','sic-ver3.png').replace('SPORTTV 1-','sptv1-ver2.png').replace('SPORTTV 1 HD-','sptv1-ver2.png').replace('SPORTTV 2-','sptv2-ver2.png').replace('SPORTTV 3-','sptv3-ver2.png').replace('SPORTTV LIVE-','sptvlive-ver1.png').replace('TVI-','tvi-ver2.png').replace('Discovery Channel-','disc-ver2.png').replace('AXN Black-','axnb-ver2.png').replace('AXN White-','axnw-ver2.png').replace('FOX Crime-','foxc-ver2.png').replace('FOX Life-','foxl-ver3.png').replace('FOX Movies-','foxm-ver2.png').replace('Eurosport-','eusp-ver2.png').replace('Hollywood-','hwd-ver2.png').replace('MOV-','mov-ver2.png').replace('Canal Panda-','panda-ver2.png').replace('VH1-','vh1-ver2.png').replace('Benfica TV-','bentv-ver2.png').replace('Porto Canal-','pcanal-ver2.png').replace('Big Brother VIP-','bbvip-ver2.png').replace('SIC K-','sick-ver2.png').replace('SIC Mulher-','sicm-ver3.png').replace('SIC Noticias-','sicn-ver2.png').replace('SIC Radical-','sicrad-ver2.png').replace('TVI24-','tvi24-ver2.png').replace('TVI Ficção-','tvif-ver2.png').replace('Syfy-','syfy-ver1.png').replace('Odisseia-','odisseia-ver1.png').replace('História-','historia-ver1.png').replace('National Geographic Channel-','natgeo-ver1.png').replace('MTV-','mtv-ver1.png').replace('CM TV-','cmtv-ver1.png').replace('RTP Informação-','rtpi-ver1.png').replace('Disney Channel-','disney-ver1.png').replace('Motors TV-','motors-ver1.png').replace('ESPN America-','espna-ver1.png').replace('Fashion TV-','fash-ver1.png').replace('A Bola TV-','abola-ver1.png').replace('Casa dos Segredos 4-','casadseg-ver1.png').replace('RTP Açores-','rtpac-ver1.png').replace('RTP Internacional-','rtpint-ver1.png').replace('RTP Madeira-','rtpmad-ver1.png').replace('RTP Memória-','rtpmem-ver1.png').replace('RTP Africa-','rtpaf-ver1.png')
        name=name.replace('-','')
        progname=name
        if selfAddon.getSetting("prog-player3") == "true":
            try:
                siglacanal=name.replace('SPORTTV 1','SPTV1').replace('SPORTTV 2','SPTV2').replace('SPORTTV 3','SPTV3').replace('SPORTTV LIVE','SPTVL').replace('Discovery Channel','DISCV').replace('AXN Black','AXNBL').replace('AXN White','AXNWH').replace('FOX Crime','FOXCR').replace('FOX Life','FLIFE').replace('FOX Movies','FOXM').replace('Eurosport','EURSP').replace('Hollywood','HOLLW').replace('Canal Panda','PANDA').replace('Benfica TV','SLB').replace('Porto Canal','PORTO').replace('Big Brother VIP','BBV').replace('SIC K','SICK').replace('SIC Mulher','SICM').replace('SIC Noticias','SICN').replace('SIC Radical','SICR').replace('TVI24','TVI24').replace('TVI Ficção','TVIFIC').replace('Mais TVI','SEM').replace('Syfy-','SYFY').replace('Odisseia','ODISS').replace('História','HIST').replace('National Geographic Channel','NGC').replace('MTV','MTV').replace('CM TV','CMTV').replace('RTP Informação','RTPIN').replace('Disney Channel','DISNY').replace('Motors TV','MOTOR').replace('ESPN America','SEM').replace('Fashion TV','FASH').replace('MOV','SEM').replace('A Bola TV','ABOLA')
                progname=p_umcanal(p_todos(),siglacanal,False)
                if progname=='':pass
                else: name=name + ' ' + progname
            except: pass
        listitem = xbmcgui.ListItem(progname, iconImage="DefaultVideo.png", thumbnailImage=tvporpath + art + thumb)
    else: listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumb)
    if zapping==True:
        conteudoficheiro=openfile('zapping')
        savefile('zapping', conteudoficheiro + '_comeca_' + name + '_nomecanal_' + finalurl + '_thumb_' + thumb + '_acaba_')
    else:
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(finalurl, listitem)
        mensagemprogresso.close()
        dialogWait = xbmcgui.DialogProgress()
        dialogWait.create('TV Portuguesa', 'A carregar...')
        dialogWait.close()
        del dialogWait
        
        player = Player(finalurl=finalurl,name=name,siglacanal=siglacanal,directo=directo)
        player.play(playlist)
        while player.is_active:
            player.sleep(1000)
        #if not player.is_active:
        #    print "Parou. Saiu do ciclo."
        #    sys.exit(0)
            
            #player.sleep(10000)
            #print "ERRO"
            
        #import SimpleDownloader as downloader
        #downloader = downloader.SimpleDownloader()
        #downloader.dbg = True
        #url=finalurl
        #params = {"url": finalurl, "download_path": pastaperfil, "Title": "Live Download", "live": "true", "duration": "1"}
        #downloader.download("aljazeera-10minutes.mp4", params)



class Player(xbmc.Player):
      def __init__(self,finalurl,name,siglacanal,directo):
            if selfAddon.getSetting("playertype") == "0": player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
            elif selfAddon.getSetting("playertype") == "1": player = xbmc.Player(xbmc.PLAYER_CORE_MPLAYER)
            elif selfAddon.getSetting("playertype") == "2": player = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
            elif selfAddon.getSetting("playertype") == "3": player = xbmc.Player(xbmc.PLAYER_CORE_PAPLAYER)
            else: player = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
            self.is_active = True
            self._refInfo = True
            self._totalTime = 999999
            self._finalurl=finalurl
            self._name=name
            self._siglacanal=siglacanal
            self._directo=directo
            print "Criou o player"
            #player.stop()

      def onPlayBackStarted(self):
            print "Comecou o player"
            if self._directo==True and selfAddon.getSetting("gravadoractivar") == "true":
                if re.search('rtmp://',self._finalurl) and selfAddon.getSetting("gravadoractivar") == "true":
                    self._finalurl=self._finalurl.replace('playPath=','-y ').replace('swfVfy=1','').replace('conn=','-C ').replace('live=true','-v').replace('swfUrl=','-W ').replace('pageUrl=','-p ').replace('token=','-T ').replace('app=','-a ')
                    import gravador
                    gravador.verifica_so(' -r ' + self._finalurl,self._name,self._siglacanal,self._directo)
                else: xbmc.executebuiltin("XBMC.Notification(TV Portuguesa, Stream não gravável. Escolha outro.,'100000'," + tvporpath + art + "icon32-ver1.png)")
                              
      def onPlayBackStopped(self):
            print "Parou o player"
            self.is_active = False
            #opcao= xbmcgui.Dialog().yesno("TV Portuguesa", "Este stream funciona? ", "(exemplificação / ainda não funciona)", "",'Sim', 'Não')
            ###### PERGUNTAR SE O STREAM E BOM #####            

      def onPlayBackEnded(self):              
            self.onPlayBackStopped()
            print 'Chegou ao fim. Playback terminou.'


      def sleep(self, s): xbmc.sleep(s) 

class PlaybackFailed(Exception):
      '''XBMC falhou a carregar o stream'''

def addLink(name,url,iconimage):
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
    try:
        if re.search('HD',name) or re.search('1080P',name) or re.search('720P',name):liz.addStreamInfo( 'video', { 'Codec': 'h264', 'width': 1280, 'height': 720 } )
        else: liz.addStreamInfo( 'video', { 'Codec': 'h264', 'width': 600, 'height': 300 } )
    except: pass    
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)

def addCanal(name,url,mode,iconimage,total,descricao):
    cm=[]
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&thumb="+urllib.quote_plus(iconimage)
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "overlay":6 ,"plot":descricao} )
    liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
    try:
        if re.search('HD',name) or re.search('1080P',name) or re.search('720P',name):liz.addStreamInfo( 'video', { 'Codec': 'h264', 'width': 1280, 'height': 720 } )
        else: liz.addStreamInfo( 'video', { 'Codec': 'h264', 'width': 600, 'height': 300 } )
    except: pass
    #cm.append(('Adicionar stream preferencial', "XBMC.RunPlugin(%s?mode=%s&name=%s&url=%s)")%(sys.argv[0],)
    liz.addContextMenuItems(cm, replaceItems=False)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=total)

def addDir(name,url,mode,iconimage,total,descricao,pasta):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "overlay":6 ,"plot":descricao} )
    liz.setProperty('fanart_image', "%s/fanart.jpg"%selfAddon.getAddonInfo("path"))
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=pasta,totalItems=total)

def clean(text):
    command={'\r':'','\n':'','\t':'','&nbsp;':''}
    regex = re.compile("|".join(map(re.escape, command.keys())))
    return regex.sub(lambda mo: command[mo.group(0)], text)

def parseDate(dateString):
    try: return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except: return datetime.datetime.today() - datetime.timedelta(days = 1) #force update

def checkGA():
    secsInHour = 60 * 60
    threshold  = 2 * secsInHour
    now   = datetime.datetime.today()
    prev  = parseDate(selfAddon.getSetting('ga_time'))
    delta = now - prev
    nDays = delta.days
    nSecs = delta.seconds
    doUpdate = (nDays > 0) or (nSecs > threshold)
    if not doUpdate:
        return
    selfAddon.setSetting('ga_time', str(now).split('.')[0])
    APP_LAUNCH()    
    
                    
def send_request_to_google_analytics(utm_url):
    try:
        req = urllib2.Request(utm_url, None,{'User-Agent':user_agent})
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)         
    return response
       
def GA(group,name):
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VISITOR = selfAddon.getSetting('ga_visitor')
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================" 
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + versao + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + versao + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                                
            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)
            
        except:
            print "================  CANNOT POST TO ANALYTICS  ================" 
            
            
def APP_LAUNCH():
        versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
        if versionNumber < 12:
            if xbmc.getCondVisibility('system.platform.osx'):
                if xbmc.getCondVisibility('system.platform.atv2'):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
            elif xbmc.getCondVisibility('system.platform.ios'):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility('system.platform.windows'):
                log_path = xbmc.translatePath('special://home')
                log = os.path.join(log_path, 'xbmc.log')
                logfile = open(log, 'r').read()
            elif xbmc.getCondVisibility('system.platform.linux'):
                log_path = xbmc.translatePath('special://home/temp')
            else:
                log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        elif versionNumber > 11:
            print '======================= more than ===================='
            log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, 'xbmc.log')
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        else:
            logfile='Starting XBMC (Unknown Git:.+?Platform: Unknown. Built.+?'
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        print '==========================   '+PATH+' '+versao+'  =========================='
        try:
            from hashlib import md5
        except:
            from md5 import md5
        from random import randint
        import time
        from urllib import unquote, quote
        from os import environ
        from hashlib import sha1
        import platform
        VISITOR = selfAddon.getSetting('ga_visitor')
        for build, PLATFORM in match:
            if re.search('12',build[0:2],re.IGNORECASE): 
                build="Frodo" 
            if re.search('11',build[0:2],re.IGNORECASE): 
                build="Eden" 
            if re.search('13',build[0:2],re.IGNORECASE): 
                build="Gotham" 
            print build
            print PLATFORM
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + versao + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except:
                print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================" 
checkGA()

params=get_params()
url=None
thumb=None
name=None
mode=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: thumb=urllib.unquote_plus(params["thumb"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass

##################################MENU LATERAL######################
class menulateral(xbmcgui.WindowXMLDialog):
    
    C_POPUP_CHOOSE_STREAM = 4001
    C_POPUP_CHANNEL_LOGO = 4100

    C_CHANNELS_LIST = 6000
    C_CHANNELS_SELECTION_VISIBLE = 6001
    C_CHANNELS_SELECTION = 6002
    C_CHANNELS_SAVE = 6003
    C_CHANNELS_CANCEL = 6004



    def __init__( self, *args, **kwargs ):
            xbmcgui.WindowXML.__init__(self)

    def onInit(self):
        channelLogoControl = self.getControl(self.C_POPUP_CHANNEL_LOGO)
        channelLogoControl.setImage(tvporpath + art + 'sptv1-ver2.png')        
        self.updateChannelList()


    def onAction(self, action):
        if action.getId() in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, KEY_NAV_BACK, KEY_CONTEXT_MENU]:
            self.close()
            return

    def onClick(self, controlId):
        pass
        #if controlId == self.C_POPUP_CHOOSE_STREAM:
        #    self.close()
        #    request_servidores(url,name)

        #elif controlId == 6000:
        #    listControl = self.getControl(self.C_CHANNELS_LIST)
        #    item = listControl.getSelectedItem()
        #    nomecanal=item.getProperty('chname')
        #    self.close()
        #    request_servidores(url,nomecanal)
        #    
        #else:
        #    self.buttonClicked = controlId
        #    self.close()

    def onFocus(self, controlId):
        
        #print "SIM!!!!"
        pass

    def updateChannelList(self):
        idx=-1
        listControl = self.getControl(self.C_CHANNELS_LIST)
        listControl.reset()
        canaison=openfile('canaison')
        canaison=canaison.replace('[','')
        lista=re.compile('B](.+?)/B]').findall(canaison)
        for nomecanal in lista:
            idx=int(idx+1)
            if idx==0: idxaux='   '
            else: idxaux='%4s.' % (idx)
            item = xbmcgui.ListItem(idxaux + ' %s' % (nomecanal), iconImage = '')
            item.setProperty('idx', str(idx))
            item.setProperty('chname', '[B]' + nomecanal + '[/B]')
            listControl.addItem(item)
        
        #for idx, channel in enumerate(self.channelList):
        #    if channel.visible:
        #        iconImage = 'tvguide-channel-visible.png'
        #    else:
        #        iconImage = 'tvguide-channel-hidden.png'

        #    item = xbmcgui.ListItem('%3d. %s' % (idx+1, channel.title), iconImage = iconImage)
        #    item.setProperty('idx', str(idx))
        #    listControl.addItem(item)
        
    def updateListItem(self, idx, item):
        channel = self.channelList[idx]
        item.setLabel('%3d. %s' % (idx+1, channel.title))

        if channel.visible:
            iconImage = 'tvguide-channel-visible.png'
        else:
            iconImage = 'tvguide-channel-hidden.png'
        item.setIconImage(iconImage)
        item.setProperty('idx', str(idx))

    def swapChannels(self, fromIdx, toIdx):
        if self.swapInProgress:
            return
        self.swapInProgress = True

        c = self.channelList[fromIdx]
        self.channelList[fromIdx] = self.channelList[toIdx]
        self.channelList[toIdx] = c

        # recalculate weight
        for idx, channel in enumerate(self.channelList):
            channel.weight = idx

        listControl = self.getControl(self.C_CHANNELS_LIST)
        self.updateListItem(fromIdx, listControl.getListItem(fromIdx))
        self.updateListItem(toIdx, listControl.getListItem(toIdx))

        listControl.selectItem(toIdx)
        xbmc.sleep(50)
        self.swapInProgress = False


def testejanela():
    d = menulateral("" , tvporpath, "Default")
    d.doModal()
    del d

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Thumb: "+str(url)

if mode==None or url==None or len(url)<1:
    print "Versao Instalada: v" + versao
    if selfAddon.getSetting('termos') == 'true':
        mensagemaviso()
        selfAddon.setSetting('termos',value='false')
    entraraddon()
elif mode==1: menu_principal()
elif mode==2: restarttv()
elif mode==3: restarttv_lista(name,url)
elif mode==4: restarttv_progs(name,url)
elif mode==5: obter_lista(name,url)
elif mode==6: listascanais()
elif mode==7: descobrirresolver(url,nomecanal,linkrecebido,zapping)
elif mode==8: restarttv_play(name,url)
elif mode==9: xbmc.executebuiltin("Container.NextViewMode")
elif mode==10: restarttv_pesquisa()
elif mode==12: menugravador()
elif mode==13: abrir_lista_canais()
elif mode==14: ok = mensagemok('TV Portuguesa','[B][COLOR white]Queres adicionar a tua lista (XML)?[/COLOR][/B]','Visita [B]http://bit.ly/fightnightaddons[/B]','ou contacta "fightnight.addons@gmail.com')
elif mode==15: ok = mensagemok('TV Portuguesa','A actualizacao é automática. Caso nao actualize va ao','repositorio fightnight e prima c ou durante 2seg','e force a actualizacao. De seguida, reinicie o XBMC.')
elif mode==16: request_servidores(url,name)
elif mode==17: comecarvideo(url,name,'listas',False,thumb=thumb)
elif mode==22: selfAddon.openSettings()
elif mode==23: mensagemaviso()
elif mode==2013: testejanela()


xbmcplugin.endOfDirectory(int(sys.argv[1]))
